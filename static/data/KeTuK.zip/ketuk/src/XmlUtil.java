/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xerces.parsers.*;
import java.net.*;
import java.io.*;

/**
 * General utilities to manipulate DOM objects
 *
 * @author Claude Pasquier
 */
public class XmlUtil {

  /**
   * Default constructor
   */
  public XmlUtil() {
  }

  /**
   * The first child of type Node.ELEMENT_NODE
   * <p>
   * If there is no such node, this returns null .
   *
   *  @param elt      the parent element of the returned node
   */
  public Element getFirstChildElement(Element elt) {
    Node n = elt.getFirstChild();
    while (n != null) {
      if (n.getNodeType() == Node.ELEMENT_NODE) return (Element)n;
      n = n.getNextSibling();
    }
    return null;
  }

  /**
   * The element following the parameter element
   * <p>
   * If there is no such element, this returns null .
   *
   *  @param elt      the element where to start the search
   */
  public Element getNextElement(Element elt) {
    Node n = elt.getNextSibling();
    while (n != null) {
      if (n.getNodeType() == Node.ELEMENT_NODE) return (Element)n;
      n = n.getNextSibling();
    }
    return null;
  }

  /**
   * The element preceding the parameter element
   * <p>
   * If there is no such element, this returns null .
   *
   *  @param elt      the element where to start the search
   */
  public Element getPreviousElement(Element elt) {
    Node n = elt.getPreviousSibling();
    while (n != null) {
      if (n.getNodeType() == Node.ELEMENT_NODE) return (Element)n;
      n = n.getPreviousSibling();
    }
    return null;
  }

  /**
   * Returns the number of child elements of the parameter node
   *
   *  @param elt      the source element
   *
   *  @return         the number of childs elements of elt
   */
  public int countNbChildElements(Element elt) {
    Node n = elt.getFirstChild();
    int nbChilds = 0;
    while (n != null) {
      if (n.getNodeType() == Node.ELEMENT_NODE)
        nbChilds += 1;
      n = n.getNextSibling();
    }
    return nbChilds;
  }


  /**
   * Searches in a document tree, an element with a given attribute
   * valorized with a specific value
   *
   *  @param doc      the document tree where to perform the search
   *  @param attName  the name of the attribute
   *  @param attValue the value of the attribute
   *
   *  @return         the first element found
   */
  public Element getEltByAttValue(Document doc, String attName, String attValue) {
    NodeList nList = doc.getElementsByTagName("*");
    for (int i = 0 ; i < nList.getLength() ; i++) {
      Element elt = (Element)nList.item(i);
      if (elt.getAttribute(attName).equals(attValue)) return elt;
    }
    return null;
  }

  /**
   * Creates an URL object from a string representation
   * <p>
   * If the string is not representing an url
   * (i.e. the constructor of the URL fails), then,
   * the methods tries to constructs an URL representing a local file
   * by adding "file:" in front of the parameter string
   * if the URL creation fails again, then MalformedURLException
   * is returned
   *
   *  @param string   the sting to parse as an URL
   *
   *  @return         the created URL
   */
  public URL getUrl(String source)
    throws MalformedURLException {
    return getUrl(null, source);
  }
  
  /**
   * Creates an URL object from a string representation within
   * a specified context
   * <p>
   * If the string is not representing an url
   * (i.e. the constructor of the URL fails), then,
   * the methods tries to constructs an URL representing a local file
   * by adding "file:" in front of the parameter string. In this case,
   * the context URL is not used. If the URL creation fails again,
   * then MalformedURLException is returned
   *
   *  @param contextURL  the context in which to parse the specification.
   *  @param string      the sting to parse as an URL
   *
   *  @return            the created URL
   */
  public URL getUrl(URL contextURL, String source)
    throws MalformedURLException {
    URL uri = null;
    try {
      uri = new URL(contextURL, source);
    } 
    catch (MalformedURLException ex) {
      File f = new File(source);
      String addr="file:" + f.getAbsolutePath();
      uri = new URL(addr);
    }
    
    return uri;
  }

  /**
   * Constructs a DOM representation of a XML document accessed throught
   * an input stream
   * <p>
   * Xerces is used as default DOM implementation
   *
   *  @param is          the input source
   *
   *  @return            the created DOM tree
   */
  public Document readDocument(InputStream is)
    throws IOException, SAXException {
    InputSource i = new InputSource(is);
    return readDocument(i);
  }

  /**
   * Constructs a DOM representation of a XML document accessed throught
   * an URL
   * <p>
   * Xerces is used as default DOM implementation
   *
   *  @param is          the input source
   *
   *  @return            the created DOM tree
   */
  public Document readDocument(URL url)
    throws IOException, SAXException {
    InputSource i = new InputSource(url.toString());
    return readDocument(i);
  }

  /**
   * Constructs a DOM representation of a XML document accessed throught
   * a system identified
   * <p>
   * Xerces is used as default DOM implementation
   *
   *  @param is          the input source
   *
   *  @return            the created DOM tree
   */
  public Document readDocument(String systemId)
    throws IOException, SAXException {
    InputSource i = new InputSource(systemId);
    return readDocument(i);
  }
  
  /**
   * Constructs a DOM representation of a XML document accessed throught
   * an input souce
   * <p>
   * Xerces is used as default DOM implementation
   *
   *  @param is          the input source
   *
   *  @return            the created DOM tree
   */
  public Document readDocument(InputSource is)
    throws IOException, SAXException {
    Document doc = null;

    // Using XERCES parser
    DOMParser parser;
    parser = new org.apache.xerces.parsers.DOMParser();
    
    // specifying validation
    boolean validate = false;
    parser.setFeature("http://xml.org/sax/features/validation", validate);
    // specifying nameSpace processing
    boolean nameSpaceProcessing = true;
    parser.setFeature("http://xml.org/sax/features/namespaces", nameSpaceProcessing);
    
    parser.parse(is);
    
    // querying document after parse
    doc = parser.getDocument();

    return doc;
  }
}
