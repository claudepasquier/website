/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

/**
 * An Event representing an editing operation that must be performed on a bean
 *
 * @author Claude Pasquier
 */
public class BeanEditEvent extends java.util.EventObject {

  /**
   * Indicates that a property has to be changed
   */
  public static int CHANGE_PROPERTY = 1;

  /**
   * Indicates that a child has to be removed
   */
  public static int REMOVE_CHILD    = 2;

  /**
   * Indicates that a child has to be added
   */
  public static int ADD_CHILD       = 3;

  /**
   * Indicates that a end is requested
   */
  public static int END             = 4;

  /**
   * The type of the event
   */
  private int    eventType        = 0;

  /**
   * The name of teh property that has to be changed
   */
  private String propertyName     = null;

  /**
   * The old value of the property
   */
  private Object propertyOldValue = null;

  /**
   * The new value of the property
   */
  private Object propertyNewValue = null;

  /**
   * The object that has to bea added or removed
   */
  private Object child            = null;

  /**
   * The position of the child
   */
  private int    childIndex       = 0; //not used

  /**
   * The name of the child that has to be added
   */
  private String childName     = null;

  /**
   *  Constuctor used to create a 'CHANGE_PROPERTY' event
   *
   *  @param o              the event's source
   *  @param eventType      the event's type (should be 'CHANGE_PROPERTY')
   *  @param propertyName   the name of the updated property
   *  @param oldValue       the previous value of the property
   *  @param newValue       the new value of the property
   **/
  public BeanEditEvent(Object o,
                       int eventType,
                       String propertyName,
                       Object oldValue,
                       Object newValue ) {
    super(o);
    this.eventType        = eventType;
    this.propertyName     = propertyName;
    this.propertyOldValue = oldValue;
    this.propertyNewValue = newValue;
  }

  /**
   *  Constuctor used to create a 'END' event
   *
   *  @param o              the event's source
   *  @param eventType      the event's type (should be 'END')
   **/
  public BeanEditEvent(Object o,
                       int    eventType) {
    super(o);
    this.eventType  = eventType;
  }

  /**
   *  Constuctor used to create a 'ADD_CHILD' event
   *
   *  @param o              the event source
   *  @param eventType      the event type (should be 'ADD_CHILD')
   *  @param child          the added child
   *  @param childIndex     the position of the added child
   **/
  public BeanEditEvent(Object o,
                       int    eventType,
                       Object child,
                       int    childIndex) {
    super(o);
    this.eventType  = eventType;
    this.child      = child;
    this.childIndex = childIndex;
  }

  /**
   *  Constuctor used to create a 'ADD_CHILD' or 'REMOVE_CHILD' event
   *
   *  @param o              the event source
   *  @param eventType      the event type
   *  @param child          the added or removed child
   **/
  public BeanEditEvent(Object o,
                       int eventType,
                       Object child) {
    super(o);
    this.eventType  = eventType;

    // child can be either a String specifying the name
    // of the element to add/remove, or an object
    this.child      = child;

  }

  /**
   *  Constuctor used to create a 'REMOVE_CHILD' event
   *
   *  @param o              the event source
   *  @param child          the removed child
   *
   *  @return               the created object 
   **/
  public static BeanEditEvent createRemoveBeanEvent(Object o, Object child) {
    return new BeanEditEvent(o, REMOVE_CHILD, child);
  }

  /**
   *  Constructor used to create a 'CHANGE_PROPERTY' event
   *
   *  @param o              the event source
   *  @param propertyName   the name of the updated property
   *  @param oldValue       the previous value of the property
   *  @param newValue       the new value of the property
   *
   *  @return               the created object 
   **/
  public static BeanEditEvent createChangePropertyEvent(Object o,
                                                        String propertyName,
                                                        Object oldValue,
                                                        Object newValue ) {
    return new BeanEditEvent(o, CHANGE_PROPERTY, propertyName, oldValue, newValue);
  }

  /**
   *  Constructor used to create a 'ADD_CHILD' event
   *
   *  @param o              the event source
   *  @param child          the added child
   *  @param childIndex     the position of the added child
   *
   *  @return               the created object 
   **/
  public static BeanEditEvent createAddChildEvent(Object o,
                                                  Object child,
                                                  int childIndex) {
    return new BeanEditEvent(o, ADD_CHILD, child, childIndex);
  }

  /**
   *  Constructor used to create a 'ADD_CHILD' event
   *
   *  @param o              the event source
   *  @param child          the added child
   *
   *  @return               the created object 
   **/
  public static BeanEditEvent createAddChildEvent(Object o,
                                                  Object child) {
    return new BeanEditEvent(o, ADD_CHILD, child);
  }

  /**
   *  Constructor used to create a 'ADD_CHILD' event
   *
   *  @param o              the event source
   *  @param childName      the name of the child to add
   *
   *  @return               the created object 
   **/
  public static BeanEditEvent createAddChildEvent(Object o,
                                                  String childName) {
    return new BeanEditEvent(o, ADD_CHILD, childName);
  }

  /**
   *  Gets the event type
   **/
  public int getEventType() {
    return eventType;
  }

  /**
   *  Gets the property name
   **/
  public String getPropertyName() {
    return propertyName;
  }

  /**
   *  Gets the property's old value
   **/
  public Object getOldProperty() {
    return propertyOldValue;
  }

  /**
   *  Gets the property's new value
   **/
  public Object getNewProperty() {
    return propertyNewValue;
  }

  /**
   *  Gets the added child
   **/
  public Object getChild() {
    return child;
  }

  /**
   *  Gets the added child's index
   **/
  public int getChildIndex() {
    return childIndex;
  }

  /**
   *  Gets the name of the added child
   **/
  public String getChildName() {
    if (child instanceof String) {
      return (String)child;
    }
    else return null;
  }
}
