/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.event.*;
import javax.swing.event.*;

import org.apache.xalan.xpath.xdom.XercesLiaison;
import org.apache.xerces.dom.*;
import org.apache.xalan.xslt.*;
import org.apache.xalan.xpath.*;
import org.apache.xalan.xpath.xml.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import java.beans.*;
import java.lang.reflect.*;
import XPathAPI;
import XmlUtil;

/**
 * A mapper between XML elements and beans
 *
 * @author Claude Pasquier
 */
public class XBMapper implements BeanEditListener, ActionListener, PropertyChangeListener, ContainerListener, CaretListener {

  /** 
   * Debugging flag
   */
  private static boolean trace = false;
  private static boolean trace1 = false;
  private static boolean trace2 = false;
  private static boolean trace3 = false;

  /**
   * The default namespace for output beans
   **/
  private static String _beansOutputNS = "http://www-sop.inria.fr/lemme/bo/1.0";

  /**
   * The namespace of the XSLT standard
   **/
  private static String _xslOutputNS = "http://www.w3.org/1999/XSL/Transform";

  /**
   * An instance of the xml utilities class
   **/
  private static XmlUtil _xml = new XmlUtil();

  /**
   * The source document
   **/
  private Document _xmlSourceDoc = null;

  /**
   * The source XSLT document
   **/
  private Document _xslSourceDoc = null;

  /**
   * The transformed document
   **/
  private Document _xmlResultDoc = null;

  private String _sourceDocNS = null;

  /**
   * The list of listeners set
   **/
  private Vector _xEditListeners = new Vector();

  /** 
   * The XML document specifying the skeleton to use
   * when creating new elements in the source document
   */
  private Document _skelDoc = null;

  /**
   * The object corresponding to the result document
   */
  private Object _rootBean = null;

  /**
   * The XSLT processor used to perform the transformations
   */
  XSLTProcessor _xsltProc = null;

  /**
   * A compiled version of the stylesheet
   */
  private StylesheetRoot _style = null;

  /**
   * The set of links used to assure the mapping
   */
  private XBLinks _xblinks = null;

  /**
   * Indicates if the class shoud respond to events fired by the beans
   **/
  private boolean _listeningEvents = true;


  /**
   * An instance of the default class loader
   **/
  private static ClassLoader _cl = null;

  static {
    _cl = ClassLoader.class.getClassLoader();
  }

  /**
   * The bean processor used to generate the beans
   **/
  private static BMIncrProcessor _bmProcessor = null;

  /**
   *  Constructs the class given an array of 2 or 3 parameters
   *  if there is two parameters presents, they represents
   *     1- the location of the source XML document
   *     2- the location of the XSLT document
   *
   *  if there is three parameters presents, the third represents :
   *     3- the location of the skeleton document
   *
   *  @param args       the array of parameters
   *
   **/
  XBMapper(String[] args) throws XBException, BMException {
    // parse the arguments
    if ((args.length < 2) || (args.length > 3))
      throw new XBException("incorrect number of parameters in the creation ");

    Document xmlDoc = null;
    Document xslDoc = null;
    Document sklDoc = null;

    try {
      URL uri = _xml.getUrl(args[0]);
      xmlDoc = _xml.readDocument(uri);

      uri = _xml.getUrl(args[1]);
      xslDoc = _xml.readDocument(uri);

      if (args.length == 3) {
        uri = _xml.getUrl(args[2]);
        sklDoc = _xml.readDocument(uri);
      }
    }
    catch (MalformedURLException e) {
      throw new XBException(e.getMessage());
    }
    catch (IOException e) {
      throw new XBException(e.getMessage());
    }
    catch (SAXException e) {
      throw new XBException(e.getMessage());
    }
    init(xmlDoc, xslDoc, sklDoc);
  }

  /**
   *  Constructs the class given a source XML document
   *  and a transformation XSL document
   *
   *  @param sourceDoc  the source XML document
   *  @param xslDoc     the XSL document holding the layout rules
   *
   */
  XBMapper(Document sourceDoc, Document xslDoc) throws XBException, BMException {
    init(sourceDoc, xslDoc, null);
  }

  /**
   *  Constructs the class given a source XML document,
   *  a transformation XSL document and a skeleton
   *
   *  @param sourceDoc  the source XML document
   *  @param xslDoc     the XSL document holding the layout rules
   *  @param skelDoc    the XML document describing the skeletons
   *                        to use during the creation of a new element
   *
   */
  XBMapper(Document sourceDoc, Document xslDoc, Document sklDoc) throws XBException, BMException {
    init(sourceDoc, xslDoc, sklDoc);
  }

  /**
   * The source XML document
   **/
  public Document getXmlDocument() {
    // the document returned is a clone of the source document memorized into
    // the class in which a deletion of extra-added information is removed
    Document sourceDoc = (Document)((Node)_xmlSourceDoc).cloneNode(true);
    removeElementID(sourceDoc,
                    _sourceDocNS,
                    _xblinks.getEltIdName(),
                    "*",
                    "*");
    return sourceDoc;
  }

  /**
   * The root of the generated beans
   **/
  public Object getRootBean() {
    return _rootBean;
  }

  /**
   *  Initializes a new XBMapper object
   *
   *  @param sourceDoc  the source XML document
   *  @param xslDoc     the XSL document holding the layout rules
   *  @param skelDoc    the XML document describing the skeletons
   *                    to use during the creation of a new element
   *
   */
  private void init(Document sourceDoc, Document xslDoc, Document sklDoc) throws XBException, BMException {
    // Initialises links
    if (_xblinks == null) {
      _xblinks = new XBLinks();
    }

    if (_bmProcessor == null) {
      _bmProcessor = new BMIncrProcessor(this, _xblinks);
    }

    _xmlSourceDoc = sourceDoc;
    _sourceDocNS = _xmlSourceDoc.getDocumentElement().getNamespaceURI();
    _xslSourceDoc = xslDoc;
    _skelDoc = sklDoc;

    // add an identifier to each element of the source document
    _xblinks.setEltIdNum(addElementID(_xmlSourceDoc,
                                      _sourceDocNS,
                                      _xblinks.getEltIdName(),
                                      _xblinks.getEltIdPrefix(),
                                      _xblinks.getEltIdNum(),
                                      "*",
                                      "*"));

    // add an identifier to each bo:property element of the xsl document
    addElementID(_xslSourceDoc, _sourceDocNS, "propref", "id", 0, _beansOutputNS, "property");
    // add, in the xsl document, a rule which copy the noderef of the
    // matching node into the generated bean
    addIdCopy(_xslSourceDoc, "bean", false);
    addIdCopy(_xslSourceDoc, "property", true);

    // constructs an XSL processor and memorizes it
    _xsltProc = XSLTProcessorFactory.getProcessor(new XercesLiaison());
    
    // Compiles the stylesheet and memorizes the compiled instance
    try {
      _style = _xsltProc.processStylesheet(new XSLTInputSource(_xslSourceDoc));
      _xsltProc.setStylesheet(_style);
    }
    catch (SAXException se) {
      error("unable to compile the stylesheet. Check the XSLT document");
    }
  }

  /**
   * Applies the transformation represented by the current xslt document to the
   * source document and generates the corresponding bean
   *
   * @return         the created component
   *
   **/
  public Object processBM() throws XBException, BMException {
    return processBM(doTransform());
  }

  /**
   * Applies the transformation represented by the current xsl document to the
   * source document
   *
   * @return       the target document
   *
   **/
  public Document doTransform() throws XBException {
    
    _xmlResultDoc = new DocumentImpl();
    XSLTResultTarget resultTarget = new XSLTResultTarget(_xmlResultDoc);
    
    try {
      // executes stylesheet
      _style.process(new XSLTInputSource(_xmlSourceDoc), resultTarget);
    }
    catch (SAXException se) {
      error("SAX exception occured during document transformation with XSL");
    }
    catch (Exception e) {
      error("exception occured during document transformation with XSL");
    }
    _xmlResultDoc.normalize();
    return _xmlResultDoc;
  }
  
  /**
   * Performs the layout of the beans described by the the parameter
   * bean markup document
   *
   * @param   doc   the bean markup document
   *
   * @return        the created Object
   */
  public Object processBM(Document doc) throws XBException, BMException {
    if (doc == null) return null;
    Element rootElt = doc.getDocumentElement();
    if (rootElt == null) return null;

    if (!rootElt.getTagName().equals("bean")) {
      error("root of a bean markup document must be a '<bean'> tag");
    }
    _listeningEvents = false;
    _rootBean = _bmProcessor.processBM(doc, null);
    _listeningEvents = true;
    return _rootBean;
  }

  /**
   * Adds on every selected elements of the document an attribute
   * representing its unique identifier. The name of the attribute
   * and the prefix used to identify the element are specified
   * (id value are computed by putting a number after the prefix name.
   * The name of the elements to consider is specified by eltNamespaceURI
   * and selectedEltName
   *
   *  @param doc             the document to process
   *  @param namespaceURI    the namespace of the attribute
   *  @param attName         the name of the attribute to add
   *  @param attPrefix       the prefix used to identify the node
   *  @param attNum          the number to use to name the first node
   *  @param eltNamespaceURI the namespace of the selected elements
   *  @param selectedEltName the name of the elements to process
   *
   *  @return                the number of nodes named
   */
  private int addElementID(Document doc,
                           String   attNamespaceURI,
                           String   attName,
                           String   attPrefix,
                           int      attNum,
                           String   eltNamespaceURI,
                           String   selectedEltName) {
    Element rootElt = doc.getDocumentElement();
    return addElementID(rootElt, attNamespaceURI, attName, attPrefix, attNum, eltNamespaceURI, selectedEltName);
  }

  /**
   * Adds on every selected elements of the descendand of rootElt,  an attribute
   * representing its unique identifier. The name of the attribute
   * and the prefix used to identify the element are specified
   * (id value are computed by putting a number after the prefix name.
   * The name of the elements to consider is specified by eltNamespaceURI
   * and selectedEltName
   *
   *  @param rootElt         the element where to start the processing
   *  @param namespaceURI    the namespace of the attribute
   *  @param attName         the name of the attribute to add
   *  @param attPrefix       the prefix used to identify the node
   *  @param attNum          the number to use to name the first node
   *  @param eltNamespaceURI the namespace of the selected elements
   *  @param selectedEltName the name of the elements to process
   *
   *  @return                the number of nodes named
   */
  private int addElementID(Element   rootElt,
                           String   attNamespaceURI,
                           String   attName,
                           String   attPrefix,
                           int      attNum,
                           String   eltNamespaceURI,
                           String   selectedEltName) {
    if (attNamespaceURI == null) {
      if ("*".equals(selectedEltName) || rootElt.getTagName().equals(selectedEltName)) {
        if (rootElt.getAttributeNode(attName) == null) {
          Attr att = rootElt.getOwnerDocument().createAttribute(attName);
          String nodeRef = attPrefix + new Integer(attNum++).toString();
          att.setValue(nodeRef);
          rootElt.setAttributeNode(att);
        }
      }
      NodeList nList = rootElt.getElementsByTagNameNS(eltNamespaceURI, selectedEltName);
      for (int i = 0 ; i < nList.getLength() ; i++) {
        Element elt = (Element)nList.item(i);
        if (elt.getAttributeNode(attName) == null) {
          Attr att = rootElt.getOwnerDocument().createAttribute(attName);
          String nodeRef = attPrefix + new Integer(attNum++).toString();
          att.setValue(nodeRef);
          elt.setAttributeNode(att);
        }
      }
    }
    else {
      if ("*".equals(selectedEltName) || rootElt.getTagName().equals(selectedEltName)) {
        if (rootElt.getAttributeNodeNS(attNamespaceURI, attName) == null) {
          Attr att = rootElt.getOwnerDocument().createAttributeNS(attNamespaceURI, attName);
          String nodeRef = attPrefix + new Integer(attNum++).toString();
          att.setValue(nodeRef);
          rootElt.setAttributeNodeNS(att);
        }
      }
      NodeList nList = rootElt.getElementsByTagNameNS(eltNamespaceURI, selectedEltName);
      for (int i = 0 ; i < nList.getLength() ; i++) {
        Element elt = (Element)nList.item(i);
        if (elt.getAttributeNodeNS(attNamespaceURI, attName) == null) {
          Attr att = rootElt.getOwnerDocument().createAttributeNS(attNamespaceURI, attName);
          String nodeRef = attPrefix + new Integer(attNum++).toString();
          att.setValue(nodeRef);
          elt.setAttributeNodeNS(att);
        }
      }
    }
    return attNum;
  }
  
  /**
   * Removes on every selected elements of the document the attribute
   * representing its unique identifier. The name of the attribute
   * and the prefix used to identify the element are specified
   * by namespaceURI and attName
   * The name of the elements to consider is specified by eltNamespaceURI
   * and selectedEltName
   *
   *  @param doc             the document to process
   *  @param namespaceURI    the namespace of the attribute
   *  @param attName         the name of the attribute to add
   *  @param eltNamespaceURI the namespace of the selected elements
   *  @param selectedEltName the name of the elements to process
   *
   */
  private void removeElementID(Document doc,
                            String   attNamespaceURI,
                            String   attName,
                            String   eltNamespaceURI,
                            String   selectedEltName) {
    Element rootElt = doc.getDocumentElement();
    removeElementID(rootElt, attNamespaceURI, attName, eltNamespaceURI, selectedEltName);
  }

  /**
   * Removes on every selected elements of the descendants of rootElt, the attribute
   * representing its unique identifier. The name of the attribute
   * and the prefix used to identify the element are specified.
   * by namespaceURI and attName
   * The name of the elements to consider is specified by eltNamespaceURI
   * and selectedEltName
   *
   *  @param rootElt         the element where to start the processing
   *  @param namespaceURI    the namespace of the attribute to remove
   *  @param attName         the name of the attribute to remove
   *  @param eltNamespaceURI the namespace of the selected elements
   *  @param selectedEltName the name of the elements to process
   *
   */
  private void removeElementID(Element  rootElt,
                               String   attNamespaceURI,
                               String   attName,
                               String   eltNamespaceURI,
                               String   selectedEltName) {

    if ("*".equals(selectedEltName) || rootElt.getTagName().equals(selectedEltName)) {
      Attr attrib = null;
      if (attNamespaceURI != null) {
        attrib = rootElt.getAttributeNodeNS(attNamespaceURI, attName);
      }
      else {
        attrib = rootElt.getAttributeNode(attName);
      }
      if (attrib != null) {
        rootElt.removeAttributeNode(attrib);
      }
    }
    NodeList nList = null;
    if (eltNamespaceURI != null) {
      nList = rootElt.getElementsByTagNameNS(eltNamespaceURI, selectedEltName);
    }
    else {
      nList = rootElt.getElementsByTagName(selectedEltName);
    }

    for (int i = 0 ; i < nList.getLength() ; i++) {
      Element elt = (Element)nList.item(i);
      Attr attrib = null;
      if (attNamespaceURI != null) {
        attrib = elt.getAttributeNodeNS(attNamespaceURI, attName);
      }
      else {
        attrib = elt.getAttributeNode(attName);
      }

      if (attrib != null) {
        elt.removeAttributeNode(attrib);
      }
    }
  }
  
  /**
   * Adds under each element with a name equals to 'eltName'
   * an attribute which reflects the unique identifier of the 
   * matched source element
   *
   *  @param doc            the document to process
   *  @param eltName        the name of elements to process
   *  @param addTest        Indicates if a test must be made to copy
   *                        the id of the parent if the matched node
   *                        has no ID
   *
   **/
  private void addIdCopy(Document doc, String eltName, boolean addTest) {
    NodeList nList = ((DocumentImpl)doc).getElementsByTagNameNS(_beansOutputNS, eltName);
    for (int i = 0 ; i < nList.getLength() ; i++) {
      ElementNSImpl elt = (ElementNSImpl)nList.item(i);
      // retrieves the prefix associated with xsl namespace
      // by looking at the prefix used in the ancestor nodes
      Element el = elt;
      while (!el.getNamespaceURI().equals(_xslOutputNS)) {
        el = (Element)el.getParentNode();
        if (el == null) {
          System.err.println("Error xsl namespace is not specified");
          System.exit(0);
          // (an exception should be raised when reading the stylesheet)
        }
      }
      String xslPrefix = ((ElementNSImpl)el).getPrefix();

      // Adds, an attribute creation rule which will contain the noderef
      // of the matched element
      Element addedElt = doc.createElementNS(_xslOutputNS, xslPrefix+":attribute");
      Attr att = doc.createAttributeNS(_xslOutputNS, "name");
      att.setValue(_xblinks.getEltIdName());
      addedElt.setAttributeNodeNS(att);
      if (!addTest) {
        Element valueOfElt = doc.createElementNS(_xslOutputNS, xslPrefix+":value-of");
        att = doc.createAttribute("select");
        att.setValue("./@"+_xblinks.getEltIdName());
        valueOfElt.setAttributeNodeNS(att);
        addedElt.appendChild(valueOfElt);
      }
      else {
        // conditional copy of noderef
        Element chooseElt = doc.createElementNS(_xslOutputNS, xslPrefix+":choose");
        addedElt.appendChild(chooseElt);
        Element whenElt = doc.createElementNS(_xslOutputNS, xslPrefix+":when");
        att = doc.createAttribute("test");
        att.setValue("./@"+_xblinks.getEltIdName());
        whenElt.setAttributeNodeNS(att);
        chooseElt.appendChild(whenElt);
        
        Element otherwiseElt = doc.createElementNS(_xslOutputNS, xslPrefix+":otherwise");
        chooseElt.appendChild(otherwiseElt);
        
        Element valueOfWhen = doc.createElementNS(_xslOutputNS, xslPrefix+":value-of");
        att = doc.createAttribute("select");
        att.setValue("./@"+_xblinks.getEltIdName());
        valueOfWhen.setAttributeNodeNS(att);
        whenElt.appendChild(valueOfWhen);

        Element valueOfOtherwise = doc.createElementNS(_xslOutputNS, xslPrefix+":value-of");
        att = doc.createAttribute("select");
        att.setValue("../@"+_xblinks.getEltIdName());
        valueOfOtherwise.setAttributeNodeNS(att);
        otherwiseElt.appendChild(valueOfOtherwise);
        otherwiseElt.appendChild(doc.createTextNode("/"));
        valueOfOtherwise = doc.createElementNS(_xslOutputNS, xslPrefix+":value-of");
        att = doc.createAttribute("select");
        att.setValue("position()");
        valueOfOtherwise.setAttributeNodeNS(att);
        otherwiseElt.appendChild(valueOfOtherwise);
      }

      elt.insertBefore(addedElt, elt.getFirstChild());
    }
  }

  /**
   * Registers a mapping between a source node and a corresponding bean object
   * <p>
   * the mapping is made between the object and the XPath
   * representing the source element
   *
   * @param node   the source node
   * @param obj    the object to register
   **/
  private void register(Node node, TypedObject obj) {
    if ((obj != null) && ("bean".equals(node.getNodeName()))) {
      _xblinks.putMappingEltBean(XPathUtil.computeXPath(null, node), obj);
    }
  }


  // Event Handlers implemented by default in the XBMapper

  /**
   * called when a event of type caret is fired
   *
   *  @param evt            the fired event
   **/
  public void caretUpdate(CaretEvent evt) {
    reflectBeanUpdate(evt.getSource());
  }

  /**
   * called when a event of type beanEdit is fired
   *
   *  @param evt            the fired event
   **/
  public void beanEditPerformed(BeanEditEvent evt) {
    if (trace2) {
      System.err.println("<CP> bean edit performed has intercepted this");
      System.err.println("<CP> eventType = "+evt.getEventType());
      System.err.println("<CP> _listeningEvents = "+_listeningEvents);
    }
    if (!_listeningEvents) return;
    if (trace2) {
      System.err.println("<CP>in BeanFormat: beansEditPerformed");
      System.err.println("<CP prop name="+evt.getSource());
      System.err.println("<CP oldValue="+evt.getChild());
    }

    if (evt.getEventType() == BeanEditEvent.END) {
      notifyXEditPerformed(null, XEditEvent.END);
      return;
    }
    if (evt.getEventType() == BeanEditEvent.CHANGE_PROPERTY) {
      if (_listeningEvents) {
        String pName = evt.getPropertyName();
        if ((pName == null) || !"".equals(pName)) {
          reflectBeanUpdate(evt.getSource());
        }
        else {
          PropertyChangeEvent pcEvent = new PropertyChangeEvent(evt.getSource(),
                                                                pName,
                                                                evt.getOldProperty(),
                                                                evt.getNewProperty());
          if (processPropertyChange(pcEvent)) {
            //cpadd
            try {
              updateBeans(pcEvent);
            }
            catch (XBException e) {
              System.err.println("Error: "+e.getMessage());
            }
          }
        }
      }
      return;
    }
    
    // retrieves the bean that fired the event
    Object sourceObj = evt.getSource();

    // retrieves the corresponding element ID
    String nodeRef = _xblinks.getMappingNodeRef(sourceObj);

    // retrieves the corresponding element into the sourceDocument
    Node sourceNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), nodeRef);

    if (trace2) {
      System.err.println("<CP> the source object is of type : "+sourceObj);
      System.err.println("<CP> we know now the ref of the source elt: "+nodeRef);
      System.err.println("<CP> the corresponding node is: "+sourceNode);
    }

    // retrieves the bean that has been added or removed
    Object childObj= evt.getChild();

    if (trace) {
      System.err.println("<CP> added component: "+childObj);
    }

    if (evt.getEventType() == BeanEditEvent.REMOVE_CHILD) {
      // retrieves ID corresponding to the removed component
      String childNodeRef = _xblinks.getMappingNodeRef(childObj);
      // retrieves the corresponding element into the sourceDocument
      Node sourceChildNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), childNodeRef);

      // remove the element
      sourceNode.removeChild(sourceChildNode);
      try {
        updateBeans(null);
      }
      catch (XBException e) {
        e.printStackTrace();
      }
      notifyXEditPerformed(sourceChildNode, XEditEvent.REMOVED);
      return;
    }

    // The name of the element to insert into the source document is found either:
    // by looking at the name of the added component,
    // or by seaching in the xsl specification for a template rule which generates
    // a bean of a class equal to the added component

    String addedEltName = evt.getChildName();
    if (addedEltName == null) {
      String className = childObj.getClass().getName();
      NodeList nList = ((DocumentImpl)_xslSourceDoc).getElementsByTagNameNS(_beansOutputNS, "bean");
      Vector beanTagFound = new Vector();
      for (int i = 0 ; i < nList.getLength() ; i++) {
        ElementNSImpl elt = (ElementNSImpl)nList.item(i);
        if (!className.equals(elt.getAttribute("class"))) continue;
        beanTagFound.addElement(new Integer(i));
      }
      if (beanTagFound.size() == 0) {
        System.err.print("Unable to find a xsl rule which generates");
        System.err.println(" a bean of class: "+className);
        return;
      }
      if (beanTagFound.size() > 1) { //several rules are able to generate the bean
        for (int i = 0 ; i < beanTagFound.size() ; i++) {
          int index = ((Integer)beanTagFound.elementAt(i)).intValue();
          Element parentNode = (Element)nList.item(index).getParentNode();
          if (!"template".equals(parentNode.getLocalName()) ||
              !_xslOutputNS.equals(parentNode.getNamespaceURI())) {
            beanTagFound.removeElementAt(i);
          }
        }
        if (beanTagFound.size() == 0) {
          System.err.print("Unable to find a unique xsl rule which generates");
          System.err.println("a bean of class: "+className);
          return;
        }
        if (beanTagFound.size() > 1) {
          System.err.print("Unable to find a unique xsl rule which generates");
          System.err.println("a bean of class: "+className);
          return;
        }
      }
      int indexMatchedNode = ((Integer)beanTagFound.elementAt(0)).intValue();
      Node matchedNode = nList.item(indexMatchedNode);
      Node n = matchedNode.getParentNode();
      while ((n != null) &&
             (!"template".equals(n.getLocalName()) ||
              !_xslOutputNS.equals(n.getNamespaceURI()))) {
        n = n.getParentNode();
      }
      if (n == null) {
        System.err.print("Unable to find a unique xsl rule which generates");
        System.err.println("a bean of class: "+className);
        return;
      }
      addedEltName = ((Element)n).getAttribute("match");
      if (addedEltName == null) {
        System.err.print("Unable to find a unique xsl rule which generates");
        System.err.println("a bean of class: "+className);
        return;
      }
    }

    //<CP> the code below is to perform an insertion in the middle
    // of a list of childs (for the moment, this possibility is removed)
    // retrieves next sibling of the added node
//     int indexComp = evt.getChildIndex();
//     java.awt.Component[] compList = container.getComponents();
  
//     if (indexComp == -1) {
//       System.err.println("Unable to retrieve the added component into the bean");
//       return;
//     }
    
//     String nextNodeRef = null;
//     while (nextNodeRef == null) {
//       if (indexComp < compList.length - 1) indexComp++;
//       else break;

//       // retrieves the corresponding element ID
//       nextNodeRef = _xblinks.getMappingNodeRef(compList[indexComp]);

//       // discard the case where the component is not linked
//       // to an element from the source document
//       if (nodeRef.equals(nextNodeRef)) {
//         nextNodeRef = null;
//       }
//     }
//     if (trace) {
//       System.err.println("<CP> nextNodeRef="+nextNodeRef);
//     }

//     // retrieves the corresponding element into the sourceDocument
//     Node nextNode = null;
//     if (nodeRef != null) {
//       nextNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), nextNodeRef);
//     }
    //<CP> end of code relative to tha insertion of an element
    // into a list of childs

    // create a new element with the name of the added component,
    // using the skeleton if specified
    Element newElement = null;
    if (trace) {
      System.err.println("<CP> skeleton ="+_skelDoc);
    }
    if (_skelDoc != null) {
      NodeList nodeList = _skelDoc.getDocumentElement().getChildNodes();
      for (int i = 0 ; i < nodeList.getLength() ; i++) {
        Node node = nodeList.item(i);
        if (node.getNodeType() != Node.ELEMENT_NODE) continue;
        Element elt = (Element)node;
        if (!addedEltName.equals(elt.getTagName())) continue;
        newElement = (Element)elt.cloneNode(true);
        break;
      }
    }
    if (newElement == null) {
      newElement = _xmlSourceDoc.createElement(addedEltName);
    }

    //Element newSElement = (Element)_xmlSourceDoc.importNode(newElement, true);
    _xblinks.setEltIdNum(addElementID(newElement,
                                      _sourceDocNS,
                                      _xblinks.getEltIdName(),
                                      _xblinks.getEltIdPrefix(),
                                      _xblinks.getEltIdNum(),
                                      "*",
                                      "*"));
    
    // insert the element into the source tree
    //    sourceNode.insertBefore(newSElement, nextNode);
    newElement = (Element)_xmlSourceDoc.importNode(newElement, true);
    sourceNode.appendChild(newElement);
    if (trace) {
      System.err.println("<CP> a node "+addedEltName+" has been added");
    }
    _listeningEvents = false;
    //    evt.getContainer().remove(evt.getChild());
    _listeningEvents = true;

      try {
        updateBeans(null);
      }
      catch (XBException e) {
        e.printStackTrace();
      }
    notifyXEditPerformed(newElement, XEditEvent.ADDED);
  }

  /**
   * called when a event of type action is fired
   *
   *  @param evt            the fired event
   **/
  public void actionPerformed(ActionEvent evt) {
    Object source = evt.getSource();
    reflectBeanUpdate(source);
  }

  /**
   *  Default processing when a property has changed
   *
   *  @param evt            the fired event
   **/
  public void propertyChange(PropertyChangeEvent evt) {
    if (trace1) {      
      System.err.println("<CP> PropertyChangeEvent called");;
      System.err.println("<CP>      source="+evt.getSource());
      System.err.println("<CP>   prop name="+evt.getPropertyName());
    }      
    if (_listeningEvents) {
      if (processPropertyChange(evt)) {
        //cpadd
        try {
          updateBeans(evt);
        }
        catch (XBException e) {
          System.err.println("Error: "+e.getMessage());
        }
      }
    }
  }

  /**
   * Performs the updates in the source document when an
   * event of type propertyChange has been received
   *
   *  @param evt            the fired event
   **/
  private boolean processPropertyChange(PropertyChangeEvent evt) {
    return processPropertyChange(evt, null);
  }

  /**
   * Performs the updates in the source document when an
   * event of type propertyChange has been received
   * <p>
   * If indexp is not null, the property is considered as an
   * indexed property and indexp indicates its position
   *
   *  @param evt            the fired event
   *  @param indexp         the index of the property if it's an indexed one
   **/
  private boolean processPropertyChange(PropertyChangeEvent evt,
                                        Integer indexp) {
    if (!_listeningEvents) return false;
    // don't process event when the ancestor is changed
    // (this event is handled by componentAdded or ComponentRemoved event listeners
    //  of the ancestor)
    //    if (evt.getPropertyName().equals("ancestor")) return;
    if (trace) {
      if (evt.getPropertyName().equals("ancestor"))
        System.err.println("<CP> ANCESTOREVENT");;
      System.err.println("<CP>in xmlEdit: property value changed");
      System.err.println("<CP prop name="+evt.getPropertyName());
    
      System.err.println("<CP oldValue="+evt.getOldValue());
      System.err.println("<CP newValue="+evt.getNewValue());
      System.err.println("<CP source="+evt.getSource());
    }
    if (evt.getPropertyName().equals("ancestor")) return false;

    // retrieves the bean that fired the event
    Object obj = evt.getSource();
    if (trace1) {
      System.err.println("<CP> source="+obj);
    }
    // retrieves the corresponding element ID
    String nodeRef = _xblinks.getMappingNodeRef(obj);

    if (trace) {
      System.err.println("<CP> we know now the ref of the source bean: "+nodeRef);
    }


    // retrieves the Id of the property instruction corresponding to the
    // modified property
    //    String propRef = (String)_mappingProp.get(nodeRef+"."+evt.getPropertyName());
    Hashtable hTable = _xblinks.getMappingProp(obj);
    String propRef = (String)hTable.get(evt.getPropertyName());
    if (trace) {
      System.err.println("<CP> retrieving property="+nodeRef+"."+evt.getPropertyName());
      System.err.println("<CP> property name="+evt.getPropertyName());
      System.err.println("<CP> propertyref="+propRef);
    }

    // retrieves the source node corresponding to the property
    String propNodeRef = _xblinks.getMappingSourceNode(nodeRef+"."+evt.getPropertyName());
    // retrieves the corresponding element into the sourceDocument
    Node sourcePNode = _xml.getEltByAttValue(_xmlSourceDoc,
                                             _xblinks.getEltIdName(),
                                             propNodeRef);
    if (trace) {
      System.err.println("<CP> we know now the ref of the source node of the prop: "+propNodeRef);
      System.err.println("<CP> the corresponding node is: "+sourcePNode);
      //      serialize(_xmlSourceDoc);
    }

    boolean changeDone = false;
    if (indexp != null) {
      propNodeRef = _xblinks.getMappingSourceNode(nodeRef+"."+evt.getPropertyName()+"/"+indexp.intValue());
      if (propNodeRef == null) {
        System.err.println("error, property '"
                           + evt.getPropertyName()
                           + "' not retrieved ");
      }
      if (propNodeRef.lastIndexOf('/') > -1) {
        String propId = propNodeRef.substring(0, propNodeRef.lastIndexOf('/'));
        sourcePNode = _xml.getEltByAttValue(_xmlSourceDoc,
                                            _xblinks.getEltIdName(),
                                            propId);
        int index = new Integer(propNodeRef.substring(propNodeRef.lastIndexOf('/')+1)).intValue();
        sourcePNode = sourcePNode.getChildNodes().item(index-1);
        if (trace2) {
          System.err.println("<CP> indexed prop: the source node of the prop= "+propNodeRef);
          System.err.println("<CP> node="+propId+" index="+index);
          System.err.println("<CP> the corresponding node is: "+sourcePNode);
        }
      }
      else {
        sourcePNode =  _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), propNodeRef);
      }
      changeDone = processPropertyChange(sourcePNode, propRef, evt.getNewValue(), true);
    }
    else if (propNodeRef == null) {   // this is an indexed property
      // special processing in the case of indexed property
      Object[] newV = (Object[])evt.getNewValue();
      Object[] oldV = (Object[])evt.getOldValue();
      if (trace) {
        System.err.println("<CP> oldV = "+oldV);
        System.err.println("<CP> newV = "+newV);
      }
      for (int i = 0 ; i < newV.length ; i++) {
         // process each indexed value
        if ((oldV != null) && (oldV[i] != null) && (oldV[i].equals(newV[i]))) continue;
        propNodeRef = _xblinks.getMappingSourceNode(nodeRef+"."+evt.getPropertyName()+"/"+i);
        if (trace) {
          System.err.println("<CP> indexedProp. Source node= "+propNodeRef);
        }
        if (propNodeRef == null) continue; // there is no corresponding node
                                           // in the source doc
        if (propNodeRef.lastIndexOf('/') > -1) {
          String propId = propNodeRef.substring(0, propNodeRef.lastIndexOf('/'));
          sourcePNode = _xml.getEltByAttValue(_xmlSourceDoc,
                                              _xblinks.getEltIdName(),
                                              propId);
          int index = new Integer(propNodeRef.substring(propNodeRef.lastIndexOf('/')+1)).intValue();
          sourcePNode = sourcePNode.getChildNodes().item(index-1);
          if (trace) {
            System.err.println("<CP> indexed prop: the source node of the prop= "+propNodeRef);
            System.err.println("<CP> node="+propId+" index="+index);
            System.err.println("<CP> the corresponding node is: "+sourcePNode);
          }
        }
        else {
          sourcePNode =  _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), propNodeRef);
        }
        changeDone = processPropertyChange(sourcePNode, propRef, newV[i], true);
      }
    }
    else {
      changeDone = processPropertyChange(sourcePNode, propRef, evt.getNewValue(), true);
    }
    //cpadd
    //            updateBeans(evt);
    return changeDone;
  }
 
  /**
   * Performs the updates in the source document when an
   * event of type propertyChange has been received
   *
   *  @param sourceNode     the node for which a property has been changed
   *  @param propRef        the identifier of the property
   *  @val   val            the bean corresponding to the source node
   *  @notifyEvent          a boolean to indicate if the change has to be notified
   *                        to XEdit listeners (true=yes, false=no)
   **/
  private boolean processPropertyChange(Node sourceNode, String propRef, Object val, boolean notifyEvent) {

    if (trace) {
      System.err.println("<CP> processing propertyChange");
      System.err.println("<CP>       node="+sourceNode);
      System.err.println("<CP>   propRef="+propRef);
      System.err.println("<CP>        val="+val);
    }
    // retrieves the node corresponding to the property in xml document
    Node nd = _xml.getEltByAttValue(_xslSourceDoc, "propref", propRef);
    
    if (trace) {
      System.err.println("<CP> we know the ref of the rule: "+propRef);
      System.err.println("<CP> the corresponding node is: "+nd);
    }

    // gets the XPath specifying the location of the property in the source document
    int nbElt = 0;
    Element valueOfElt = null;
    NodeList nList = ((Element)nd).getChildNodes();
    for (int i = 0 ; i < nList.getLength() ; i++) {
      Node n = nList.item(i);
      if (n.getNodeType() != Node.ELEMENT_NODE) continue;
      Element el = (Element)n;
      if (trace) {
        System.err.println("<CP> valueOf="+n);
      }
      if (!"cast".equals(el.getTagName()) && !"string".equals(el.getTagName())) continue;
      if (nbElt == 0) valueOfElt = el;
      nbElt += 1;
    }
    // <CP>TODO there can be a fixed text node here
    //     everything into an attribute must be ignored
    //     study the processing to do for each case
    if (nbElt > 1) {
      System.err.println("Warning. multiple value in a property");
    }
    if (valueOfElt == null) return false;
    NodeList valueList = valueOfElt.getElementsByTagNameNS(_xslOutputNS,"value-of");
    nbElt = valueList.getLength();
    if (nbElt > 1) {
      System.err.println("Warning. multiple 'value-of' elements in a property");
    }
    if (nbElt == 0) return false;


    // converts the value into string
    TypeConvertor tc = new TypeConvertor();
    String s = new String();
    Object value = tc.convert(val, new String().getClass());

    valueOfElt = (Element)valueList.item(0);
    String xPathExp = valueOfElt.getAttribute("select");

    // applies the XPath to the source node representing the bean
    // to retrieve the node where the property is specified
    Node propNode = null;
    try {
      propNode = XPathAPI.selectSingleNode(sourceNode, xPathExp);
    }
    catch (SAXException se) {
      se.printStackTrace();
    }

    if (trace) {
      System.err.println("<CP> Xpath expression = "+xPathExp);
      System.err.println("<CP> propNode = "+propNode);
    }

    // the property node can be an attribute node, an element node or a text node
    // If it is an element node, one has to modify the text value of the node
    // ==> we get the first child of the element (that should be a text node)
    // 
    // If the property is an attribute node or a text node,
    // sets accordingly the property value into the source document
    if (propNode.getNodeType() == Node.ELEMENT_NODE) {
      Node pNode = propNode.getFirstChild();
      if (pNode == null) {
        Node tNode = propNode.getOwnerDocument().createTextNode("");
        propNode.appendChild(tNode);
        propNode = tNode;
      }
      else if (pNode.getNodeType() != Node.TEXT_NODE) {
        System.err.print("Error. unable to change the value of the element ");
        System.err.println(((Element)propNode).getTagName());
        System.exit(0);
      }
      else {
        propNode = pNode;
      }
    }
    boolean changeDone = false;
    if (propNode.getNodeType() == Node.TEXT_NODE) {
      //      ((Text)propNode).setData((String)evt.getNewValue());
      if (!((Text)propNode).getData().equals((String)value)) {
        changeDone = true;
        if (trace) {
          System.err.println("<CP> initialVal="+((Text)propNode).getData()+"<<<");
          System.err.println("<CP> newVal    ="+((String)value)+"<<<");
          System.err.println("<CP> initialValLen="+((Text)propNode).getData().length());
          System.err.println("<CP> newValLen    ="+((String)value).length());
        }

        ((Text)propNode).setData((String)value);
      }
    }
    else if (propNode.getNodeType() == Node.ATTRIBUTE_NODE) {

      if (!((Attr)propNode).getValue().equals((String)value)) {
        changeDone = true;
        ((Attr)propNode).setValue((String)value);
      }
    }
    // notifies the change to the listeners
    if (trace) {
      System.err.println("<CP> change done");
    }
    if (changeDone && notifyEvent) notifyXEditPerformed(propNode, XEditEvent.CHANGED);
    if (trace) {
      if (notifyEvent) System.err.println("<CP> propNode = "+propNode);
    }
    return changeDone;
  }

  /**
   *  Default processing when a component has been changed
   *
   *  @param evt            the fired event
   **/
  public void componentAdded(ContainerEvent evt) {
    try {
    if (!_listeningEvents) return;
    if (trace) {
      System.err.println("<CP>in BeanFormat: component added");
      System.err.println("<CP prop name="+evt.getContainer());
      System.err.println("<CP oldValue="+evt.getChild());
    }

    // retrieves the bean that fired the event
    java.awt.Container container = evt.getContainer();

    // retrieves the corresponding element ID
    String nodeRef = _xblinks.getMappingNodeRef(container);

    // retrieves the corresponding element into the sourceDocument
    Node sourceNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), nodeRef);

    if (trace) {
      System.err.println("<CP> we know now the ref of the source elt: "+nodeRef);
      System.err.println("<CP> the corresponding node2 is: "+sourceNode);
    }

    // retrieves the bean that has been added
    java.awt.Component addedComponent= evt.getChild();
    if (trace) {
      System.err.println("<CP> added component: "+addedComponent);
      System.err.println("<CP> name of added component: "+addedComponent.getName());
    }

    // The name of the element to insert into the source document is found either:
    // by looking at the name of the added component,
    // or by seaching in the xsl specification for a template rule which generates
    // a bean of a class equal to the added component
    String addedEltName = addedComponent.getName();
    if (addedEltName == null) {
      String className = addedComponent.getClass().getName();
      NodeList nList = ((DocumentImpl)_xslSourceDoc).getElementsByTagNameNS(_beansOutputNS, "bean");
      Vector beanTagFound = new Vector();
      for (int i = 0 ; i < nList.getLength() ; i++) {
        ElementNSImpl elt = (ElementNSImpl)nList.item(i);
        if (!className.equals(elt.getAttribute("class"))) continue;
        beanTagFound.addElement(new Integer(i));
      }
      if (beanTagFound.size() == 0) {
        error("unable to find a unique xsl rule which generates"
              + " a bean of class: " + className);
        return;
      }
      if (beanTagFound.size() > 1) { //several rules are able to generate the bean
        for (int i = 0 ; i < beanTagFound.size() ; i++) {
          int index = ((Integer)beanTagFound.elementAt(i)).intValue();
          Element parentNode = (Element)nList.item(index).getParentNode();
          if (!"template".equals(parentNode.getLocalName()) ||
              !_xslOutputNS.equals(parentNode.getNamespaceURI())) {
            beanTagFound.removeElementAt(i);
          }
        }
        if (beanTagFound.size() == 0) {
          error("unable to find a unique xsl rule which generates"
                + " a bean of class: " + className);
          return;
        }
        if (beanTagFound.size() > 1) {
          error("unable to find a unique xsl rule which generates"
                + " a bean of class: " + className);
          return;
        }
      }
      int indexMatchedNode = ((Integer)beanTagFound.elementAt(0)).intValue();
      Node matchedNode = nList.item(indexMatchedNode);
      Node n = matchedNode.getParentNode();
      while ((n != null) &&
             (!"template".equals(n.getLocalName()) ||
              !_xslOutputNS.equals(n.getNamespaceURI()))) {
        n = n.getParentNode();
      }
      if (n == null) {
        error("unable to find a unique xsl rule which generates"
              + " a bean of class: " + className);
        return;
      }
      addedEltName = ((Element)n).getAttribute("match");
      if (addedEltName == null) {
        error("unable to find a unique xsl rule which generates"
              + " a bean of class: " + className);
        return;
      }
    }

    // retrieves next sibling of the added node
    int indexComp = -1;
    java.awt.Component[] compList = container.getComponents();
    for (int i = 0 ; i < compList.length ; i++) {
      if (compList[i] != addedComponent) continue;
      indexComp = i;
      break;
    }
  
    if (indexComp == -1) {
      System.err.println("Unable to retrieve the added component into the bean");
      return;
    }
    
    String nextNodeRef = null;
    while (nextNodeRef == null) {
      if (indexComp < compList.length - 1) indexComp++;
      else break;

      // retrieves the corresponding element ID
      nextNodeRef = _xblinks.getMappingNodeRef(compList[indexComp]);

      // discard the case where the component is not linked
      // to an element from the source document
      if (nodeRef.equals(nextNodeRef)) {
        nextNodeRef = null;
      }
    }

    // retrieves the corresponding element into the sourceDocument
    Node nextNode = null;
    if (nodeRef != null) {
      nextNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), nextNodeRef);
    }

    // create a new element with the name of the added component,
    // using the skeleton if specified
    Element newElement = null;
    if (trace) {
      System.err.println("<CP> skeleton ="+_skelDoc);
    }
    if (_skelDoc != null) {
      NodeList nodeList = _skelDoc.getDocumentElement().getChildNodes();
      for (int i = 0 ; i < nodeList.getLength() ; i++) {
        Node n = nodeList.item(i);
        if (n.getNodeType() != Node.ELEMENT_NODE) continue;
        Element elt = (Element)n;
        if (!addedEltName.equals(elt.getTagName())) continue;
        newElement = (Element)elt.cloneNode(true);
        break;
      }
    }
    if (newElement == null) {
      newElement = _xmlSourceDoc.createElement(addedEltName);
    }

    Element newSElement = (Element)_xmlSourceDoc.importNode(newElement, true);
    _xblinks.setEltIdNum(addElementID(newSElement,
                                      _sourceDocNS,
                                      _xblinks.getEltIdName(),
                                      _xblinks.getEltIdPrefix(),
                                      _xblinks.getEltIdNum(),
                                      "*",
                                      "*"));

    // insert the element into the source tree
    sourceNode.insertBefore(newSElement, nextNode);
    if (trace) {
      System.err.println("<CP> a node "+addedEltName+" has been added");
    }
    _listeningEvents = false;
    evt.getContainer().remove(evt.getChild());
    _listeningEvents = true;


    updateBeans(null);
    notifyXEditPerformed(newSElement, XEditEvent.ADDED);
    }
    catch (XBException e) {
      e.printStackTrace();
    }
  }

  /**
   *  Default processing when a component has been removed
   *
   *  @param evt            the fired event
   **/
  public void componentRemoved(ContainerEvent evt) {
    if (!_listeningEvents) return;
    if (trace2) {
      System.err.println("<CP> Event 'component removed' received");
      System.err.println("<CP>in BeanFormat: component removed");
      System.err.println("<CP prop name="+evt.getContainer());
      System.err.println("<CP oldValue="+evt.getChild());
    }

    // retrieves the bean that fired the event
    Object sourceBean = evt.getChild();

    // retrieves the corresponding element ID
    String nodeRef = _xblinks.getMappingNodeRef(sourceBean);

    // retrieves the corresponding element into the sourceDocument
    Node sourceNode = _xml.getEltByAttValue(_xmlSourceDoc, _xblinks.getEltIdName(), nodeRef);

    if (trace2) {
      System.err.println("<CP> we know now the ref of the source elt: "+nodeRef);
      System.err.println("<CP> the corresponding node is: "+sourceNode);
    }

    // Delete the element into the source tree
    Node parentNode = sourceNode.getParentNode();
    if (parentNode == null) {
      System.err.println("Error. Attempt to delete the root node of a document");
      return;
    }
    parentNode.removeChild(sourceNode);
    parentNode.getOwnerDocument().normalize();

    // notifies the change to the listeners
    if (trace2) {
      System.err.println("<CP> change done");
    }

    if (trace) {
      System.err.println("<CP> a node has been removed");
    }
   try {
     updateBeans(null);
   }
    catch (XBException e) {
      e.printStackTrace();
    }
    notifyXEditPerformed(parentNode, XEditEvent.REMOVED);
  }

  /**
   *  For debug only.
   * <p>
   * Generates all the beans at each modification made on the source document
   *
   *  @param evt            the fired event
   **/
  public void updateBeansTot(PropertyChangeEvent evt) throws XBException {
    Document oldXmlResultDoc = (Document)_xmlResultDoc.cloneNode(true);
    long t = new Date().getTime();
    doTransform();
    //<CP> below is a trial to recompute entirely the bean's view

    t = new Date().getTime() - t;
    System.err.println("<CP> xsl transformation tooks "+t+" ms");
    t = new Date().getTime();
    _listeningEvents = false;
    try {
      Object oldRoot = _rootBean;
      _rootBean = _bmProcessor.processBM(_xmlResultDoc, null);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    _listeningEvents = true;
    t = new Date().getTime() - t;
    System.err.println("<CP> recomputing beans tooks "+t+" ms");
  }

  /**
   * Updates the beans when a modification has been made on the source document
   * <p>
   * The update is composed of three successive operations
   * <p>
   * <ol>
   *   <li>the XSLT script is applied to the new source document and a new
   *       result is generated,</li>
   *   <li>the differences between the old result three and the new one is
   *       computed and stored in a list of changes,</li>
   *   <li>each change is reflected in the hierachy of target beans</li>
   * </ol>
   *
   *  @param evt            the fired event
   **/
  public void updateBeans(PropertyChangeEvent evt) throws XBException {

    Document oldXmlResultDoc = (Document)_xmlResultDoc.cloneNode(true);
    long t = new Date().getTime();
    doTransform();
    t = new Date().getTime() - t;
    System.err.println("<CP> xsl transformation tooks "+t+" ms");
    //<CP> below is the code to incrementally update the bean's view
    Node oldRoot = oldXmlResultDoc.getDocumentElement();
    Node newRoot = _xmlResultDoc.getDocumentElement();
    if (trace2) {
      System.err.println("<CP> ===== WORKING DOC =====");
      serialize(_xmlSourceDoc);

      System.err.println("<CP> ===== OLD DOC =====");
      serialize(oldXmlResultDoc);
      System.err.println("<CP> ===== NEW DOC =====");
      serialize(_xmlResultDoc);
      System.err.println("<CP> diffing.................");
    }
    t = new Date().getTime();
    XmlTreeDiff td = new XmlTreeDiff(oldRoot, newRoot);
    t = new Date().getTime() - t;
    System.err.println("<CP> diffing tooks "+t+" ms");
    Vector changeList = td.getChanges();
    if (changeList == null) System.err.println("<CP> no change done");

    if (true) {
      for (Enumeration e = changeList.elements() ; e.hasMoreElements() ;) {
        XChange xchange = (XChange)e.nextElement();
        System.err.println("<CP> XChange="+xchange);
      }
    }

    t = new Date().getTime();
    _listeningEvents = false;
    try {
      _bmProcessor.reflectChanges(_xmlResultDoc, changeList, evt);
      Object oldRootBean = _rootBean;
      _rootBean = _bmProcessor.getBeanObject();
      if (_rootBean != oldRootBean) {
        if (true) {
          System.err.println("<CP> the root is different");
          System.err.println("<CP> oldRoot="+oldRootBean);
          System.err.println("<CP> _rootBean="+_rootBean);
        }
      }
    }
    catch (Exception e) {
      error(e.getMessage());
    }

    t = new Date().getTime() - t;
    System.err.println("<CP> performing transformations tooks "+t+" ms");

    if (java.awt.Component.class.isAssignableFrom(_rootBean.getClass())) {
      ((java.awt.Component)_rootBean).validate();
      }
    _listeningEvents = true;
  }


  /**
   * Adds an event listener for XEdit events
   *
   *  @param l    the listener to add
   **/
  public synchronized void addXEditListener(XEditListener l) {
    _xEditListeners.addElement(l);
  }

  /**
   * Removes an event listener for XEdit events
   *
   *  @param l    the listener to remove
   **/
  public synchronized void removeXEditListener(XEditListener l) {
    _xEditListeners.removeElement(l);
  }

  /**
   * Notifies all registered listener when an XEdit event is received
   *
   * @param n           the node concerned by the event
   * @param eventType   the type of the event
   **/
  protected void notifyXEditPerformed(Node n, int eventType) {
    Vector l;
    XEditEvent xeo = new XEditEvent(this, n, eventType);
    
    synchronized(this) {
      l = (Vector)_xEditListeners.clone();
    }
    
    for (int i = 0 ; i < l.size() ; i++) {
      XEditListener xel = (XEditListener)l.elementAt(i);
      xel.xEditPerformed(xeo);
    }
  }

  /**
   * Performs the updates in the source document when a
   * possible change has been made on a bean
   * <p>
   * All properties of the bean initialized with values from the source
   * document are scanned. Modified values are reflected into the source
   * tree by calling reflectPropertyChange with the name of the modified
   * property.
   **/
  private void reflectBeanUpdate(Object source) {
    if (source == null) return;
    Collection propList = _xblinks.getMappingBeanProp(source);
      
    if (trace2) {
      System.err.println("<CP> proplist="+propList);
    }

    BeanInfo bInf = null;
    try {
      bInf = Introspector.getBeanInfo(source.getClass());
    }
    catch (IntrospectionException ie) {
      System.err.println("Error during introspection of the bean: '"+source.getClass().getName()+"'.");
      System.exit(0);
    }
    PropertyDescriptor[] pd = bInf.getPropertyDescriptors();

    boolean propertyChanged = false;

    for (Iterator it = propList.iterator() ; it.hasNext() ;) {
      String propertyName = (String)it.next();
      Integer indx = null;
      StringTokenizer st = new StringTokenizer(propertyName, "/");
      if (st.countTokens() == 2) {
        propertyName = st.nextToken();
        indx = new Integer(st.nextToken());
      }

      Method m =null;
    
      Object returnObject = null;
      for (int ii = 0 ; ii < pd.length ; ii++) {
        if (!pd[ii].getName().equals(propertyName)) continue;
        if (indx == null) {
          m = pd[ii].getReadMethod();
        }
        else {
          m = ((IndexedPropertyDescriptor)pd[ii]).getIndexedReadMethod();
        }

        if (m == null) {
          System.err.println("Error: failed to find getter for property: '"+propertyName+"'.");
          System.exit(0);
        }
        
        try {
          if (indx == null) {
            returnObject = m.invoke(source, null);
          }
          else {
            Object params[] = new Object[1];
            params[0] = indx;
            returnObject = m.invoke(source, params);
          }
        }
        catch (InvocationTargetException e) {
          System.err.println("Error in method '"+m.getName()+"' of bean '"+source.getClass().getName()+"'.");
          System.exit(0);
        }     
        catch (Exception e) {
          System.err.println("Error: method '"+m.getName()+"' of bean '"+source.getClass().getName()+"' cannot be called");
          System.exit(0);
        }
        PropertyChangeEvent evt = null;
        evt = new PropertyChangeEvent(source, propertyName, null, returnObject);
        if (_listeningEvents) {
          if (indx == null)
            propertyChanged = propertyChanged | processPropertyChange(evt);
          else
            propertyChanged = propertyChanged | processPropertyChange(evt, indx);
        }
      }
    }
    if (propertyChanged) {
      try {
        updateBeans(null);
      }
      catch (XBException e) {
        System.err.println("Error: "+e.getMessage());
      }
    }
  }

  private void error(String mess) throws XBException {
    throw new XBException(mess);
  }

  private void error(String mess, Object param) throws XBException {
    error(mess);
  }

  /**
   * For debug only.
   * <p>
   * Serialization of a DOM document
   **/
  private void serialize(Document doc) {
    StringWriter sw = new StringWriter();
    org.apache.xml.serialize.OutputFormat of = new org.apache.xml.serialize.OutputFormat();
    of.setIndent(2);
    of.setIndenting(true);
    org.apache.xml.serialize.XMLSerializer serializer = new org.apache.xml.serialize.XMLSerializer(sw, of);
    try {
      serializer.serialize(doc);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    System.err.println(sw.toString());
  }
}
