/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import org.w3c.dom.Node;

/**
 * Memorizes a Change made on a DOM tree
 *
 * @author Claude Pasquier
 */
public class XChange extends Object {

/**
 * Indicates that a node has been removed
 */
  public static final int REMOVE = 1;

/**
 * Indicates that a node has been changed
 */
  public static final int CHANGE = 2;

/**
 * Indicates that a node has been inserted
 */
  public static final int INSERT = 3;

/**
 * The change's type
 */
  private int _changeType = 0;

  /**
   * The XPath to the source node of the operation
   * <p>
   * for REMOVE, this is the parent of the node to remove,
   * for CHANGE, this is the parent of the node to replace,
   * for INSERT, this is the node where to insert a child
   */
  private String _sourceXPath = null;

  /**
   * The parameter node, depending of the operation
   * <p>
   * for REMOVE, this is the node to remove
   * for CHANGE, this is the node to replace,
   * for INSERT, this is null
   */
  private String _paramXPath = null;

  /**
   * The second parameter node, depending of the operation
   * <p>
   * for REMOVE, this is null
   * for CHANGE, this is the node to replace,
   * for INSERT, this is the node to insert
   */
  private Node _paramNode = null;

  /**
   * The position where to insert the new node
   * <p>
   * (not used for REMOVE and CHANGE operation)
   */
  private int _index = 0;

  /**
   * Constructs a XChange with an operation type, a base node and a source node
   **/
  public XChange(int opType, Node baseNode, Node sourceNode) {
    _changeType = opType;
    _sourceXPath = XPathUtil.computeXPath(baseNode, sourceNode);
  }

  /**
   * Constructs a XChange with an operation type, a base node, a source node
   * and a parameter node
   **/
  public XChange(int opType,  Node baseNode, Node sourceNode, Node paramNode) {
    _changeType = opType;
    _sourceXPath = XPathUtil.computeXPath(baseNode, sourceNode);
    _paramXPath = XPathUtil.computeXPath(baseNode, paramNode);
  }

  /**
   * Constructs a XChange with an operation type, a base node, a source node,
   * a first parameter node and a second one
   **/
  public XChange(int opType,  Node baseNode, Node sourceNode, Node paramNode, Node paramNode2) {
    _changeType = opType;
    _sourceXPath = XPathUtil.computeXPath(baseNode, sourceNode);
    if (paramNode != null) _paramXPath = XPathUtil.computeXPath(baseNode, paramNode);
    _paramNode = paramNode2;
  }

  /**
   * Constructs a XChange with an operation type, a base node, a source node,
   * a parameter node and an index
   **/
  public XChange(int opType, Node baseNode, Node sourceNode, Node paramNode, int index) {
    _changeType = opType;
    _sourceXPath = XPathUtil.computeXPath(baseNode, sourceNode);
    _paramNode = paramNode;
    _index = index;
  }

  /**
   * The change's type
   **/
  public int getType() {
    return _changeType;
  }

  /**
   * The XPath to the source node
   **/
  public String getSourceXPath() {
    return _sourceXPath;
  }

  /**
   * The XPath to the parameter node
   **/
  public String getParamXPath() {
    return _paramXPath;
  }

  /**
   * The XPath to the second parameter node
   **/
  public Node getParamNode2() {
    return _paramNode;
  }

  /**
   * The position of the insertion
   **/
  public int getIndex() {
    return _index;
  }

  /**
   * Returns a string representing the XChange object
   **/
  public String toString() {
    String op = null;
    switch (_changeType) {
    case 1: op = "REMOVE"; break;
    case 2: op = "CHANGE"; break;
    case 3: op = "INSERT"; break;
    }
    return "["+op+" "+_sourceXPath+" "+_paramXPath+" "+_index+"]";
  }
}
