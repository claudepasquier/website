/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.lang.reflect.*;
import java.beans.*;
import java.util.*;
import java.io.*;
import java.net.*;

//multimethods
import fr.umlv.jmmf.reflect.*;

import org.apache.xerces.dom.*;
import org.apache.xalan.xslt.*;
import org.apache.xalan.xpath.*;
import org.apache.xalan.xpath.xml.*;
import XPathAPI;
//TODO mettre le XmlUtil quelque part, dans un package
import XmlUtil;
import org.xml.sax.*;

import org.w3c.dom.*;

/**
 * An extension of BM processor which can perform
 * an incremental update of the result beans given a list
 * of changes in the xml document
 *
 * @author Claude Pasquier
 */
public class BMIncrProcessor extends BMProcessor {

  /** 
   * debugging flags
   */
  private static boolean trace = false;
  private static boolean trace1 =false;
  private static boolean trace2 = false;

  /**
   * Default constructor
   */
  BMIncrProcessor() throws BMException {
    super();
  }

  /**
   *  Constructs the class
   *
   *  @param defaultListener     the object that should be used
   *                             to listen events
   *  @param links               the links to use
   */
  BMIncrProcessor(XBMapper defaultListener,
              XBLinks links) throws BMException {
    super(defaultListener, links);

  }

  /**
   * Updates the beans given a list of changes
   *
   *  @param newBmDoc            the new bean markup document
   *  @param changeList          the list of changes
   *  @param evt                 the event that generated the update
   */
  public void reflectChanges(Document newBmDoc, Vector changeList, PropertyChangeEvent evt) throws BMException {
    Hashtable changeTable = new Hashtable();
    for (Enumeration e = changeList.elements() ; e.hasMoreElements() ;) {
      XChange xchange = (XChange)e.nextElement();
      String sourceXPath = xchange.getSourceXPath();
      Node sourceNode = null;
      try {
        sourceNode = XPathAPI.selectSingleNode(_bmDoc, sourceXPath);
      }
      catch (SAXException se) {
        error("unable to retrieve in the old BM document, the node corresponding to the XPath '"
              + sourceXPath + "'");
      }
      // the sourceNode has been changed
      // select as source, a bean registered
      // located under an '<add>' tab
      // (to be able to perform a replace)
      Node parentNode = sourceNode.getParentNode();
      while ((parentNode != null)
             && (!"add".equals(parentNode.getNodeName()))
             && (!"add".equals(((Element)sourceNode).getAttribute("action")))
             && (parentNode.getNodeType() != Node.DOCUMENT_NODE)) {
        sourceNode = parentNode;
        parentNode = sourceNode.getParentNode();
      }

      // computes the xpath of the source node
      String xpath = XPathUtil.computeXPath(null, sourceNode);
      // get the corresponding bean
      Object sourceBean = _xblinks.getMappingEltBean(xpath);
      if (sourceBean == null) {
        error("unable to retrieve the bean corresponding to the XPath '"
              + xpath + "'");
      }
      //      if (changeTable.get(sourceBean) != null) continue; // this bean has already been changed

      //            changeTable.put(sourceBean, "nothing");
      //System.err.println("<CP> after changing changeTable");
      Node correspondingNode = null;
      try {
        correspondingNode = XPathAPI.selectSingleNode(newBmDoc, xpath);
      }
      catch (SAXException se) {
        error("unable to retrieve in the new BM document, the node corresponding to the XPath '"
              + xpath + "'");
      }
      // searching the bean parent (context bean)
      while ((parentNode != null)
             && (!"bean".equals(parentNode.getNodeName()))
             && (parentNode.getNodeType() != Node.DOCUMENT_NODE)) {
        parentNode = parentNode.getParentNode();
      }

      Object parentBean = null;
      if ((parentNode != null)
          && ("bean".equals(parentNode.getNodeName()))) {
        String parentXPath = XPathUtil.computeXPath(null, parentNode);
        parentBean = _xblinks.getMappingEltBean(parentXPath);
      }

      // if the bean to modify is at the root
      // recompute the entire bean's hierarchy
      if (parentBean == null) {
        _bmDoc = newBmDoc;
        _rootBean = processBM(newBmDoc, null);
        return;
      }
      if (changeTable.get(parentBean) != null) { // this bean has already been changed
        continue;
      }

      changeTable.put(parentBean, "nothing");

      Object resultBean = getObject(correspondingNode, parentBean).getObject();

      // retrieves the replacer to use for this type of 'bean' elements
      String className = sourceBean.getClass().getName();
      boolean replacementDone = false;
      for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
        Element elt = (Element)enum.nextElement();
        String type = elt.getAttribute("type");
        if (!"replacer".equals(type)) continue;

        String replacerClassName = elt.getAttribute("class");
        Class replacerClass = null;
        try {
          replacerClass = Class.forName(replacerClassName);
        }
        catch (ClassNotFoundException cnfe) {
          error("unable to retrieve the class '" + replacerClassName + "'");
        }
        String methodName = elt.getAttribute("method");

        try {
          Object[] params = new Object[3];
          params[0] = parentBean;
          params[1] = sourceBean;
          params[2] = resultBean;
          MultiMethod mm=MultiMethod.create(replacerClass,methodName,3);
          if (trace) {
            System.err.println("<CP> multimethod found1");
            System.err.println("<CP> parentBean="+ parentBean);
            System.err.println("<CP> sourceBean="+ sourceBean);
            System.err.println("<CP> resultBean="+ resultBean);
          }
          mm.invoke(replacerClass.newInstance(), params);
        }
        catch (NoClassDefFoundError ex) {
          // the replacer is not found. Tries to find another one
          continue;
        }
        catch (Exception ex) {
          // the replacer doesn't match. Tries to find another one
          continue;
        }
        replacementDone = true;
        break;
      }
      if (replacementDone == false) {
        error("unable to find a replacer for for an element of class '"
              + sourceBean.getClass()
              + "' in an element of class '"
              + parentBean.getClass() + "'");
      }
    }
    _bmDoc = newBmDoc;
  }

//   public void reflectChanges(Vector changeList, PropertyChangeEvent evt) throws BMException {
//     Object[] memBeans = new Object[changeList.size()];
//     Node[]   memProps = new Node[changeList.size()];
//     int eltIndex = -1;
//     for (Enumeration e = changeList.elements() ; e.hasMoreElements() ;) {
//       eltIndex += 1;
//       sourceBeans[eltIndex] = null;
//       paramBean[eltIndex] = null;
//       //      memProps[eltIndex] = null;
//       XChange xchange = (XChange)e.nextElement();
//       if (trace2) {
//         System.err.println("<CP>processing XChange="+xchange);
//       }
//       String sourceXPath = xchange.getSourceXPath();
//       String paramXPath = xchange.getParamXPath();
//       Node paramNode2 = xchange.getParamNode();
//       int opType = xchange.getType();
//       Node sourceNode = XPathAPI.selectSingleNode(_bmDoc, sourceXPath);
//       Node paramNode = XPathAPI.selectSingleNode(_bmDoc, paramXPath);
//       switch (opType) {
//       case XChange.REMOVE :
//         sourceNode.removeChild(paramNode);
//         Object sourceBean = _xblinks.getMappingEltBean(sourceXPath);
//         Object paramBean = _xblinks.getMappingEltBean(paramXPath);
//         if ((sourceBean != null) && (paramBean != null)) {
//           remove(sourceBean, paramBean);
//         }
//         else {
//           while ((sourceBean == null) ||(paramBean == null)) {
//             try {
//               sourceNode = sourceNode.getParentNode();
//               paramNode = paramNode.getParentNode();
//               sourceXPath = XPathUtil.computeXPath(null, sourceNode);
//               paramXPath = XPathUtil.computeXPath(null, paramNode);
//               sourceBean = _xblinks.getMappingEltBean(sourceXPath);
//               paramBean = _xblinks.getMappingEltBean(paramXPath);
//             }
//           }
//           Object newBean = getObject(

//             paramNode2 = 
//           Node paramNode = XPathAPI.selectSingleNode(_bmDoc, paramXPath);
//           sourceNode = sourceNode.getParentNode();
//           paramNode

//       // retrieve the corresponding element into the source document
//       Node correspondingElt = null;
//       Node modifiedProp = null;
//       Node resultBean = xchange.getParamNode();
//       if (!(((resultBean != null) &&
//              (resultBean.getNodeType() == Node.ELEMENT_NODE) &&
//              ((Element)resultBean).getTagName().equals("bean")) ||
//             ((_xblinks.getMappingEltBean(xpath) != null)))) {
//         if (trace) {
//           System.err.println("<CP> hehehe");
//         }
//         try {
//           System.err.println("<CP>Start");
//           System.err.println("<CP> xpath="+xpath);
//           System.err.println("<CP> bmdoc="+_bmDoc);
//           correspondingElt = XPathAPI.selectSingleNode(_bmDoc, xpath);
//           System.err.println("<CP>end");
//         }
//         catch (SAXException se) {
//           error("unable to apply the XPath '" + xpath
//                 + " on the bmDocument");
//         }
//         System.err.println("<CP> after applying XPath");

//         // if the corresponding element is not a property element, search
//         // the property element to which it correspond by looking
//         // at the ancestors
//         Node currentElt = correspondingElt;
//         if (trace) {
//           if (currentElt.getNodeType() == Node.TEXT_NODE)
//             System.err.println("<CP>TEXTTT");
//           if ((currentElt.getNodeType() == Node.TEXT_NODE) &&
//               (resultBean != null) &&
//               (currentElt.getNodeType() == Node.TEXT_NODE))System.err.println("<CP>TEXTTT2");
//         }
        
        

//         if ((resultBean != null) &&
//             (resultBean.getNodeType() == Node.TEXT_NODE)) {
//           Node oldTextNode = currentElt.getFirstChild();
//           if ((oldTextNode != null) &&
//               (oldTextNode.getNodeType() == Node.TEXT_NODE)) {
//             ((Text)currentElt.getFirstChild()).setData(((Text)resultBean).getData());
//           }
//         }
 
//         if ((currentElt.getNodeType() != Node.ELEMENT_NODE) ||
//             ((currentElt.getNodeType() == Node.ELEMENT_NODE) &&
//              (!((Element)currentElt).getTagName().equals("property")))) {
// System.err.println("<CP>222");
//           do {
//             currentElt = currentElt.getParentNode();
//           }
//           while ((currentElt != null) &&
//                  !((Element)currentElt).getTagName().equals("property") &&
//                  !((Element)currentElt).getTagName().equals("bean"));
          
// System.err.println("<CP>333");
//           if (currentElt == null) {
//             error("the modified element of a document is not part of a bean");
//           }
//           else if (((Element)currentElt).getTagName().equals("bean")) {
// System.err.println("<CP>444");
//             xpath = XPathUtil.computeXPath(null, currentElt);
// System.err.println("<CP>555");
//             if (trace) {
//               System.err.println("<CP>modifying xpath");
//             }
//           }
//           else if (((Element)currentElt).getTagName().equals("property")) {
//             System.err.println("<CP>666");
//             modifiedProp = currentElt;
//             Node beanElt = (Element)currentElt.getParentNode();
//             while ((beanElt != null) &&
//                    !((Element)beanElt).getTagName().equals("bean")) {
//               beanElt = beanElt.getParentNode();
//             }
//             if (beanElt == null) {
//               error("the bean holding a modified property was not retrieved");
//             }
//             System.err.println("<CP>777");
//             xpath = XPathUtil.computeXPath(null, beanElt);
//             System.err.println("<CP>888");
//           }
//         }
//       }
// //       else {
// //         Node currentElt = null;
// //         try {
// //           System.err.println("<CP>Start-01");
// //           currentElt = XPathAPI.selectSingleNode(_bmDoc, xpath);
// //           System.err.println("<CP>end-01");
// //         }
// //         catch (SAXException se) {
// //           error("unable to apply the XPath '" + xpath
// //                 + " on the bmDocument");
// //         }
// //         if ((currentElt != null)
// //             && (currentElt.getNodeType() == Node.ELEMENT_NODE)
// //             && (currentElt.getNodeName().equals("add"))) {
// //           System.err.println("<CP> we are on a 'add' element");
// //           currentElt = currentElt.getParentNode();
// //           System.err.println("<CP> currentElt = "+currentElt);
// //           xpath = XPathUtil.computeXPath(null, currentElt);
// //           System.err.println("<CP> xpath = "+xpath);
// //         }
// //       }

//       System.err.println("<CP>999 xpath="+xpath+", _xblinks="+_xblinks);
//       Object ob = _xblinks.getMappingEltBean(xpath);
//       System.err.println("<CP>1019 tob="+ob);

//       //      TypedObject tob = (TypedObject)_xblinks.getMappingEltBean(xpath);
//       Object bean = _xblinks.getMappingEltBean(xpath);
//       //      System.err.println("<CP>1010 tob="+tob);
//       //      if (tob == null) continue;
//       //      Object bean = tob.getObject();
       
//       if (bean == null) {
//         continue;
//       }
//       if (trace) {
//         System.err.println("<CP> concerned bean="+bean);
//       }
//       memBeans[eltIndex] = bean;
//       memProps[eltIndex] = modifiedProp;
//     }

//     eltIndex = -1;
//     System.err.println("<CP> starting XChange processing");
//     for (Enumeration e = changeList.elements() ; e.hasMoreElements() ;) {
//       eltIndex += 1;
//       Object bean = memBeans[eltIndex];
//       System.err.println("<CP> processing change. bean="+bean);
//       Node modifiedProp = memProps[eltIndex];
//       XChange xchange = (XChange)e.nextElement();
//       Node resultBean = xchange.getParamNode();
//       System.err.println("<CP> XChange===="+xchange.getType()+"("+modifiedProp+")");
//       if (bean == null) continue;
//       if (modifiedProp != null) {
//         if (trace1) {
//           System.err.println("<CP>MODIFIEDPROP");
//           System.err.println("<CP> bean="+bean);
//           if (evt != null) {
//             System.err.println("<CP> source="+evt.getSource());
//             System.err.println("<CP>   prop name="+evt.getPropertyName());
//           }
//         }
//         if ((evt != null) && (bean == evt.getSource()))
//           if (trace1) {
//             System.err.println("<CP>WE ARE LOCATED ON THE SOURCE BEAN");
//           }

//         if ((evt == null) ||
//             (!((bean == evt.getSource()) &&
//                (((Element)modifiedProp).getAttribute("name").equals(evt.getPropertyName()))))) {
//           if (trace1) {
//             System.err.println("<CP>CALLING setProperty");
//             System.err.println("<CP>modifiedProp="+modifiedProp);
//           }
//           setProperty((Element)modifiedProp, bean);
//         }
//       }
//       else {
//         TypedObject to = null;
//         switch (xchange.getType()) {
//         case XChange.REMOVE :
//           String path = xchange.getSourceXPath();
//           try {
//             Node sNode = XPathAPI.selectSingleNode(_bmDoc.getDocumentElement(), path);
//             lShiftNode(sNode);
//           }
//           catch (SAXException se) {
//             error("unable to apply the XPath '" + path
//                   + " on the bmDocument");
//           }
//           // retrieves the remover to use for this type of 'bean' elements
//           String className = bean.getClass().getName();
//           for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
//             Element elt = (Element)enum.nextElement();
//             String type = elt.getAttribute("type");
//             if (!"remover".equals(type)) continue;
//             String parentClassName = elt.getAttribute("parentClass");
//             Class parentClass = null;
//             try {
//               parentClass = Class.forName(parentClassName);
//             }
//             catch (ClassNotFoundException cnfe) {
//               error("unable to retrieve the class '" + parentClassName + "'");
//             }
//             if (!parentClass.isInstance(bean)) continue;
//             String removerClassName = elt.getAttribute("class");
//             Class removerClass = null;
//             try {
//               removerClass = Class.forName(removerClassName);
//             }
//             catch (ClassNotFoundException cnfe) {
//               error("unable to retrieve the class '" + removerClassName + "'");
//             }
//             String methodName = elt.getAttribute("method");

//             try {
//               Object[] params = new Object[2];
//               params[0] = bean;
//               params[1] = resultBean;
//               MultiMethod mm=MultiMethod.create(removerClass,methodName,2);
//               System.err.println("<CP> multimethod found");
//               mm.invoke(new Removers(), params);
//             }
//             catch (Exception ex) {
//               error("unable to find a method to remove an alement of class '"
//                     + resultBean.getClass()
//                     + "' from an element of class '"
//                     + bean.getClass() + "'");
//             }
//             System.err.println("<CP> remove successfull");
//             break;
//           }
//           break;
//         case XChange.CHANGE :
// //          to = getObject((Element)resultBean, bean.getParent());
// //           Component[] comps = bean.getParent().getComponents();
// //           int index =0;
// //           for (int i = 0 ; i < comps.length ; i++) {
// //             if (comps[i] == bean) {
// //               index = i;
// //               break;
// //             }
// //           }
// //           bean.getParent().remove(bean);
// //           ((Container)bean).add((Component)to.getObject(), index);
//           break;
//         case XChange.INSERT :
//           //<CP1>
//           Node n = resultBean;
//           rShiftNode(resultBean);
//           System.err.println("<CP> index of insertion ="+xchange.getIndex());
//           //</CP1>
//           if ("add".equals(resultBean.getNodeName())) {
//             Object beanObj = executeAdd((Element)resultBean, bean);
//           }
//           break;
//         }
//       }
//     }
//   }

//   private void rShiftNode(Node node) {
//     Vector paths = new Vector();
//     Node n = node;
//     do {
//       paths.insertElementAt(XPathUtil.computeXPath(null, n), 0);
//       n= n.getNextSibling();
//     }
//     while (n != null);

//     for (Enumeration e = paths.elements() ; e.hasMoreElements() ;) {
//       String xpath = (String)e.nextElement();
//       int startPos = xpath.lastIndexOf('[') + 1;
//       int endPos   = xpath.lastIndexOf(']');
//       int lastMove = Integer.parseInt(xpath.substring(startPos, endPos));
//       lastMove += 1;
//       String oldXPath  = xpath.substring(0, endPos+1);
//       String newXPath = xpath.substring(0, startPos) + lastMove + ']';
//       for (Enumeration e2 = _xblinks.getMappingEltBeanKeys() ; e2.hasMoreElements() ;) {
//         String oldKey = (String)e2.nextElement();
//         if (oldKey.startsWith(oldXPath)) {
//           Object value = _xblinks.getMappingEltBean(oldKey);
//           String newKey = newXPath.substring(0, endPos) + oldKey.substring(endPos);
//           _xblinks.removeMappingEltBean(oldKey);
//           _xblinks.putMappingEltBean(newKey, value);
//           if (trace) {
//             System.err.println("<CP> replaced "+oldKey);
//             System.err.println("<CP> with     "+newKey);
//           }
//         }
//       }
//     }
//   }

//   private void lShiftNode(Node node) {
//     Vector paths = new Vector();
//     Node n = node.getNextSibling();
//     while (n != null) {
//       paths.addElement(XPathUtil.computeXPath(null, n));
//       n= n.getNextSibling();
//     }

//     for (Enumeration e = paths.elements() ; e.hasMoreElements() ;) {
//       String xpath = (String)e.nextElement();
//       int startPos = xpath.lastIndexOf('[') + 1;
//       int endPos   = xpath.lastIndexOf(']');
//       int lastMove = Integer.parseInt(xpath.substring(startPos, endPos));
//       lastMove -= 1;
//       String oldXPath  = xpath.substring(0, endPos+1);
//       String newXPath = xpath.substring(0, startPos) + lastMove + ']';
//       for (Enumeration e2 = _xblinks.getMappingEltBeanKeys() ; e2.hasMoreElements() ;) {
//         String oldKey = (String)e2.nextElement();
//         if (oldKey.startsWith(oldXPath)) {
//           Object value = _xblinks.getMappingEltBean(oldKey);
//           String newKey = newXPath.substring(0, endPos) + oldKey.substring(endPos);
//           _xblinks.removeMappingEltBean(oldKey);
//           _xblinks.putMappingEltBean(newKey, value);
//           if (trace) {
//             System.err.println("<CP> replaced "+oldKey);
//             System.err.println("<CP> with     "+newKey);
//           }
//         }
//       }
//     }
//   }
}
