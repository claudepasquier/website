/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle key events
 *
 * @author Claude Pasquier
 */
  
public class ScriptKeyHandler implements KeyListener {
      
  public void keyPressed(KeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "keyPressed");
  }

  public void keyTyped(KeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "keyTyped");
  }

  public void keyReleased(KeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "keyReleased");
  }
}
