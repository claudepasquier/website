/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;
import java.net.URL;
import java.beans.*;
import org.w3c.dom.Element;

/**
 * A processor for scripts invoked at runtime
 *
 * @author Claude Pasquier
 */
public class ScriptEventProcessor {
      
  static Vector _beanList            = new Vector();
  static Vector _scriptList          = new Vector();
  static Vector _registeredBeansList = new Vector();
  static Vector _filterList          = new Vector();
  static Vector _xbmapperList        = new Vector();
  static Vector _contextURLList      = new Vector();

  /**
   *  Register a bean with its associated script element
   *
   *  @param beanObject      the source bean
   *  @param scriptElement   the script associated with the bean
   *  @param registeredBeans the list of registered beans at
   *                         the time of the declaration of the script
   *  @param xbmapper        the xbmapper to use
   *  @param contextURL      the currentUrl at the time of the
   *                         declaration of the script
   **/
  public static void register(Object beanObject,
                              Element scriptElement,
                              Hashtable registeredBeans,
                              Object xbmapper,
                              URL contextURL) {
    register(beanObject,
             scriptElement,
             registeredBeans,
             xbmapper,
             contextURL, 
             null);
  }

  /**
   *  Register a bean with its associated script element
   *
   *  @param beanObject      the source bean
   *  @param scriptElement   the script associated with the bean
   *  @param registeredBeans the list of registered beans at
   *                         the time of the declaration of the script
   *  @param xbmapper        the xbmapper to use
   *  @param contextURL      the currentUrl at the time of the
   *                         declaration of the script
   *  @param filter          a data used to filter the events
   **/
  public static void register(Object beanObject,
                              Element scriptElement,
                              Hashtable registeredBeans,
                              Object xbmapper,
                              URL contextURL,
                              String filter) {
    _beanList.addElement(beanObject);
    _scriptList.addElement(scriptElement);
    _registeredBeansList.addElement(registeredBeans.clone());
    _xbmapperList.addElement(xbmapper);
    _contextURLList.addElement(contextURL);
    _filterList.addElement(filter);
  }

  /**
   *  Delegates the execution of the script to xbmapper
   *  when an eventObject is received
   **/
  public void processEvent(EventObject evt) {
    processEvent(evt, "");
  }

  /**
   *  Delegates the execution of the script to xbmapper
   *  when a documentEvent is received
   **/
  public void processEvent(DocumentEvent evt) {
    processEvent(evt, "");
  }

  /**
   *  Delegates the execution of the script to xbmapper
   **/
  public void processEvent(EventObject evt, String filter) {
    Object source = evt.getSource();
    processEvent(evt, source, filter);
  }

  /**
   *  Delegates the execution of the script to xbmapper
   **/
  public void processEvent(DocumentEvent evt, String filter) {
    Object source = evt.getDocument();
    processEvent(evt, source, filter);
  }

  /**
   *  Delegates the execution of the script to xbmapper
   **/
  public void processEvent(PropertyChangeEvent evt, String propertyName) {
    Object source = evt.getSource();
    for (int i = 0 ; i < _beanList.size() ; i++) {
      if (_beanList.elementAt(i) != source) continue;
      String filter = (String)_filterList.elementAt(i);
      if (!((filter == null)
            || ("".equals(filter)) 
            || propertyName.equals(filter))) continue;

      Hashtable contextTable = new Hashtable();
      Element scriptElement = null;
      XBMapper xbmapper = null;
      URL contextURL = null;
      synchronized(this) {
        contextTable = (Hashtable)((Hashtable)_registeredBeansList.elementAt(i)).clone();
        scriptElement = (Element)_scriptList.elementAt(i);
        xbmapper = (XBMapper)_xbmapperList.elementAt(i);
        contextURL = (URL)_contextURLList.elementAt(i);
      }
      contextTable.put("event:arg0", propertyName);
      contextTable.put("event:arg1", evt);
      
      try {
        BMProcessor processor = new BMProcessor(xbmapper);
        processor.processBM(scriptElement,contextTable, source, contextURL);
      }
      catch (BMException e) {
        e.printStackTrace();
      }
    }
  }

  /**
   *  Delegates the execution of the script to xbmapper
   **/
  private void processEvent(Object evt, Object source, String filter) {
    for (int i = 0 ; i < _beanList.size() ; i++) {
      if (_beanList.elementAt(i) != source) continue;
      Hashtable contextTable = new Hashtable();
      Element scriptElement = null;
      XBMapper xbmapper = null;
      URL contextURL = null;
      synchronized(this) {
        contextTable = (Hashtable)((Hashtable)_registeredBeansList.elementAt(i)).clone();
        scriptElement = (Element)_scriptList.elementAt(i);
        xbmapper = (XBMapper)_xbmapperList.elementAt(i);
        contextURL = (URL)_contextURLList.elementAt(i);
      }
      contextTable.put("event:arg0", filter);
      contextTable.put("event:arg1", evt);
      
      try {
        BMProcessor processor = new BMProcessor(xbmapper);
        processor.processBM(scriptElement,contextTable, source, contextURL);
      }
      catch (BMException e) {
        e.printStackTrace();
      }
    }
  }
}
