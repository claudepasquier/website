/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle treeWillExpand events
 *
 * @author Claude Pasquier
 */
  
public class ScriptTreeWillExpandHandler implements TreeWillExpandListener {
      
  public void treeWillCollapse(TreeExpansionEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeWillCollapse");
  }

  public void treeWillExpand(TreeExpansionEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeWillExpand");
  }
}
