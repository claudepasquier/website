/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import org.w3c.dom.*;
import java.util.*;

/**
 * Utilities to differenciates two DOM trees
 *
 * @author Claude Pasquier
 */
public class XmlTreeDiff {

  /**
   * The root of the first tree to diff
   */
  private Node root1 = null;

  /**
   * The root of the second tree to diff
   */
  private Node root2 = null;

  /**
   * The list of changes
   */
  private Vector changes = null;

/**
 * Consructor accepting DOM documents as both trees to diff
 *
 *  @param firstDoc   the first document to diff
 *  @param secondDoc  the second document to diff
 *
 */
  public XmlTreeDiff(Document firstDoc, Document secondDoc) {
    diff(firstDoc.getDocumentElement(), secondDoc.getDocumentElement());
  }

/**
 * Consructor accepting DOM nodes as roots for thetrees to diff
 *
 *  @param firstTree   the first tree to diff
 *  @param secondTree  the second tree to diff
 *
 */
  public XmlTreeDiff(Node firstTree, Node secondTree) {
    root1 = firstTree;
    root2 = secondTree;
    changes = new Vector();
    diff(firstTree, secondTree);
  }

/**
 * The changes representing the differences between trees
 *
 */
  public Vector getChanges() {
    return changes;
  }

  /**
   * Performs a diff between two DOM trees
   *
   * @param n1            the first node
   * @param n2            the second node
   *
   * @return              true if the nodes are different, false otherwise
   *
   **/
  public boolean diff(Node n1, Node n2) {
    return diff(n1, n2, false, true);
  }


  /**
   * Performs a diff between two DOM trees
   *
   * @param n1            the first node
   * @param n2            the second node
   * @param testOnly      if true, makes only a test
   * @param recurse       if true, the method recurses by making a diff on the childs
   *
   * @return              true if the nodes are different, false otherwise
   *
   **/
  private boolean diff(Node n1, Node n2, boolean testOnly, boolean recurse) {

    boolean diff = false;
    if ((n1 == null) && (n2 == null)) return false;
    else if ((n1 == null) && (n2 != null)) diff = true;
    else if ((n1 != null) && (n2 == null)) diff = true;
    else if (!n1.getNodeName().equals(n2.getNodeName())) diff = true;
    else if (n1.getNodeType() != n2.getNodeType()) diff = true;
    else if ((n1.getNodeValue() == null) &&
             (n2.getNodeValue() != null)) diff = true;
    else if ((n1.getNodeValue() != null) &&
             (n2.getNodeValue() == null)) diff = true;
    else if ((n1.getNodeValue() != null) &&
             (n2.getNodeValue() != null) &&
             !n1.getNodeValue().equals(n2.getNodeValue())) diff = true;
    else {
      NamedNodeMap n1Attributes = n1.getAttributes();
      NamedNodeMap n2Attributes = n2.getAttributes();
      if ((n1Attributes == null) && (n2Attributes == null)) {
      }
      else if ((n1Attributes != null) && (n2Attributes != null)) {
        if (n1Attributes.getLength() != n2Attributes.getLength()) {
          diff = true;
        }
        else {
          for (int i = 0 ; i < n1Attributes.getLength() ; i++) {
            Node att1 = n1Attributes.item(i);
            Node att2 = n2Attributes.getNamedItem(att1.getNodeName());
            if ((att2 == null) ||
                (!att1.getNodeValue().equals(att2.getNodeValue()))) {
              diff = true;
              break;
            }
          }
        }
      }
      else {
        diff = true;
      }
    }

    if (diff && !testOnly) { // memorizes the change
      changes.addElement(new XChange(XChange.CHANGE, null, n1.getParentNode(), n1, n2));
      return diff;
    }

    if (!recurse) return diff;

    // The nodes themselves are equals.
    // We have now to check their childs

    NodeList n1Childs = n1.getChildNodes();
    NodeList n2Childs = n2.getChildNodes();
    int indxj = 0;
    for (int i = 0 ; i < n1Childs.getLength() ; i++) {
      Node child1 = n1Childs.item(i);
      boolean nodeFound = false;
      for (int j = indxj ; j < n2Childs.getLength() ; j++) {
        Node child2 = n2Childs.item(j);
        if (!diff(child1,child2, true, false)) {
          for (int k = indxj ; k < j ; k++) {
            // a node has been added
            if (!testOnly) {
              //              changes.addElement(new XChange(XChange.CHANGE, null, n1, n2));
              //              return true;
              changes.addElement(new XChange(XChange.INSERT, null, n1, n2Childs.item(k), k));
            }
            diff = true;
          }
          indxj = j+1;
          diff(child1, child2, false, true);
          nodeFound = true;
          break;
        }
      }
      if (!nodeFound) {
        // a node has been removed
        if (!testOnly) {
          //          changes.addElement(new XChange(XChange.CHANGE, null, n1, n2));
          //          return true;
          changes.addElement(new XChange(XChange.REMOVE, null, n1, child1));
        }
        diff = true;
      }
    }
    for (int j = indxj ; j < n2Childs.getLength() ; j++) {
      // a node has been added
      if (!testOnly) {
        //        changes.addElement(new XChange(XChange.CHANGE, null, n1, n2));
        //        return true;
        changes.addElement(new XChange(XChange.INSERT, null, n1, n2Childs.item(j), j));
      }
      diff = true;
    }
    return diff;
  }
}
