/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

import fr.dyade.koala.xml.kuil.widgets.TablePanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;

public class Table extends TablePanel {

  private int _borderw = -1;

  public Table() {
    super();
  }

  public void setRows(TR[] rows) {
    super.setRows(rows);
    for (int i = 0 ; i < rows.length ; i++) {
      ((fr.inria.ketuk.widgets.html.TR)rows[i]).setParent(this);
      ((fr.inria.ketuk.widgets.html.TR)rows[i]).setBorderw(_borderw);
    }
  }

  public void add(Object tableRow) {
    TR[] oldRows = getRows();
    int nbRow = oldRows == null ? 0 : oldRows.length;
    TR[] newRows = new TR[nbRow+1];
    for (int i = 0 ; i < nbRow ; i++) {
      newRows[i] = oldRows[i];
    }
    newRows[nbRow] = (TR)tableRow;
    setRows(newRows);
  }

  public void remove(Object tableRow) {
    TR[] oldRows = getRows();
    int nbRow = oldRows == null ? 0 : oldRows.length;
    TR[] newRows = new TR[nbRow-1];
    int index = 0;
    for (int i = 0 ; i < nbRow ; i++) {
      if (tableRow != oldRows[i]) {
        newRows[index] = oldRows[i];
        index++;
      }
    }
    setRows(newRows);
    TR tr = (TR)tableRow;
    TD[] cols = tr.getCols();
    for (int i = 0 ; i < cols.length ; i++) {
      ((java.awt.Container)this).remove(cols[i].getComponent());
    }
  }

  public void replace(Object oldTableRow, Object newTableRow) {
    TR[] rows = getRows();
    int nbRow = rows == null ? 0 : rows.length;
    for (int i = 0 ; i < nbRow ; i++) {
      if (oldTableRow == rows[i]) {
        rows[i] = (TR)newTableRow;
      }
    }
    TR tr = (TR)oldTableRow;
    TD[] cols = tr.getCols();
    for (int i = 0 ; i < cols.length ; i++) {
      ((java.awt.Container)this).remove(cols[i].getComponent());
    }
  }

  public void setBorderw(int w) {
    _borderw = w;
    TR[] rows = getRows();
    if (rows != null) {
      for (int i = 0 ; i < rows.length ; i++) {
        ((fr.inria.ketuk.widgets.html.TR)rows[i]).setBorderw(_borderw);
      }
    }
    if (_borderw >= 0) {
      setBorder(new MatteBorder(_borderw, _borderw, _borderw, _borderw, Color.black));
    }
  }

  public int getBorderw() {
    return _borderw;
  }

//   public void validate() {
//     System.err.println("Validate requested on table");
//     super.validate();
//     TR[] rows = getRows();
//     int nbRow = (rows == null) ? 0 : rows.length;
//     for (int i = 0 ; i < nbRow ; i++) {
//       Object[] cols = (Object[])rows[i].getCols();
//       int nbCol = (cols == null) ? 0 : cols.length;
//       for (int j = 0 ; j < nbCol ; j++) {
//         ((TD)cols[j]).getComponent().validate();
//         ((TD)cols[j]).getComponent().invalidate();
// System.err.println("COMP="+ ((TD)cols[j]).getComponent());
//       }
//     }
//   }
}
