/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
 * A Collection of methods which replace, in the context of a containing object,
 * an object by another one
 *
 * @author Claude Pasquier
 */
public class Replacers {

  /**
   * Default constructor
   */
  public Replacers() {
  }

  /**
   * Default replacer for two objects of class Component placed in a Container
   *
   *  @param parent    the container of the first component
   *  @param c1        the component to replace
   *  @param c2        the new component
   *
   **/
  public void replace(Container parent, Component c1, Component c2) {
    for (int i = 0 ; i < parent.getComponentCount() ; i++) {
      if (parent.getComponent(i) == c1) {
        parent.add(c2, i);
        parent.remove(c1);
        break;
      }
    }
  }

  /**
   * Default replacer for two objects of class Component placed in a JFrame
   *
   *  @param parent    the frame containing the first component
   *  @param c1        the component to replace
   *  @param c2        the new component
   *
   **/
  public void replace(JFrame parent, Component c1, Component c2) {
    replace(parent.getContentPane(), c1, c2);
  }

  /**
   * Default replacer for two objects of class Object placed in a Vector
   *
   *  @param parent    the Vector containing the first object
   *  @param obj1      the object to replace
   *  @param obj2      the new object
   *
   **/
  public void replace(Vector parent, Object obj1, Object obj2) {
    int index = parent.indexOf(obj1);
    if (index > -1) {
      parent.setElementAt(obj2, index);
    }
  }

}
