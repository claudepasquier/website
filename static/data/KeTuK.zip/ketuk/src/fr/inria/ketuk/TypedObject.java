/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

/**
 * Used to represent an object with its type
 * <p>
 * This is needed to process in an unifor way objects instances of
 * classes and objects which represents standard types
 * (int, byte, boolean, etc)
 *
 * @author Claude Pasquier
 */
public class TypedObject{

  /**
   * The object
   **/
  private Object obj  = null;

  /**
   * The type or class of the object
   **/
  private Class  type = null;

  /**
   * Default constructor
   */
  public TypedObject() {
  }

  /**
   * Constructs a typed object representing the object o with the class c
   */
  public TypedObject(Object o, Class c) {
    obj  = o;
    type = c;
  }

  /**
   * Sets the object
   */
  public void setObject(Object o) {
    obj = o;
  }

  /**
   * Sets the type
   */
  public void setType(Class c) {
    type = c;
  }

  /**
   * Gets the object
   */
  public Object getObject() {
    return obj;
  }

  /**
   * Gets the type
   */
  public Class getType() {
    return type;
  }

}
