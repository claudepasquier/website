/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.lang.Exception;
import java.util.*;

/**
 * Memorizes the links used to assure a mapping between XML nodes
 * and beans
 *
 * @author Claude Pasquier
 */
public class XBLinks {

  /**
   * The mapping between the xpath of bean elements in the result DOM tree
   * and the generated object
   */
  private Hashtable _mappingEltBean = null;

  /**
   * The mapping between generated beans, and the 'id' of the corresponding
   * element in the source tree
   */
  private Hashtable _mappingNodeRef = null;

  /**
   * The mapping between beans and the pair property name, property ID
   */
  private Hashtable _mappingProp = null;

  /**
   * The mapping between beans and the Vector of property names which were set
   */
  //<TODO>
  // this may be redundant with the previous table
  public Hashtable _mappingBeanProp = null;

  /**
   * The mapping between a pair "sourceNode+propertyName" and the 'id' of
   * the property element into the XSL tree
   */
  private Hashtable _mappingSourceNode = null;

  /**
   * The name of the attribute used to memorize the unique Identifier of a node
   **/
  private String _eltIdName   = "noderef";

  /**
   * The prefix used to name a node
   **/
  private String _eltIdPrefix = "id";

  /**
   * The number of the last named node
   * <p>
   * The next one will be named <_eltIdPrefix><_eltIdNum>
   **/
  private int    _eltIdNum    = 0;

  /**
   * Default constructor
   */
  public XBLinks() {
    // Initialises hash tables
    _mappingEltBean    = new Hashtable();
    _mappingNodeRef    = new Hashtable();
    _mappingProp       = new Hashtable();
    _mappingBeanProp   = new Hashtable();
    _mappingSourceNode = new Hashtable();
  }

  /**
   * Returns the mapping between the xpath of bean elements in the result DOM tree
   * and the generated object
   */
  public Object getMappingEltBean(String key) {
    return _mappingEltBean.get(key);
  }

  /**
   * Returns the XPath of the element from the source document mapped with beans
   */
  public Enumeration getMappingEltBeanKeys() {
    return _mappingEltBean.keys();
  }

  /**
   * Adds a new mapping between the xpath of a bean elements in the result DOM tree
   * and a generated object
   */
  public void putMappingEltBean(String key, Object value) {
    _mappingEltBean.put(key, value);
  }

  /**
   * Removes the mapping corresponding to the key
   */
  public void removeMappingEltBean(String key) {
    _mappingEltBean.remove(key);
  }

  /**
   * Returns the mapping between generated beans, and the 'id' of the corresponding
   * element in the source tree
   */
  public String getMappingNodeRef(Object key) {
    return (String)_mappingNodeRef.get(key);
  }

  /**
   * Adds a new mapping between a beans, and the 'id' of the corresponding
   * element in the source tree
   */
  public void putMappingNodeRef(Object key, String nodeRef) {
    _mappingNodeRef.put(key, nodeRef);
  }

  /**
   * Returns the pairs propertyName, propertyID associated with the bean
   */
  public Hashtable getMappingProp(Object key) {
    return (Hashtable)_mappingProp.get(key);
  }

  /**
   * Sets the pairs propertyName, propertyID associated with the bean
   */
  public void putMappingProp(Object key, Hashtable propTable) {
    _mappingProp.put(key, propTable);
  }

  /**
   * Adds a pairs propertyName, propertyID to the key bean
   */
  public void addMappingProp(Object key, String property, String propertyRef) {
    Hashtable propTable = getMappingProp(key);
    if (propTable == null) {
      propTable = new Hashtable();
    }
    propTable.put(property, propertyRef);
    putMappingProp(key, propTable);
  }

  /**
   * Returns the properties initialized int the bean
   */
  public Collection getMappingBeanProp(Object key) {
    return (Set)_mappingBeanProp.get(key);
  }

  /**
   * Sets the list of properties associated with the bean
   */
  public void putMappingBeanProp(Object key, Set propList) {
    _mappingBeanProp.put(key, propList);
  }

  /**
   * Adds a properties in the list of props associated with the bean
   */
  public void addMappingBeanProp(Object key, String property) {
    Set propList = (Set)getMappingBeanProp(key);
    if (propList == null) {
      propList = new HashSet();
    }
    propList.add(property);
    putMappingBeanProp(key, propList);
  }

  /**
   * Removes a properties from the list of props associated with the bean
   */
  public void removeMappingBeanProp(Object key, String property) {
    Set propList = (Set)getMappingBeanProp(key);
    if (propList == null) return;
    propList.remove(property);
    putMappingBeanProp(key, propList);
  }

  /**
   * Returns the id into the xslt of the property defined by "sourceNode+propertyName"
   */
  public String getMappingSourceNode(String key) {
    return (String)_mappingSourceNode.get(key);
  }

  /**
   * Adds a mapping between a pair "sourceNode+propertyName" and the 'id' of
   * the property element into the XSL tree
   */
  public void putMappingSourceNode(String key, String value) {
    _mappingSourceNode.put(key, value);
  }

  /**
   * Returns the name of the attribute used to memorize the unique Identifier of a node
   **/
  public String getEltIdName() {
    return _eltIdName;
  }

  /**
   * Returns the prefix used to name a node
   **/
  public String getEltIdPrefix() {
    return _eltIdPrefix;
  }

  /**
   * Sets the value of the last named node
   **/
  public void setEltIdNum(int num) {
    _eltIdNum = num;
  }

  /**
   * Increments the value of the last named node
   **/
  public void incrementEltIdNum() {
    _eltIdNum += 1;
  }

  /**
   * The number of the last named node
   * <p>
   * The next one will be named <_eltIdPrefix><_eltIdNum>
   **/
  public int getEltIdNum() {
    return _eltIdNum;
  }
}
