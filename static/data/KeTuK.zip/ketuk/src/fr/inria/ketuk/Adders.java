/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
 * A Collection of methods to add an object into another one
 *
 * @author Claude Pasquier
 */
public class Adders {

  /**
   * Default constructor
   */
  public Adders() {
  }

  /**
   * Adder for an object of class Component into a Container
   *
   *  @param parent    the container of the component
   *  @param comp      the component to add
   **/
  public void add(Container parent, Component comp) {
    parent.add(comp);
  }

  /**
   * Adder for an object of class Component at a given position into a Container
   *
   *  @param parent    the container of the component
   *  @param comp      the component to add
   *  @param index     the position where to add the component
   **/
  public void add(Container parent, Component comp, int index) {
    parent.add(comp, index);
  }

  /**
   * Adder for an object of class Component into a Container with a given constraint
   *
   *  @param parent         the container of the component
   *  @param comp           the component to add
   *  @param constraints    the constraints used to add teh component
   **/
   public void add(Container parent, Component comp, Object constraints) {
     parent.add(comp, constraints);
   }

  /**
   * Adder for an object of class Component at a given position
   * into a Container with a given constraint
   *
   *  @param parent         the container of the component
   *  @param comp           the component to add
   *  @param constraints    the constraints used to add teh component
   *  @param index          the position where to add the component
   **/
  public void add(Container parent, Component comp, Object constraints, int index) {
    parent.add(comp, constraints, index);
  }

  /**
   * Adder for an object of class Component into a JFrame
   *
   *  @param parent         the JFrame where to add the component
   *  @param comp           the component to add
   **/
  public void add(JFrame parent, Component comp) {
    parent.getContentPane().add(comp);
  }

  /**
   * Adder for an object of class Component at a given position
   * into a JFrame
   *
   *  @param parent         the JFrame where to add the component
   *  @param comp           the component to add
   *  @param index          the position where to add the component
   **/
  public void add(JFrame parent, Component comp, int index) {
    parent.getContentPane().add(comp, index);
  }

  /**
   * Adder for an object of class Component
   * into a JFrame with a given constraint
   *
   *  @param parent         the JFrame where to add the component
   *  @param comp           the component to add
   *  @param constraints    the constraints used to add teh component
   **/
   public void add(JFrame parent, Component comp, Object constraints) {
     parent.getContentPane().add(comp, constraints);
   }

  /**
   * Adder for an object of class Component at a given position
   * into a JFrame with a given constraint
   *
   *  @param parent         the JFrame where to add the component
   *  @param comp           the component to add
   *  @param constraints    the constraints used to add teh component
   *  @param index          the position where to add the component
   **/
  public void add(JFrame parent, Component comp, Object constraints, int index) {
    parent.getContentPane().add(comp, constraints, index);
  }

  /**
   * Adder for an object of class MenuItem into a Menu
   *
   *  @param menu           the Menu where to add the item
   *  @param item           the menuItem to add
   **/
  public void add(Menu menu, MenuItem item) {
    menu.add(item);
  }

  /**
   * Adder for an object of class String into a Menu
   *
   *  @param menu           the Menu where to add the string
   *  @param label          the string to add
   **/
  public void add(Menu menu, String label) {
    menu.add(label);
  }

  /**
   * Adder for an object of class Menu into a MenuBar
   *
   *  @param menubar           the MenuBar where to add the menu
   *  @param manu              the Menu to add
   **/
  public void add(MenuBar menubar, Menu menu) {
    menubar.add(menu);
  }

  /**
   * Adder for an object of class String into a JMenu
   *
   *  @param menu           the JMenu where to add the string
   *  @param label          the string to add
   **/
  public void add(JMenu menu, String label) {
    menu.add(label);
  }

  /**
   * Adder for an object into a Vector
   *
   *  @param parent           the Vector where to add the object
   *  @param obj              the object to add
   **/
  public void add(Vector parent, Object obj) {
    parent.addElement(obj);
  }

  /**
   * Adder for an object at a specified position into a Vector
   *
   *  @param parent           the Vector where to add the object
   *  @param obj              the object to add
   *  @param index            the position where to add the object
   **/
  public void add(Vector parent, Object obj, int index) {
    parent.insertElementAt(obj, index);
  }

  /**
   * Adder for a pair key, value into a Dictionary
   *
   *  @param parent           the Dictionary where to add the pair
   *  @param key              the object to add
   *  @param value            the value of the object to add
   **/
  public void add(Dictionary parent, Object key, Object value) {
    parent.put(key, value);
  }

}
