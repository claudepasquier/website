/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle component events
 *
 * @author Claude Pasquier
 */
  
public class ScriptComponentHandler implements ComponentListener {
      
  public void componentHidden(ComponentEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentHidden");
  }

  public void componentMoved(ComponentEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentMoved");
  }

  public void componentResized(ComponentEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentResized");
  }

  public void componentShown(ComponentEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentShown");
  }
}
