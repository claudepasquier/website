/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

import java.awt.Component;

import fr.dyade.koala.xml.kuil.widgets.*;
import javax.swing.border.MatteBorder;
import java.awt.Color;

public class TD extends TablePanel$TD {

  private Object _parent;
  private int _borderw = -1;

  public TD() {
    super();
    setWeightx(0);
    setWeighty(0);
  }

  public void add(Object comp) {
//  Table table = (Table)(((Component)comp).getParent());
//      System.err.println("<CP> table="+table);
//  if (table != null) {
//    Component comps[] = table.getComponents();
//      System.err.println("<CP> comps="+comps);
//      System.err.println("<CP> component="+getComponent());
//  if ((comps != null) && (getComponent() != null)){ 
//    for (int i = 0 ; i < comps.length ; i++) {
//      System.err.println("<CP> i="+i);
//      if (comps[i] == getComponent()) {
// System.err.println("<CP>found: comps[i]="+comps[i]+" comp="+getComponent());
//        table.remove(i);
//        table.add((Component)comp,i);
//        break;
//      }
//    }
//  }
//  }
    setComponent((Component)comp);

    if (javax.swing.JComponent.class.isAssignableFrom(comp.getClass())) {
      if (_borderw >= 0) {
        ((javax.swing.JComponent)comp).setBorder(new MatteBorder(_borderw, _borderw, _borderw, _borderw, Color.black));
      }
    }
  }

  public void remove(Object comp) {
    setComponent(null);
  }

  public void replace(Object comp1, Object comp2) {
    setComponent((Component)comp2);

    Table table = (Table)(((Component)comp1).getParent());
    if (table != null) {
      table.removeAll();
      table.setRows(table.getRows());
    }
  }

  public void setParent(Object parent) {
    _parent = parent;
  }

  public Object getParent() {
    return _parent;
  }

  public void setBorderw(int w) {
    _borderw = w;
    Object comp = getComponent();
    if (javax.swing.JComponent.class.isAssignableFrom(comp.getClass())) {
      if (_borderw >= 0) {
        ((javax.swing.JComponent)comp).setBorder(new MatteBorder(_borderw, _borderw, _borderw, _borderw, Color.black));
      }
    }
  }

  public int getBorderw() {
    return _borderw;
  }
}
