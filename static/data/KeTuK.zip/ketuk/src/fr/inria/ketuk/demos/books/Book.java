package fr.inria.ketuk.demos.books;

import fr.inria.ketuk.widgets.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Container;

public class Book extends JPanel implements MouseListener  {

  JTextField titleField   = null;
  JTextField authorField  = null;
  JTextField isbnField    = null;
  JTextField nbPagesField = null;
  JTextPane synopsisField = null;
  JTextField priceField   = null;
  JLabel ratingField = null;

  String title = null;
  String author = null;
  String isbn = null;
  String nbPages = null;
  String synopsis = null;
  String price = null;
  String imageLocation = null;

  ImageBox image = null;
  JButton okButton = null;
  JButton cancelButton = null;
  JButton deleteButton = null;
  JButton newButton = null;

  public Book() {
    super();
    this.setLayout(new VerticalLayout());
    HBox hbox = new HBox();

    // Cover
    image = new ImageBox();
    hbox.add(image);

    VBox vbox = new VBox();
    hbox.add(vbox);
    this.add(hbox);

    // Title
    hbox = new HBox();
    hbox.add(new JLabel("TITLE: "));
    titleField = new JTextField(40);
    hbox.add(titleField);
    vbox.add(hbox);

    // Author
    hbox = new HBox();
    hbox.add(new JLabel("AUTHOR: "));
    authorField = new JTextField(20);
    hbox.add(authorField);
    vbox.add(hbox);

    // ISBN
    hbox = new HBox();
    hbox.add(new JLabel("ISBN: "));
    isbnField = new JTextField(10);
    hbox.add(isbnField);
    vbox.add(hbox);

    // nbPages
    hbox = new HBox();
    hbox.add(new JLabel("pages: "));
    nbPagesField = new JTextField(5);
    hbox.add(nbPagesField);
    vbox.add(hbox);

    // Price
    hbox = new HBox();
    hbox.add(new JLabel("PRICE: "));
    priceField = new JTextField(5);
    hbox.add(priceField);
    vbox.add(hbox);

    //Rating
    hbox = new HBox();
    hbox.add(new JLabel("RATING: "));
    ratingField = new JLabel();
    hbox.add(ratingField);
    vbox.add(hbox);

    // Synopsis
    synopsisField = new JTextPane();
    synopsisField.setPreferredSize(new java.awt.Dimension(400,250));
    this.add(synopsisField);

    hbox = new HBox();
    okButton = new JButton("OK");
    okButton.addMouseListener(this);
    hbox.add(okButton);
    cancelButton = new JButton("Cancel");
    cancelButton.addMouseListener(this);
    hbox.add(cancelButton);
    deleteButton = new JButton("Delete");
    deleteButton.addMouseListener(this);
    hbox.add(deleteButton);
    newButton = new JButton("New");
    newButton.addMouseListener(this);
    hbox.add(newButton);
    this.add(hbox);
  }

  public void setTitle(String title) {
    System.err.println("<CP> title="+title);
    titleField.setText(title);
    this.title = title;
  }

  public void setAuthor(String author) {
    authorField.setText(author);
    this.author = author;
  }

  public void setIsbn(String isbn) {
    isbnField.setText(isbn);
    this.isbn = isbn;
  }

  public void setNbPages(String nbPages) {
    nbPagesField.setText(nbPages);
    this.nbPages = nbPages;
  }
 
  public void setPrice(String price) {
    priceField.setText(price);
    this.price = price;
  }

  public void setSynopsis(String synopsis) {
    synopsisField.setText(synopsis);
    this.synopsis = synopsis;
  }

  public void setImage(String imageLocation) {
    image.setSource(imageLocation);
    this.imageLocation = imageLocation;
  }

  public void setRating(int score) {
    if (score == 0)
      ratingField.setText("N/A");
    else
      ratingField.setIcon(new ImageIcon("images/rating-" + score + ".gif"));
  }

  public void mouseClicked(MouseEvent e) {
    if (e.getComponent() == okButton) {
      if (!image.getSource().equals(imageLocation)) {
        firePropertyChange("image", imageLocation, image.getSource());
        imageLocation = image.getSource();
      }
      if (!authorField.getText().equals(author)) {
        firePropertyChange("author", author, authorField.getText());
        author = authorField.getText();
      }
      if (!titleField.getText().equals(title)) {
        firePropertyChange("title", title, titleField.getText());
        title = titleField.getText();
      }
      if (!isbnField.getText().equals(isbn)) {
        firePropertyChange("isbn", isbn, isbnField.getText());
        isbn = isbnField.getText();
      }
      if (!nbPagesField.getText().equals(nbPages)) {
        firePropertyChange("nbPages", nbPages, nbPagesField.getText());
        nbPages = nbPagesField.getText();
      }
      if (!priceField.getText().equals(price)) {
        firePropertyChange("price", price, priceField.getText());
        price = priceField.getText();
      }
      if (!synopsisField.getText().equals(synopsis)) {
        firePropertyChange("synopsis", synopsis, synopsisField.getText());
        synopsis = synopsisField.getText();
      }
    }
    else if (e.getComponent() == cancelButton) {
      titleField.setText(title);
      authorField.setText(author);
      isbnField.setText(isbn);
      nbPagesField.setText(nbPages);
      priceField.setText(price);
      synopsisField.setText(synopsis);
      image.setSource(imageLocation);
    }
    else if (e.getComponent() == deleteButton) {
      Container parent = getParent();
      parent.remove(this);
      //      if (parent.getComponentCount() == 1) {
      //        parent.add(new Book(),0);
      //      }
    }
    else if (e.getComponent() == newButton) {
      Container parent = this.getParent();
      int index = 0;
      for ( ; index < parent.getComponentCount() ; index++) {
        if (parent.getComponent(index) == this) break;
      }
      this.getParent().add(new Book(), index);
    }
  }

  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {
  }
}
