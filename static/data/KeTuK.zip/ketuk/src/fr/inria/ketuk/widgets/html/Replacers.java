/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

public class Replacers {

  /** Constructs the convertor
   *
   */
  public Replacers() {
  }

  // replacer for a table
  public void replace(Table parent, Object obj1, Object obj2) {
    parent.replace(obj1, obj2);
  }

  // replacer for a table row
  public void replace(TR parent, Object obj1, Object obj2) {
    parent.replace(obj1, obj2);
  }

  // replacer for a table column
  public void replace(TD parent, Object obj1, Object obj2) {
    parent.replace(obj1, obj2);
  }

}
