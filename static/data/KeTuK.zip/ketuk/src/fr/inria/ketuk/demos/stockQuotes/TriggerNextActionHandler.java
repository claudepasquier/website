/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.demos.stockQuotes;

import fr.inria.ketuk.*;
import com.ibm.webaccessor.events.*;

/**
 * A listener class which handle action events
 *
 * @author Claude Pasquier
 */
  
public class TriggerNextActionHandler implements TriggerNextActionListener {
      
  public void triggerNextAction(TriggerNextActionEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "actionPerformed");
  }
}
