/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets;

import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

public class HBox extends JPanel implements MouseListener, FocusListener {

  int interword = 0;

  public HBox() {
    super();
    this.setLayout(new HorizontalLayout());
    this.addMouseListener(this);
    this.addFocusListener(this);
  }

  public void setInterword(String iw) {
    try {
      interword = Integer.decode(iw).intValue();
    }
    catch (NumberFormatException nfe) {
      System.err.println("Method setInterword in class HBox");
      System.err.println("   argument is not a number ("+iw+")");
      interword = 0;
    }
    this.setLayout(new HorizontalLayout(interword));
  }

  public String getInterword() {
    return new Integer(interword).toString();
  }

  public void mouseClicked(MouseEvent e) {
    System.err.println("<CP> mouse clicked on atom. value="+this);
    this.requestFocus();
  }

  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}

  public void focusGained(FocusEvent e) {
    System.err.println("<CP> focus gained");
    this.setBackground(Color.blue);
  }

  public void focusLost(FocusEvent e) {
    System.err.println("<CP> focus lost");
    this.setBackground(Color.gray);
  }
}
