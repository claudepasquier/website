/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.lang.Exception;

/**
 * Exception raised during the processing of a BM script
 *
 * @author Claude Pasquier
 */
public class BMException extends Exception {

  /**
   * Default constructor
   **/
  public BMException() {
    super("error during the processing of a BM script");
  }

  /**
   * Constructor with an error message specified
   **/
  public BMException(String message) {
    super(message);
  }
}
