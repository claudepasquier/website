/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.beans.*;


/**
 * A listener class which handle propertyChange events
 *
 * @author Claude Pasquier
 */
  
public class ScriptPropertyChangeHandler implements PropertyChangeListener {
      

  public void propertyChange(PropertyChangeEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
     p.processEvent(event, event.getPropertyName());
//  fr.umlv.jmmf.reflect.MultiMethod mm=fr.umlv.jmmf.reflect.MultiMethod.create(ScriptEventProcessor.class,"processEvent",2);
//  try {
//    mm.invoke(p,new Object[] {event, event.getPropertyName()});
//   }
//   catch (java.lang.Exception e) {
//     e.printStackTrace();
//   }
  }

}
