/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import org.w3c.dom.Node;
import org.w3c.dom.Document;

/**
 * Utilities to manipulate XPaths
 *
 * @author Claude Pasquier
 **/
public class XPathUtil {

  /**
   * Computes an unambiguous XPath allowing to reach sourceNode
   * from the specified baseNode
   *
   * <p>
   * if baseNode equals null, then the root of the DOM tree is used
   * 
   *  @param base        the base of the XPAth
   *  @param sourceNode  the node that has to be pointed by the XPath
   *
   *  @return            the resulting XPath
   **/
  public static String computeXPath(Node base, Node sourceNode) {
    if (sourceNode == null) return null;
    Node baseNode = base;
    if (base == null) baseNode = sourceNode.getOwnerDocument().getDocumentElement();
    else if (base.getNodeType() == Node.DOCUMENT_NODE) baseNode = ((Document)base).getDocumentElement();
    StringBuffer s = new StringBuffer();
    Node n = sourceNode;
    while ((n != null) && (n != baseNode)){// && (n.getNodeType() != Node.DOCUMENT_NODE)) {
      int index = 0;
      Node n1 = n;
      if (n.getNodeType() == Node.ELEMENT_NODE) {
        while (n1 != null) {
          if (n1.getNodeType() == Node.ELEMENT_NODE) index += 1;
          n1 = n1.getPreviousSibling();
        }
      }
      else if (n.getNodeType() == Node.TEXT_NODE) {
        while (n1 != null) {
          if (n1.getNodeType() == Node.TEXT_NODE) index += 1;
          n1 = n1.getPreviousSibling();
        }
      }
      if (s.length() > 0) s.insert(0,'/');
      if (n.getNodeType() == Node.TEXT_NODE) {
        s.insert(0, "text()["+index+"]");
      }
      else {
        s.insert(0, "*["+index+"]");
      }
      n = n.getParentNode();
    }
    if ((base == null) || (baseNode.getNodeType() == Node.DOCUMENT_NODE)) {
      if (s.length() > 0) s.insert(0,"/*[1]/");
      else s.insert(0,"/*[1]");
    }
    if ((baseNode != null) && (n == null)) {
      System.err.println("Warning. the base node used for the computation");
      System.err.println("of an XPath was not found. using the rootNode instead");
    }
    return s.toString();
  }
}
