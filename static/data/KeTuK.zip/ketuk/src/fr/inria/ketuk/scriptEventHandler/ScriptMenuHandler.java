/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle menu events
 *
 * @author Claude Pasquier
 */
  
public class ScriptMenuHandler implements MenuListener {
      

  public void menuCanceled(MenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuCanceled");
  }
  public void menuDeselected(MenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuDeselected");
  }
  public void menuSelected(MenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuSelected");
  }


}
