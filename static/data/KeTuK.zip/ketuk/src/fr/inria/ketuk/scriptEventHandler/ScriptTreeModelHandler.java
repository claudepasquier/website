/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle treeModel events
 *
 * @author Claude Pasquier
 */
  
public class ScriptTreeModelHandler implements TreeModelListener {
      

  public void treeNodesChanged(TreeModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeNodesChanged");
  }

  public void treeNodesInserted(TreeModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeNodesInserted");
  }

  public void treeNodesRemoved(TreeModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeNodesRemoved");
  }

  public void treeStructureChanged(TreeModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "treeStructureChanged");
  }
}
