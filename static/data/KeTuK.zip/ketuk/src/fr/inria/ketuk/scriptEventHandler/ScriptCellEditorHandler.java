/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle ancestor events
 *
 * @author Claude Pasquier
 */
  
public class ScriptCellEditorHandler implements CellEditorListener {
      

  public void editingCanceled(ChangeEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "editingChanceled");
  }

  public void editingStopped(ChangeEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "editingStopped");
  }
}
