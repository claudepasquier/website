/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle listData events
 *
 * @author Claude Pasquier
 */
  
public class ScriptListDataHandler implements ListDataListener {

  public void contentsChanged(ListDataEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "contentsChanged");
  }

  public void intervalAdded(ListDataEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "intervalAdded");
  }

  public void intervalRemoved(ListDataEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "intervalRemoved");
  }

}
