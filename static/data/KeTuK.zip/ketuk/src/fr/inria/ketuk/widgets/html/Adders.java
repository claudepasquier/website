/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

public class Adders {

  /** Constructs the convertor
   *
   */
  public Adders() {
  }

  // adder for a table
  public void add(Table parent, Object obj) {
    parent.add(obj);
  }

  // adder for a table row
  public void add(TR parent, Object obj) {
    parent.add(obj);
  }

  // adder for a table column
  public void add(TD parent, Object obj) {
    parent.add(obj);
  }

}
