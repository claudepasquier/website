/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle focus events
 *
 * @author Claude Pasquier
 */
  
public class ScriptFocusHandler implements FocusListener {
      
  public void focusGained(FocusEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "focusGained");
  }

  public void focusLost(FocusEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "focusLost");
  }
}
