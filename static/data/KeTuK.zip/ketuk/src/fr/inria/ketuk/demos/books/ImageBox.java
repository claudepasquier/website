package fr.inria.ketuk.demos.books;

import javax.swing.*;
import javax.swing.text.*;
import java.net.*;
import java.awt.event.*;

public class ImageBox extends JLabel implements MouseListener {

  private String sourceUrl;

  public ImageBox() {
    super();
    this.addMouseListener(this);
  }

  public void setSourceUrl(URL url) {
    ImageIcon image = new ImageIcon(url);
    if (image.getIconWidth() == -1) {
      image = new ImageIcon("images/cover.jpg");
      sourceUrl = "";
    }
    else {
      sourceUrl = url.toString();
    }
    this.setIcon(image);
  }

  public void setSource(String imageLocation) {
    sourceUrl = imageLocation;
    URL urlImage = null;
    try {
      urlImage = new URL(imageLocation);
    }
    catch (MalformedURLException mue) {
      ImageIcon image = new ImageIcon(imageLocation);
      if (image.getIconWidth() == -1) {
        image = new ImageIcon("images/cover.jpg");
        sourceUrl = "";
      }
      this.setIcon(image);
      return;
    }
    setSourceUrl(urlImage);
  }

  public String getSource() {
    return sourceUrl;
  }

  public void mouseClicked(MouseEvent e) {
    if (e.getClickCount() != 2) return;
    //Create a file chooser
    final JFileChooser fc = new JFileChooser("~");
    //In response to a button click:
    int returnVal = fc.showOpenDialog(this);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
      java.io.File file = fc.getSelectedFile();
      if (file != null) {
        setSource(file.toString());
      }
    }
  }

  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}
}

