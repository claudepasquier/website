package fr.inria.ketuk.demos.stockQuotes;

import XmlUtil;
import XPathAPI;
import org.w3c.dom.*;
import org.xml.sax.*;
import java.util.*;
import java.io.StringReader;

public class StockQuotesParser {

  private static XmlUtil _xml = new XmlUtil();

  private Vector stocks = new Vector();

  public StockQuotesParser() {
  }

  public StockQuotesParser(String xmlContent) {
    setQuotes(xmlContent);
  }

  public void setQuotes(String xmlContent) {
      InputSource is = new InputSource(new StringReader(xmlContent));
    Document doc = null;
    try {
      doc = _xml.readDocument(is);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    Element quoteElt = _xml.getFirstChildElement(doc.getDocumentElement());
    while (quoteElt != null) {
      if ("stock_quote".equals(quoteElt.getTagName())) {
        QuoteRecord qr = new QuoteRecord();
        try {
          Node n =  XPathAPI.selectSingleNode(quoteElt, "symbol/text()");
          if (n != null) qr.setSymbol(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "when/date/text()");
          if (n != null) qr.setDate(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "when/time/text()");
          if (n != null) qr.setTime(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "price[@type='ask']/@value");
          if (n != null) qr.setAsk(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "price[@type='open']/@value");
          if (n != null) qr.setOpen(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "price[@type='dayhigh']/@value");
          if (n != null) qr.setDayhigh(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "price[@type='daylow']/@value");
          if (n != null) qr.setDaylow(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "change/text()");
          if (n != null) qr.setChange(n.getNodeValue());
          n = XPathAPI.selectSingleNode(quoteElt, "volume/text()");
          if (n != null) qr.setVolume(n.getNodeValue());
        }
        catch (Exception e) {
          e.printStackTrace();
        }
        int index = 0;
        boolean elementFound = false;
        for (Enumeration e = stocks.elements() ; e.hasMoreElements() ;) {
          QuoteRecord quoteElement = (QuoteRecord)e.nextElement();
          if ((qr.getSymbol() != null)
              && (quoteElement != null)
              && (qr.getSymbol().equals(quoteElement.getSymbol()))) {
            stocks.setElementAt(qr, index);
            elementFound = true;
            break;
          }
          index += 1;
        }
        if (!elementFound) stocks.addElement(qr);
      }
      quoteElt = _xml.getNextElement(quoteElt);
    }
  }

    // getters
    public String getSymbol(int i)  {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getSymbol();
    }

    public String getDate(int i)    {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getDate();
    }

    public String getTime(int i)    {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getTime();
    }

    public String getAsk(int i)     {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getAsk();
    }

    public String getOpen(int i)    {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getOpen();
    }

    public String getDayhigh(int i) {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getDayhigh();
    }

    public String getDaylow(int i)  {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getDaylow();
    }

    public String getChange(int i)  {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getChange();
    }

    public String getVolume(int i)  {
      QuoteRecord quote = (QuoteRecord)stocks.elementAt(i);
      return (quote == null) ? null : quote.getVolume();
    }


  private QuoteRecord getQuoteElement(int i) {
    if (stocks.size() <= i) {
      stocks.setSize(i+1);
    }
    QuoteRecord qr = (QuoteRecord)stocks.elementAt(i);
    if (qr == null) {
      qr = new QuoteRecord();
      stocks.setElementAt(qr, i);
    }
    return qr;
  }

    // setters
    public void setSymbol(int i, String s)  {
      QuoteRecord quote = getQuoteElement(i);
      quote.setSymbol(s);
    }

    public void setDate(int i, String d)    {
      QuoteRecord quote = getQuoteElement(i);
      quote.setDate(d);
    }

    public void setTime(int i, String t)    {
      QuoteRecord quote = getQuoteElement(i);
      quote.setTime(t);
    }

    public void setAsk(int i, String a)     {
      QuoteRecord quote = getQuoteElement(i);
      quote.setAsk(a);
    }

    public void setOpen(int i, String o)    {
      QuoteRecord quote = getQuoteElement(i);
      quote.setOpen(o);
    }

    public void setDayhigh(int i, String h) {
      QuoteRecord quote = getQuoteElement(i);
      quote.setDayhigh(h);
    }

    public void setDaylow(int i, String l)  {
      QuoteRecord quote = getQuoteElement(i);
      quote.setDaylow(l);
    }

    public void setChange(int i, String c)  {
      QuoteRecord quote = getQuoteElement(i);
      quote.setChange(c);
    }

    public void setVolume(int i, String v)  {
      QuoteRecord quote = getQuoteElement(i);
      quote.setVolume(v);
    }


  private class QuoteRecord {
    private String _symbol = null;
    private String _date = null;
    private String _time = null;
    private String _ask = null;
    private String _open = null;
    private String _dayhigh = null;
    private String _daylow = null;
    private String _change = null;
    private String _volume = null;

    // getters
    String getSymbol()  { return _symbol;}
    String getDate()    { return _date;}
    String getTime()    { return _time;}
    String getAsk()     { return _ask;}
    String getOpen()    { return _open;}
    String getDayhigh() { return _dayhigh;}
    String getDaylow()  { return _daylow;}
    String getChange()  { return _change;}
    String getVolume()  { return _volume;}

    // setters
    void setSymbol(String s)  { _symbol = s;}
    void setDate(String d)    { _date = d;}
    void setTime(String t)    { _time = t;}
    void setAsk(String a)     { _ask = a;}
    void setOpen(String o)    { _open = o;}
    void setDayhigh(String h) { _dayhigh = h;}
    void setDaylow(String l)  { _daylow = l;}
    void setChange(String c)  { _change = c;}
    void setVolume(String v)  { _volume = v;}
  }
}
