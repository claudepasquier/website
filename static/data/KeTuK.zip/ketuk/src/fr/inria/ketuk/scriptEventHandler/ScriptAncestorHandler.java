/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle ancestor events
 *
 * @author Claude Pasquier
 */
  
public class ScriptAncestorHandler implements AncestorListener {
      

  public void ancestorAdded(AncestorEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "ancestorAdded");
  }

  public void ancestorMoved(AncestorEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "ancestorMoved");
  }

  public void ancestorRemoved(AncestorEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "ancestorreMoved");
  }

}
