/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

import javax.swing.*;
import java.awt.Font;

public class Label extends JLabel {

  public Label() {
    super();
  }

  public Label(String value) {
    super(value);
  }

  public void setStyle(String fontModifier) {
    Font f = getFont();
    if ("h4".equalsIgnoreCase(fontModifier)) {
      setFont(f.deriveFont((float)f.getSize2D() * (float)1.1));
    }
    else if ("h3".equalsIgnoreCase(fontModifier)) {
      setFont(f.deriveFont((float)f.getSize2D()* (float)1.25));
    }
    else if ("h2".equalsIgnoreCase(fontModifier)) {
      setFont(f.deriveFont((float)f.getSize2D()* (float)1.5));
    }
    else if ("h1".equalsIgnoreCase(fontModifier)) {
      setFont(f.deriveFont((float)f.getSize2D()* (float)2.0));
    }
    else if ("b".equalsIgnoreCase(fontModifier)) {
      setFont(f.deriveFont(Font.BOLD));
    }
  }


}
