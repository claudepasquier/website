/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle tableColumnModel events
 *
 * @author Claude Pasquier
 */
  
public class ScriptTableColumnModelHandler implements TableColumnModelListener {
      
  public void columnAdded(TableColumnModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "columnAdded");
  }

  public void columnMarginChanged(ChangeEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "columnMarginChanged");
  }

  public void columnMoved(TableColumnModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "columnMoved");
  }

  public void columnRemoved(TableColumnModelEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "columnRemoved");
  }

  public void columnSelectionChanged(ListSelectionEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "columnSelectionChanged");
  }
}
