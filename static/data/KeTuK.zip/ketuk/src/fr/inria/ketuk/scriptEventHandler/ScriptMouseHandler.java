/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle mouse events
 *
 * @author Claude Pasquier
 */
  
public class ScriptMouseHandler implements MouseListener {
      
  public void mouseClicked(MouseEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "mouseClicked");
  }

  public void mouseEntered(MouseEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "mouseEntered");
  }

  public void mouseExited(MouseEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "mouseExited");
  }

  public void mousePressed(MouseEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "mousePressed");
  }

  public void mouseReleased(MouseEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "mouseReleased");
  }
}
