/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets;

import javax.swing.*;
import javax.swing.text.*;
import java.net.*;
import java.awt.event.*;
import javax.swing.event.*;

public class TextBox extends JTextPane implements KeyListener, DocumentListener {
  private String[] content = new String[10];
  private String[] style = new String[10];

  public TextBox() {
    super();
    initStyles();
    Document doc = getDocument();
    doc.addDocumentListener(this);
    for (int i = 0 ; i < 10 ; i++) {
      style[i] = "regular";
    }
    this.setPreferredSize(new java.awt.Dimension(400,100));
  }

  public void setElt(int a, String c) {
    Document doc = getDocument();
    try {
      doc.insertString(doc.getLength(), c,
                       getStyle(style[a]));
    }
    catch (BadLocationException ble) {
      System.err.println("Couldn't insert initial text.");
      System.exit(0);
    }
    catch (Exception e) {
      System.err.println("Exception in TextBox");
      System.exit(0);
    }
    initContent();
  }

  private void initContent() {
    Document doc = getDocument();
    int count = 0;
    if (doc.getDefaultRootElement().getElementCount() >1) count = 1;
    Element elt = doc.getDefaultRootElement().getElement(count);
    // elt represents the first paragraph
    int offset = 0;
    for (int i = 0 ; i < elt.getElementCount() ; i++) {
      int endOffset = elt.getElement(i).getEndOffset();
      try {
        content[i] = doc.getText(offset, endOffset-offset);
      }
      catch (BadLocationException ble) {
        ble.printStackTrace();
      }
      offset = endOffset;
    }
  }

  public String  getElt(int a) {
    Document doc = getDocument();
    int count = 0;
    if (doc.getDefaultRootElement().getElementCount() >1) count = 1;
    Element elt = doc.getDefaultRootElement().getElement(count);
    // elt represents the first paragraph
    int offset = 0;
    if (a > 0) offset = elt.getElement(a-1).getEndOffset();
    int endOffset = elt.getElement(a).getEndOffset();
    String strContent = null;
    try {
        strContent = doc.getText(offset, endOffset-offset);
    }
    catch (BadLocationException ble) {
      ble.printStackTrace();
    }
    return strContent;
  }

  public void setStyle(int a, String s) {
    System.err.println("<CP> style no "+a+" is set to "+s);
    style[a] = s;
  }

  protected void initStyles() {
    //Initialize some styles.
    Style def = StyleContext.getDefaultStyleContext().
      getStyle(StyleContext.DEFAULT_STYLE);

    Style regular = addStyle("regular", def);
    StyleConstants.setFontFamily(def, "SansSerif");

    Style s = addStyle("italic", regular);
    StyleConstants.setItalic(s, true);

    s = addStyle("bold", regular);
    StyleConstants.setBold(s, true);

    s = addStyle("small", regular);
    StyleConstants.setFontSize(s, 10);

    s = addStyle("large", regular);
    StyleConstants.setFontSize(s, 16);
  }

  public void keyTyped(KeyEvent e) {}

  public void keyPressed(KeyEvent e) {
  }

  public void keyReleased(KeyEvent e) {}

  public void changedUpdate(DocumentEvent e) {
    String[] oldContent = new String[10];
    for (int i = 0 ; i < content.length ; i++) {
      oldContent[i] = content[i];
    }

    initContent();
    firePropertyChange("elt", oldContent, content);
  }

  public void insertUpdate(DocumentEvent e) {
    String[] oldContent = new String[10];
    for (int i = 0 ; i < content.length ; i++) {
      oldContent[i] = content[i];
    }

    initContent();
    firePropertyChange("elt", oldContent, content);
  }

  public void removeUpdate(DocumentEvent e) {
    String[] oldContent = new String[10];
    for (int i = 0 ; i < content.length ; i++) {
      oldContent[i] = content[i];
    }

    initContent();
    firePropertyChange("elt", oldContent, content);
  }
}

