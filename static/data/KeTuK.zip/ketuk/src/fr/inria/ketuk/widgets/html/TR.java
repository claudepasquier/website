/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

import fr.dyade.koala.xml.kuil.widgets.*;

public class TR extends TablePanel$TR {

  private int _borderw = -1;
  private Object _parent;

  public TR() {
    super();
  }

  public void setCols(TD[] cols) {
    super.setCols(cols);
    for (int i = 0 ; i < cols.length ; i++) {
      cols[i].setParent(this);
      cols[i].setBorderw(_borderw);
    }
  }

  public void add(Object tableCol) {
    Object[] oldCols = (Object[])getCols();
    int nbCol = oldCols == null ? 0 : oldCols.length;
    TD[] newCols = new TD[nbCol+1];
    for (int i = 0 ; i < nbCol ; i++) {
      newCols[i] = (TD)oldCols[i];
    }
    newCols[nbCol] = (TD)tableCol;
    setCols(newCols);
  }

  public void remove(Object tableCol) {
    Object[] oldCols = (Object[])getCols();
    int nbCol = oldCols == null ? 0 : oldCols.length;
    TD[] newCols = new TD[nbCol-1];
    int index = 0;
    for (int i = 0 ; i < nbCol ; i++) {
      if (tableCol != oldCols[i]) {
        newCols[index] = (TD)oldCols[i];
        index++;
      }
    }
    setCols(newCols);
  }

  public void replace(Object oldTableCol, Object newTableCol) {
    Object[] cols = (Object[])getCols();
    int nbCol = cols == null ? 0 : cols.length;
    for (int i = 0 ; i < nbCol ; i++) {
      if (oldTableCol == cols[i]) {
        cols[i] = (TD)newTableCol;
      }
    }
  }

  public void setParent(Object parent) {
    _parent = parent;
  }

  public Object getParent() {
    return _parent;
  }

  public void setBorderw(int w) {
    _borderw = w;
    Object[] cols = (Object[])getCols();
    int nbCol = cols == null ? 0 : cols.length;
    for (int i = 0 ; i < nbCol ; i++) {
      ((TD)cols[i]).setBorderw(_borderw);
    }
  }

  public int getBorderw() {
    return _borderw;
  }
}
