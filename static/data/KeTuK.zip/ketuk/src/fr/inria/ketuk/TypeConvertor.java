/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

/**
 * A Collection of methods which convert an object of one type to one of another type.
 *
 * @author Claude Pasquier
 */
public class TypeConvertor {

  /**
   * Default constructor
   */
  TypeConvertor() {
  }

  /**
   * Default convertor for an object of class Object
   *
   * @param obj    the object to convert
   * @param target the desired class
   *
   * @return a new object of the desired class
   *
   **/
  public Object convert(Object obj, Class target)
    throws java.lang.ClassCastException,
           java.lang.NumberFormatException {
    if ((obj == null) 
        || target.isInstance(obj)
        || target.isAssignableFrom(obj.getClass()))
      return obj;
    
    if (target == String.class) {
      return obj.toString();
    }

    throw new java.lang.ClassCastException("impossible conversion from "
                                           + "an object of class "
                                           + obj.getClass().getName()
                                           + " to an object of class "
                                           + target.getName() +".");
  }

  /**
   * Default convertor for an object of class String
   *
   * @param str    the string to convert
   * @param target the desired class
   *
   * @return a new object of the desired class
   *
   **/
  public Object convert(String str, Class target)
    throws java.lang.ClassCastException,
    java.lang.NumberFormatException {
    if ((str == null) 
        || target.isInstance(str)
        || target.isAssignableFrom(str.getClass()))
      return str;

    if (target == boolean.class) {
      return new Boolean(str);
    }
    if (target == byte.class) {
      if ("".equals(str)) str = "0";
      return new Byte(str);
    }
    if (target == char.class) {
      if (str.length() != 1) {
        throw new java.lang.ClassCastException("incompatible value for data of type char");
      }
      return new Character(str.charAt(0));
    }
    if (target == short.class) {
      if ("".equals(str)) str = "0";
      return new Short(str);
    }
    if (target == int.class) {
      if ("".equals(str)) str = "0";
      return new Integer(str);
    }
    if (target == long.class) {
      if ("".equals(str)) str = "0";
      return new Long(str);
    }
    if (target == float.class) {
      if ("".equals(str)) str = "0";
      return new Float(str);
    }
    if (target == double.class) {
      if ("".equals(str)) str = "0";
      return new Double(str);
    }
    if (target == java.awt.Color.class) {
      Integer c = Integer.decode(str);
      return new java.awt.Color(c.intValue());
    }
    throw new java.lang.ClassCastException("impossible conversion from "
                                           + "an object of class "
                                           + str.getClass().getName()
                                           + " to an object of class "
                                           + target.getName() +".");
  }

  /**
   * Default convertor for an object of class Number
   *
   * @param n      the number to convert
   * @param target the desired class
   *
   * @return a new object of the desired class
   *
   **/
  public Object convert(Number n, Class target)
    throws java.lang.ClassCastException,
    java.lang.NumberFormatException {
    if ((n == null) 
        || target.isInstance(n)
        || target.isAssignableFrom(n.getClass()))
      return n;
    
    if (target == byte.class) {
      return new Byte(n.byteValue());
    }
    if (target == short.class) {
      return new Short(n.shortValue());
    }
    if (target == int.class) {
      return new Integer(n.intValue());
    }
    if (target == long.class) {
      return new Long(n.longValue());
    }
    if (target == float.class) {
      return new Float(n.floatValue());
    }
    if (target == double.class) {
      return new Double(n.doubleValue());
    }
    if (target == String.class) {
      return n.toString();
    }
    if (target == java.awt.Color.class) {
      return new java.awt.Color(n.intValue());
    }
    throw new java.lang.ClassCastException("impossible conversion from "
                                           + "an object of class "
                                           + n.getClass().getName()
                                           + " to an object of class "
                                           + target.getName() +".");
  }

  /**
   * Default convertor for an object of class Boolean
   *
   * @param b      the boolean to convert
   * @param target the desired class
   *
   * @return a new object of the desired class
   *
   **/
  public Object convert(Boolean b, Class target)
    throws java.lang.ClassCastException,
    java.lang.NumberFormatException {
    if ((b == null) 
        || target.isInstance(b)
        || target.isAssignableFrom(b.getClass()))
      return b;
    
    if (target == String.class) {
      return b.toString();
    }
    if (target == boolean.class) {
      return b;
    }
    throw new java.lang.ClassCastException("impossible conversion from "
                                           + "an object of class "
                                           + b.getClass().getName()
                                           + " to an object of class "
                                           + target.getName() +".");
  }
}
