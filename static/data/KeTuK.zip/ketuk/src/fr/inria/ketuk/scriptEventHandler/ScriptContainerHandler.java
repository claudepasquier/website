/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle container events
 *
 * @author Claude Pasquier
 */
  
public class ScriptContainerHandler implements ContainerListener {
      
  public void componentAdded(ContainerEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentAdded");
  }

  public void componentRemoved(ContainerEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "componentRemoved");
  }
}
