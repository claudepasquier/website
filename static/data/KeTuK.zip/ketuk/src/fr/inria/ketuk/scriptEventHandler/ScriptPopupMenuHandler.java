/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle popupMenu events
 *
 * @author Claude Pasquier
 */
  
public class ScriptPopupMenuHandler implements PopupMenuListener {
      

  public void popupMenuCanceled(PopupMenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "popupMenuCanceled");
  }

  public void popupMenuWillBecomeInvisible(PopupMenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "popupMenuWillBecomeInvisible");
  }

  public void popupMenuWillBecomeVisible(PopupMenuEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "popupMenuWillBecomeVisible");
  }
}
