/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets;

import java.awt.*;
import java.util.Vector;

public class VerticalLayout implements LayoutManager {
  private int vgap;
  private int indent;
  private int minWidth = 0, minHeight = 0;
  private int preferredWidth = 0, preferredHeight = 0;
  private boolean sizeUnknown = true;

  public VerticalLayout() {
    this(0,0);
  }

  public VerticalLayout(int il, int id) {
    vgap = il;
    indent = id;
  }
  
  /* Required by LayoutManager. */
  public void addLayoutComponent(String name, Component comp) {
  }

  /* Required by LayoutManager. */
  public void removeLayoutComponent(Component comp) {
  }

  private void setSizes(Container parent) {
    int nComps = parent.getComponentCount();
    Dimension d = null;

    //Reset preferred/minimum width and height.
    preferredWidth = 0;
    preferredHeight = 0;
    minWidth = 0;
    minHeight = 0;

    boolean firstVisibleComponent = true;
    for (int i = 0; i < nComps; i++) {
      Component c = parent.getComponent(i);
      if (c.isVisible()) {
        d = c.getPreferredSize();
        if (firstVisibleComponent) {
          preferredWidth = indent + d.width;
          preferredHeight = d.height;
          firstVisibleComponent = false;
        }
        else {
          preferredWidth = Math.max(preferredWidth, indent + d.width);
          preferredHeight += vgap + d.height;
        }

        minWidth = Math.max(c.getMinimumSize().width + indent, minWidth);
        minHeight = preferredHeight;
      }
    }
  }


  /* Required by LayoutManager. */
  public Dimension preferredLayoutSize(Container parent) {
    Dimension dim = new Dimension(0, 0);
    int nComps = parent.getComponentCount();

    setSizes(parent);

    //Always add the container's insets!
    Insets insets = parent.getInsets();
    dim.width = preferredWidth 
      + insets.left + insets.right;
    dim.height = preferredHeight 
      + insets.top + insets.bottom;

    sizeUnknown = false;

    return dim;
  }

  /* Required by LayoutManager. */
  public Dimension minimumLayoutSize(Container parent) {
    Dimension dim = new Dimension(0, 0);
    int nComps = parent.getComponentCount();

    //Always add the container's insets!
    Insets insets = parent.getInsets();
    dim.width = minWidth 
      + insets.left + insets.right;
    dim.height = minHeight 
      + insets.top + insets.bottom;
    
    sizeUnknown = false;
    
    return dim;
  }

  /* Required by LayoutManager. */
  /* 
   * This is called when the panel is first displayed, 
   * and every time its size changes. 
   * Note: You CAN'T assume preferredLayoutSize or 
   * minimumLayoutSize will be called -- in the case 
   * of applets, at least, they probably won't be. 
   */
  public void layoutContainer(Container parent) {
    Insets insets = parent.getInsets();
    int maxWidth = parent.getSize().width
      - (insets.left + insets.right);
    int maxHeight = parent.getSize().height
      - (insets.top + insets.bottom);
    int nComps = parent.getComponentCount();
    int previousWidth = 0, previousHeight = 0;
    int x = 0, y = insets.top;

    x = indent;

    // Go through the components' sizes, if neither 
    // preferredLayoutSize nor minimumLayoutSize has 
    // been called.
    if (sizeUnknown) {
      setSizes(parent);
    }
    
    for (int i = 0 ; i < nComps ; i++) {
      Component c = parent.getComponent(i);
      if (c.isVisible()) {
        Dimension d = c.getPreferredSize();
                
        // increase x and y, if appropriate
        if (i > 0) { 
          y += previousHeight + vgap;
        }
                

        // Set the component's size and position.
        c.setBounds(x, y, d.width, d.height);

        previousWidth = d.width;
        previousHeight = d.height;
      }
    }
  }
  
  public String toString() {
    String str = "";
    return getClass().getName() + "[vgap=" + vgap + str + "]";
  }
}
