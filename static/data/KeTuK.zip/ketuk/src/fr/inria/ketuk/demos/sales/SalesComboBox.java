package fr.inria.ketuk.demos.sales;

import javax.swing.JComboBox;

public class SalesComboBox extends JComboBox {

  private String[] keys;

  public SalesComboBox(String[] keys, Object[] items) {
    super(items);
    this.keys = keys;
  }

  public void setSelectedId(String key) {
    int index = -1;
    for (int i = 0 ; i < keys.length ; i++) {
      if (!keys[i].equals(key)) continue;
      index = i;
      break;
    }
    if (index > -1) setSelectedIndex(index);
  }

  public String getSelectedId() {
    return keys[getSelectedIndex()];
  }
}
