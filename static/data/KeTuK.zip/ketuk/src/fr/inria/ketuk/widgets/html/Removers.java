/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets.html;

public class Removers {

  /** Constructs the convertor
   *
   */
  public Removers() {
  }

  // remover for a table
  public void remove(Table parent, Object obj) {
    parent.remove(obj);
  }

  // remover for a table row
  public void remove(TR parent, Object obj) {
    parent.remove(obj);
  }

  // remover for a table column
  public void remove(TD parent, Object obj) {
    parent.remove(obj);
  }
}
