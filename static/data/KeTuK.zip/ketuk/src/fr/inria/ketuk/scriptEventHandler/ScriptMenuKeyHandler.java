/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle menuKey events
 *
 * @author Claude Pasquier
 */
  
public class ScriptMenuKeyHandler implements MenuKeyListener {
      
  public void menuKeyPressed(MenuKeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuKeyPressed");
  }

  public void menuKeyReleased(MenuKeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuKeyReleased");
  }
  public void menuKeyTyped(MenuKeyEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "menuKeyTyped");
  }
}
