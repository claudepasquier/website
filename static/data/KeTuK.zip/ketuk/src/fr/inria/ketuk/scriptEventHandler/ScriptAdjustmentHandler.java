/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle adjustment events
 *
 * @author Claude Pasquier
 */
  
public class ScriptAdjustmentHandler implements AdjustmentListener {
      
  public void adjustmentValueChanged(AdjustmentEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "adjustmentValueChanged");
  }
}
