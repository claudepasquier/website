/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.lang.Exception;

/**
 * Exception raised during the processing of XBMapper
 *
 * @author Claude Pasquier
 */
public class XBException extends Exception {

  /**
   * Default constructor
   */
  public XBException() {
    super("error during the execution of XBMapper");
  }

  /**
   * Constructor with an error message specified
   */
  public XBException(String message) {
    super(message);
  }
}
