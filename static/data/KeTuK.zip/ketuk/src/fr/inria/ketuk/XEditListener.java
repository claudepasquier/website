/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

/**
 * An interface that should be implemented by object
 * listening XEditEvent types
 *
 * @author Claude Pasquier
 */
public interface XEditListener extends java.util.EventListener {


/**
 * Invoked when an xedit event occurs.
 **/
  void xEditPerformed(XEditEvent e);
}
