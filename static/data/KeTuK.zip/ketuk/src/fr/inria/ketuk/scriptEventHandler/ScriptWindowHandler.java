/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import java.awt.event.*;

/**
 * A listener class which handle window events
 *
 * @author Claude Pasquier
 */
  
public class ScriptWindowHandler implements WindowListener {
      
  public void windowActivated(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowActivated");
  }
      
  public void windowClosed(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowClosed");
  }
      
  public void windowClosing(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowClosing");
  }
      
  public void windowDeactivated(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowDeactivated");
  }
      
  public void windowDeiconified(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowDeiconified");
  }
      
  public void windowIconified(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowIconified");
  }
      
  public void windowOpened(WindowEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "windowOpened");
  }
}
