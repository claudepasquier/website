/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;

/**
 * A listener class which handle change events
 *
 * @author Claude Pasquier
 */
  
public class ScriptChangeHandler implements ChangeListener {
      
  public void stateChanged(ChangeEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "stateChanged");
  }
}
