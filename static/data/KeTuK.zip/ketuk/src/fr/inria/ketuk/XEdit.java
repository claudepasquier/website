/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import org.apache.xml.serialize.*;

/**
 * Implementation of a basic application
 * allowing the edition of a XML document with it's associated
 * XSLT file
 *
 * @author Claude Pasquier
 */
public class XEdit implements XEditListener {

  /**
   * The XBMapper assuring the links between the source document
   * and the transformed one
   */
  private static XBMapper mapper = null;
  private static JFrame f = null;

  /**
   * Entry point of the class.
   *
   * <p>
   * Processes xml ans xslt documents, generates the corresponding bean
   * hierarchy and displays it
   **/
  public static void main(String[] args) {
    XEdit xedit = new XEdit();
    Object resultObj = null;
    try {
      mapper = new XBMapper(args);
      resultObj = mapper.processBM();
    }
    catch (Exception e) {
      System.err.println(e.getMessage());
      System.exit(1);
    }

    if (resultObj == null) {
      System.err.println("no bean was created");
    }
    else if (Window.class.isAssignableFrom(resultObj.getClass())) {
      //      ((Window)resultObj).pack();
      ((Window)resultObj).setVisible(true);
    }
    else if (Component.class.isInstance(resultObj)) {
      f = new JFrame();
      f.getContentPane().add((Component)resultObj);
      f.pack();
      f.setVisible(true);
    }
    else {
      System.err.println("warning: the resulting bean is not a displayable object");
    }
    mapper.addXEditListener(xedit);
  }

  /**
   * Handler for XEdit events.
   * <p>
   * This method does nothing excepted for END events
   * where the edited document is written on the standard
   * output and the application is ended
   **/
   public void xEditPerformed(XEditEvent xe) {
     if (xe.getEventType() == XEditEvent.END) {
       StringWriter sw = new StringWriter();
       OutputFormat of = new OutputFormat();
       of.setIndent(2);
       of.setIndenting(true);
       XMLSerializer serializer = new XMLSerializer(sw, of);
       try {
         serializer.serialize(mapper.getXmlDocument());
       }
       catch (Exception e) {
         e.printStackTrace();
       }
       System.out.println(sw.toString());
       System.exit(0);
     }
     else {
       //     Object resultObj = mapper.getRootBean();
       //       f.getContentPane().add((Component)resultObj);
       //      ((Component)resultObj).validate();
      //      ((Component)resultObj).pack();
       //((Component)resultObj).repaint();
       //      ((Component)resultObj).setVisible(true);
       //<TODO>
       // Do we need the lines below ?
       //       Object resultObj = mapper.getRootBean();
       //System.err.println("<CP>REVALIDATE");
       //       if (Component.class.isInstance(resultObj)) {
       //         ((Component)resultObj).validate();
       //       }
              //new java.lang.Exception().printStackTrace();
              //System.err.println("TOTO");       ((Component)resultObj).setVisible(true);
     }
   }

  /**
   * Serializes an DOM document
   * <p>
   * This method is used to write a XML version of the document
   **/
  private String serialize(org.w3c.dom.Document doc) {
    StringWriter sw = new StringWriter();
    org.apache.xml.serialize.OutputFormat of = new org.apache.xml.serialize.OutputFormat();
    of.setIndent(2);
    of.setIndenting(true);
    of.setLineWidth(40);
    org.apache.xml.serialize.XMLSerializer serializer = new org.apache.xml.serialize.XMLSerializer(sw, of);
    try {
      serializer.serialize(doc);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return sw.toString();
  }
}
