/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.*;

/**
 * Plays a bean markup file
 *
 * @author Claude Pasquier
 */
public class BMPlayer {

  /**
   * Processes beans Markup document, generates the corresponding bean
   * hierarchy and displays it
   **/
  public static void main(String[] args) {
    Object resultObj = null;
    try {
      BMProcessor process = new BMProcessor();
      resultObj = process.processBM(args[0]);
    }
    catch (BMException e) {
      System.err.println(e.getMessage());
      System.exit(1);
    }

    if (resultObj == null) {
      System.err.println("no bean was created");
    }
    else if (Window.class.isInstance(resultObj)) {
      ((Window)resultObj).pack();
      ((Window)resultObj).setVisible(true);
    }
    else if (Component.class.isInstance(resultObj)) {
      Frame f = new Frame();
      f.add((Component)resultObj);
      f.pack();
      f.setVisible(true);
    }
    else {
      System.err.println("the resulting bean is not a displayable object");
    }
  }
}
