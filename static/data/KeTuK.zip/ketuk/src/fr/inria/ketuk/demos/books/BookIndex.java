package fr.inria.ketuk.demos.books;

import fr.inria.ketuk.widgets.*;
import javax.swing.*;
import java.awt.event.*;

public class BookIndex extends JPanel implements MouseListener  {

  int nbBooks = 0;
  JLabel nbBookLabel = null;

  int index = 0;
  JLabel indexLabel = null;
  JButton previousButton = null;
  JButton nextButton = null;
  boolean prevEnabled = false;
  boolean nextEnabled = false;

  public BookIndex() {
    super();
    this.setLayout(new VerticalLayout());
    this.add(new JLabel("BOOK INDEX"));
    indexLabel = new JLabel("index of book: "+index);
    this.add(indexLabel);
    nbBookLabel = new JLabel("number of books in the base: "+nbBooks);
    this.add(nbBookLabel);
    previousButton = new JButton("previous");
    previousButton.setEnabled(false);
    nextButton = new JButton("next");
    nextButton.setEnabled(false);
    HBox hbox = new HBox();
    hbox.add(previousButton);
    hbox.add(nextButton);
    this.add(hbox);
    updateButtonStates();

  }

  private void updateButtonStates() {
    if (index > 1) {
      if (!prevEnabled) {
        previousButton.setEnabled(true);
        previousButton.addMouseListener(this);
        prevEnabled = true;
      }
    }
    else if (index == 1) {
      if (prevEnabled) {
        previousButton.setEnabled(false);
        previousButton.removeMouseListener(this);
        prevEnabled = false;
      }
    }
    if (index < nbBooks) {
      if (!nextEnabled) {
        nextButton.setEnabled(true);
        nextButton.addMouseListener(this);
        nextEnabled = true;
      }
    }
    else if (index == nbBooks) {
      if (nextEnabled) {
        nextButton.setEnabled(false);
        nextButton.removeMouseListener(this);
        nextEnabled = false;
      }
    }
  }

  public void setNbBooks(int n) {
    nbBooks = n;
    nbBookLabel.setText("number of books in the base: "+nbBooks);
    updateButtonStates();
  }

  public void setIndex(int n) {
    if (index != n) {
      index = n;
      indexLabel.setText("index of book: "+index);
      updateButtonStates();
    }
  }

  public void mouseClicked(MouseEvent e) {
    int oldIndex = index;
    if (e.getComponent() == previousButton) {
      index -= 1;
    }
    else if (e.getComponent() == nextButton) {
      index += 1;
    }
    if (oldIndex != index) {
      updateButtonStates();
      indexLabel.setText("index of book: "+index);
      firePropertyChange("index", oldIndex, index);
    }
  }

  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {
  }
}
