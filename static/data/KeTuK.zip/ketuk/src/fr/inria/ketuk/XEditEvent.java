/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import org.w3c.dom.Node;

/**
 * An event representing an editing operation occuring
 * on a DOM Node
 *
 * @author Claude Pasquier
 */
public class XEditEvent extends java.util.EventObject {

/**
 * Indicates that a node is selected
 */
  public static int SELECTED = 1;

/**
 * Indicates that a node has to be changed
 */
  public static int CHANGED = 2;

/**
 * Indicates that a node has to be removed
 */
  public static int REMOVED = 3;

/**
 * Indicates that a node has to be added
 */
  public static int ADDED = 4;

/**
 * Indicates the end of an updating process
 */
  public static int END = 5;

/**
 * the event's type
 */
  private int eventType;

/**
 * the concerned node
 */
  private Node node;

/**
 * Default constructor
 */
  public XEditEvent(Object o) {
    super(o);
  }

/**
 * A constructor using a node and an event type as parameters
 */
  public XEditEvent(Object o, Node n, int eventType) {
    super(o);
    this.eventType = eventType;
    this.node = n;
  }

/**
 * The event's type
 */
  public int getEventType() {
    return eventType;
  }

/**
 * The concerned node
 */
  public Node getSourceNode() {
    return node;
  }
}
