/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

/**
 * An interface that should be implemented by object
 * listening BeanEditEvent types
 *
 * @author Claude Pasquier
 */
public abstract interface BeanEditListener extends java.awt.event.ActionListener {

  /**
   *  Called when an update is made on a bean
   **/
  void beanEditPerformed(BeanEditEvent e);
}
