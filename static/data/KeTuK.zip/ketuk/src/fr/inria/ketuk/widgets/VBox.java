/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.widgets;

import javax.swing.*;

public class VBox extends JPanel {

  int interline = 0;
  int indent = 0;

  public VBox() {
    super();
    this.setLayout(new VerticalLayout());
  }

  public void setInterline(String il) {
    try {
      interline = Integer.decode(il).intValue();
    }
    catch (NumberFormatException nfe) {
      System.err.println("Method setInterline in class VBox");
      System.err.println("   argument is not a number ("+il+")");
      interline = 0;
    }
    this.setLayout(new VerticalLayout(interline, indent));
  }

  public String getInterline() {
    return new Integer(interline).toString();
  }

  public void setIndent(String id) {
    try {
      indent = Integer.decode(id).intValue();
    }
    catch (NumberFormatException nfe) {
      System.err.println("Method setIndent in class VBox");
      System.err.println("   argument is not a number ("+id+")");
      indent = 0;
    }
    this.setLayout(new VerticalLayout(interline, indent));
  }

  public String getIndent() {
    return new Integer(indent).toString();
  }

}
