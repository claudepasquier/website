/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.lang.reflect.*;
import java.beans.*;
import java.util.*;
import java.io.*;
import java.net.*;

//multimethods
import fr.umlv.jmmf.reflect.MultiMethod;

import org.apache.xerces.dom.*;
import org.apache.xalan.xslt.*;
import org.apache.xalan.xpath.*;
import org.apache.xalan.xpath.xml.*;
import XPathAPI;

import XmlUtil;

import org.xml.sax.*;

import org.w3c.dom.*;

/**
 * A processor of the Beans markups
 *
 * @author Claude Pasquier
 */
public class BMProcessor {

  /** 
   * debugging flags
   */
  private static boolean trace = false;
  private static boolean trace1 =false;
  private static boolean trace2 = false;

  /**
   *  The bean markup document
   **/
  protected Document _bmDoc = null;

  /**
   * the root of the generated beans
   **/
  protected Object _rootBean = null;  // the root of the created bean

  /**
   *  An instance of the default class loader
   **/
  protected static ClassLoader _cl = null;

  static {
    _cl = ClassLoader.class.getClassLoader();
  }

  /**
   * Indicates that arguments specified at the initialization of
   * beans may be casted if necessary
   **/
  private static boolean autoCastBeanArgs = false;

  /**
   * Indicates that arguments specified in a method call
   * may be casted if necessary
   **/
  private static boolean autoCastMethodArgs = true;

  /**
   * Indicates that arguments specified to set a property
   * may be casted if necessary
   **/
  private static boolean autoCastPropertyArgs = true;

  /**
   * Indicates that arguments specified to set a field
   * may be casted if necessary
   **/
  private static boolean autoCastFieldArgs = true;

  /**
   * The mapping between basic types and the corresponding class
   * eg.  int ==> int.class
   */
  private static Hashtable _mappingClassName;

  /**
   * The array of basic types
   */
  private static String[] _className  = {"boolean", "byte", "char", "short",
                                       "int",     "long", "float", "double"};

  /**
   * The array of classes corresponding to basic types
   */
  private static Class[]  _classValue = {boolean.class, byte.class, char.class, short.class,
                                       int.class,     long.class, float.class, double.class};

  static {
    _mappingClassName  = new Hashtable();
    for (int i = 0 ; i < _className.length ; i++ ) {
      _mappingClassName.put(_className[i], _classValue[i]);
    }
  }

  /**
   *  An instance of XmlUtil
   **/
  private static XmlUtil _xml = new XmlUtil();

  /**
   *  The list of registered beans
   **/
  protected Hashtable _registeredBeans = null;

  /**
   *  The XBMapper used
   **/
  private XBMapper _xbmapper = null;

  /**
   * The set of links used to assure the mapping
   */
  protected XBLinks _xblinks = null;

  /**
   *  The URL of the bean markup file being processed
   **/
  private URL _contextURL = null;

  /**
   *  The list of registered methods specified in config.xml
   **/
  protected static Vector _registerList = new Vector();

  static {
    try {
      InputStream is = String.class.getResourceAsStream("/config.xml");
      if (is != null) {
        Document ressourcesDoc = _xml.readDocument(is);
        is.close();
        Element elt = ressourcesDoc.getDocumentElement();
        if (elt == null) System.err.println("warning: 'file 'config.xml' is empty");
        elt = _xml.getFirstChildElement(elt);
        if (elt == null) System.err.println("warning: 'file 'config.xml' is empty");
        while (elt != null) {
          if ("register".equals(elt.getTagName())) {
            _registerList.addElement(elt);
          }
          else if ("option".equals(elt.getTagName())) {
            String optionName = elt.getAttribute("name");
            boolean optionValue= new Boolean(elt.getAttribute("value")).booleanValue();
            if ("autoCastBeanArgs".equals(optionName)) {
              autoCastBeanArgs = optionValue;
            }
            else if  ("autoCastMethodArgs".equals(optionName)) {
              autoCastMethodArgs = optionValue;
            }
            else if  ("autoCastPropertyArgs".equals(optionName)) {
              autoCastPropertyArgs = optionValue;
            }
            else if  ("autoCastFieldArgs".equals(optionName)) {
              autoCastFieldArgs = optionValue;
            }
          }
          elt = _xml.getNextElement(elt);
        }
      }
      else {
        System.err.println("warning: unable to find the configuration file 'config.xml'");
      }
    }
    catch (SAXException e) {
      System.err.println("SAX exception occured while parsing configuration file");
      System.exit(1);
    }
    catch (IOException e) {
      System.err.println("IO error occured while parsing configuration file");
      System.exit(1);
    }
    catch (Exception e) {
      System.err.println(e.getMessage());
      System.exit(1);
    }
  }

  /**
   * Default constructor
   */
  BMProcessor() throws BMException {
    // Initialize the class loader
    _registeredBeans = new Hashtable();
    _xblinks = new XBLinks();
  }

  /**
   * Constructs a BMProcessor given a XBMapper
   *  @param defaultListener     the object that should be used
   *                             to listen events
   */
  BMProcessor(XBMapper defaultListener) throws BMException {
    // Initialize the class loader
    _registeredBeans = new Hashtable();
    _xbmapper = defaultListener;
    _xblinks = new XBLinks();
  }


  /**
   * Constructs a BMProcessor given a XBMapper and a set of links
   *
   *  @param defaultListener     the object that should be used
   *                             to listen events
   *  @param links               the links to use
   *
   */
  BMProcessor(XBMapper defaultListener,
              XBLinks links) throws BMException {
    // Initialize the class loader
    _registeredBeans = new Hashtable();
    _xbmapper = defaultListener;
    _xblinks = links;

  }

  /**
   *  Returns the bean markup document
   **/
  public Document getBMDocument() {
    return _bmDoc;
  }

  /**
   *  Sets the bean markup document
   **/
  public void setBMDocument(Document bmDoc) {
    _bmDoc = bmDoc;
  }

  /**
   *  Returns the root of the bean hierarchy
   **/
  public Object getBeanObject() {
    return _rootBean;
  }

  /**
   *  Process the bean markup document to obtain a root bean
   **/
  public void process() throws BMException {
    Element rootElement = _bmDoc.getDocumentElement();
    if (!"bean".equals(rootElement.getTagName()))
      error("root of a bean markup document must be a '<bean'> tag");
    _rootBean = processBM(_bmDoc, null);
  }
  
  /**
   *  Process the bean markup document specified in the source
   *
   *  @param source               the source of the bean markup document
   *
   *  @ return                    the created bean     
   **/
  public Object processBM(String source) throws BMException {
    return processBM(source, new Hashtable(), null, null);
  }

  /**
   *  Process the bean markup document specified in the source,
   *  given a contextURL
   *
   *  @param source               the source of the bean markup document
   *  @param contextURL           the context url used to find the source
   *
   *  @ return                    the created bean     
   **/
  public Object processBM(String source, URL contextURL) throws BMException {
    return processBM(source, new Hashtable(), null, contextURL);
  }

  /**
   *  Process the bean markup document specified in the source,
   *  given a contextURL, a contextBean and a list or registered beans
   *
   *  @param source               the source of the bean markup document
   *  @param beansRegistry        the list of registered beans
   *  @param contextBean          the contextBean
   *  @param contextURL           the context url used to find the source
   *
   *  @ return                    the created bean     
   **/
  protected Object processBM(String source,
                             Hashtable beansRegistry,
                             Object contextBean,
                             URL contextURL) throws BMException {

    URL uri = null;
    try {
      uri = _xml.getUrl(contextURL, source);
    }
    catch (MalformedURLException ex) {
      error("cannot localize the source " + source);
    }
    
    _contextURL = uri;
    Document doc = null;
    try {
      doc = _xml.readDocument(uri);
    }
    catch (Exception e) {
      error(e.getMessage());
    }
    return processBM(doc, beansRegistry, contextBean, _contextURL); 
  }

  /**
   *  Process the bean markup document
   *
   *  @param bmDoc                the source beans markup document
   *  @param beansRegistry        the list of registered beans
   *
   *  @ return                    the created bean     
   **/
  public Object processBM(Document bmDoc, Hashtable beansRegistry) throws BMException {
    return processBM(bmDoc, beansRegistry, null, null);
  }

  /**
   *  Process the bean markup document specified in the source,
   *  given a contextURL, a contextBean and a list or registered beans
   *
   *  @param source               the source of the bean markup document
   *  @param beansRegistry        the list of registered beans
   *  @param contextBean          the contextBean
   *  @param contextURL           the context url used to find the source
   *
   *  @ return                    the created bean     
   **/
  public Object processBM(Document bmDoc,
                          Hashtable beansRegistry,
                          Object contextBean,
                          URL contextURL)
    throws BMException {

    _bmDoc = bmDoc;
    Element rootElement = _bmDoc.getDocumentElement();
    _rootBean = processBM(rootElement, beansRegistry, contextBean, contextURL);
    return _rootBean;
  }

  /**
   *  Process the bean markup document
   *
   *  @param bmElement            the Element representing the bean
   *  @param beansRegistry        the list of registered beans
   *
   *  @ return                    the created bean     
   **/
  protected Object processBM(Element bmElement, Hashtable beansRegistry) throws BMException {
    return processBM(bmElement, beansRegistry, null, null);
  }

  /**
   *  Process the bean markup document
   *
   *  @param bmElement            the Element representing the bean
   *  @param beansRegistry        the list of registered beans
   *  @param contextBean          the contextBean
   *  @param contextURL           the context url used to find the source
   *
   *  @ return                    the created bean     
   **/
  protected Object processBM(Element bmElement,
                             Hashtable beansRegistry,
                             Object contextBean,
                             URL contextURL)
    throws BMException {

    if (beansRegistry != null) _registeredBeans = beansRegistry;
    _contextURL = contextURL;
    TypedObject resultObject = getObject(bmElement, contextBean);
    if (resultObject == null) return null;
    else return resultObject.getObject();
  }
  
  /**
   * Constructs a bean from a 'bean' tag
   *
   *  @param beanElt              the Element representing the bean
   *  @param contextBean          the contextBean
   *
   *  @ return                    the created bean     
   **/
  protected TypedObject getBean(Element beanElt, Object currentBean) throws BMException {

    Object bean = null; // the bean representing the element

    String source = beanElt.getAttribute("source");
    String beanClass = beanElt.getAttribute("class");
    String action = beanElt.getAttribute("action");
    Element childElt = _xml.getFirstChildElement(beanElt);
    if (!"".equals(source)) {
      // if a source is specified, retrieves the bean
      if (source.startsWith("class:")) {
        source = source.substring(6);
        try {
          bean = Class.forName(source);
        }
        catch (ClassNotFoundException cnfe) {
          error("unable to create the class '"+source+"'");
        }
      }
      else if ("this".equals(source)) {
        bean = currentBean;
      }
      else {
        bean = _registeredBeans.get(source);
        if (bean == null) {
          error("unable to retrieve a bean registered with the name '"+source+"'");
        }
        if (!"".equals(beanClass)) {
          try {
            Class c = Class.forName(beanClass);
            if (!c.isInstance(bean)) {
              error("the bean registered with '" + source
                    + "is not an instance of '" + beanClass+"'");
            }
          }
          catch (ClassNotFoundException cnfe) {
            error("unable to retrieve the class '"+beanClass+"'");
          }
        }
      }
      if ((childElt != null)
          && ("args".equals(childElt.getTagName()))) {
        error("argument cannot be specified during looking-up of a bean");
      }
    }
    else if (!"".equals(beanClass)) {
      // variables used to memorize the parameters
      int nbParam = 0;
      Class[] paramClasses = null;
      Object params[] = null;

      if ((childElt != null) 
          && ("args".equals(childElt.getTagName()))) {
        // constructs a new bean with the specified parameters
        Element argsElt = childElt;
        childElt = _xml.getNextElement(childElt);
        nbParam = _xml.countNbChildElements(argsElt);
        paramClasses = new Class[nbParam];
        params = new Object[nbParam];
        getParam(argsElt.getChildNodes(), params, paramClasses, 0, currentBean);
      }

      if (beanClass.endsWith(".xml")
          || beanClass.endsWith(".bml")) {
        // the bean should be created by processing an inner xml file
        Hashtable localRegistry = (Hashtable)_registeredBeans.clone();
        for (int i = 0 ; i < nbParam ; i++) {
          localRegistry.put("script:arg"+i, params[i]);
        }
        BMProcessor process = new BMProcessor();
        bean = process.processBM(beanClass, localRegistry, currentBean, _contextURL);
      }

      else {
        if (nbParam > 0) {
          // retrieves the constructor
          // and tries to create and instance of the class
          // with the specified arguments
          Class theClass = null;
          try {
            theClass = Class.forName(beanClass);
            if (theClass == null) {
              error("unable to ind the class '" + beanClass + "'");
            }
            Constructor cons = theClass.getConstructor(paramClasses);
            bean = cons.newInstance(params);
          }
          catch (Exception e) {
            // no constructor accepting all parameters can be applied without a cast
            // Tries now to find a constructor which can accept the specified
            // arguments after a simple casting from the given parameters to
            // the expected ones
            bean = null;
            Constructor[] constructors = theClass.getConstructors();
            Class[] convertedParamClasses = null;
            boolean goodParameters = true;
            for (int i = 0 ; i < constructors.length ; i++) {
              Class[] paramTypes = constructors[i].getParameterTypes();
              if (nbParam != paramTypes.length) continue;
              convertedParamClasses = new Class[nbParam];
              goodParameters = true;
              for (int j = 0 ; j < nbParam ; j++) {
                if (!paramTypes[j].isAssignableFrom(paramClasses[j])) {
                  goodParameters = false;
                  break;
                }
                convertedParamClasses[j] = paramTypes[j];
              }
              if (goodParameters) break;
            }
            if (goodParameters) {
              try {
                Constructor constructor = theClass.getConstructor(convertedParamClasses);
                bean = constructor.newInstance(params);
              }
              catch (Exception e1) {
                error("unexpected error while calling the constructor '"
                      + "' of class '" + beanClass + "'");
              }
            }
            else if (autoCastBeanArgs) {
              // tries now to use a typeConverter to cast the arguments
              bean = createBeanWAutoCast(theClass, params);
            }
            if (bean == null) {
              error("unable to create an instance of the class '"
                    + beanClass + "' with the specified parameters");
            }
          }
        }
        else {
          // constructs a new bean with no parameter
          try {
            bean = Beans.instantiate(_cl, beanClass);
          }
          catch (Exception e) {
            error("unable to create an instance of the class '"
                  + beanClass + "' using no parameter");
          }
        }
      }
    }
    else {
      error("no 'source' nor 'class' attribute specified in a bean declaration", beanElt);
    }  

    // the bean has been created
    // translates and executes next instructions
    // in the context of the current bean

    register(beanElt, bean);
    while (childElt != null) {
      getObject(childElt, bean);
      childElt = _xml.getNextElement(childElt);
    }

    // registering
    String nodeRef = beanElt.getAttribute(_xblinks.getEltIdName());
    if (nodeRef.length() > 0) {
      _xblinks.putMappingNodeRef(bean, nodeRef);
    }

    if ("add".equals(action)) {
      Object params[] = new Object[2]; // the enclosed bean and the bean to add
      params[0] = currentBean;
      params[1] = bean;
      String parentClassName = currentBean.getClass().getName();
      // retrieves the adder to use, depending of the class
      // of the parent object
      for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
        Element elt = (Element)enum.nextElement();
        String type = elt.getAttribute("type");
        if (!"adder".equals(type)) continue;
        String adderClassName = elt.getAttribute("class");
        Class adderClass = null;
        try {
          adderClass = Class.forName(adderClassName);
        }
        catch (ClassNotFoundException e) {
          error("unable to retrieve the class '" + adderClassName + "'");
        }
        String methodName = elt.getAttribute("method");

        try {
          MultiMethod mm=MultiMethod.create(adderClass,methodName,2);
          mm.invoke(adderClass.newInstance(), params);
        }
        catch (NoClassDefFoundError e) {
          // the adder is not found. Tries to find another one
          continue;
        }
        catch (Exception e) {
          // the adder doesn't match. Tries to find another one
          continue;
        }
        break;
      }
    }

    return new TypedObject(bean, bean.getClass());
  }
  
  /**
   * Sets a property as specified by the 'property' parameter element
   *
   *  @param propertyElt            the element representing the property
   *  @param currentBean            the bean that is curently instanciated
   *
   *  @return                       the value returned when setting the property
   **/
  protected TypedObject setProperty(Element propertyElt, Object currentBean) throws BMException {
    String propertyName = propertyElt.getAttribute("name");
    String indx = propertyElt.getAttribute("index");
    String value = propertyElt.getAttribute("value");
    String target = propertyElt.getAttribute("target");
    Object contextBean = currentBean;
    if (!"".equals(target)) {
      contextBean = _registeredBeans.get(target);
      if (contextBean == null) {
        error("unable to retrieve a bean registered with the name '" + target + "'");
      }
    }

    if ("".equals(indx)) indx = null;

    // gets a bean info describing the bean
    BeanInfo bInf = null;
    try {
      bInf = Introspector.getBeanInfo(contextBean.getClass());
    }
    catch (IntrospectionException ie) {
      error("error occured during introspection of the bean: '"
            + contextBean.getClass().getName()+"'.");
    }

    PropertyDescriptor[] pd = bInf.getPropertyDescriptors();
    boolean propertySet = false;
    TypedObject returnObject = null; // returnObject will be set
                                     //with the value of the property set
    // collect the parameter used to set the property
    if (indx == null) {
      int nbParam = 1; // one parameter for setting the property
      Class[] paramClasses = new Class[nbParam];
      Object params[] = new Object[nbParam];
      
      for (int ii = 0 ; ii < pd.length ; ii++) {
        if (trace2) {
          System.err.println("<CP> propName="+pd[ii].getName());
        }
        if (!pd[ii].getName().equals(propertyName)) continue;

        // a property with the same name is localized
        // finds the corresponding write method
        Method m = pd[ii].getWriteMethod();
        if (trace2) {
          System.err.println("<CP> method found: "+m);
          System.err.println("<CP> parameters = "+m.getParameterTypes());
        }
        if (m == null) { // the property is read only,
          continue; // continue to search for another setter
        }

        // retrieve the table of parameter classes expected
        Class[] expectedParams = m.getParameterTypes();

        // retrieve the parameters
        if (value.length() > 0) {
          params[0] = value;
          paramClasses[0] = String.class;
        }
        else {
          boolean forceArrayCreation = false;
          // if the 'setProperty' method is called with an array of objects,
          // then we force the creation of an array holding all the sub elements
          if (autoCastPropertyArgs
              && (expectedParams.length == 1)
              && (expectedParams[0].isArray())) {
            if (_xml.countNbChildElements(propertyElt) > 1) forceArrayCreation = true;
            else {
              NodeList argList = propertyElt.getChildNodes();
              for (int i = 0 ; i < argList.getLength() ; i++) {
                if (argList.item(i).getNodeType() == Node.ELEMENT_NODE) {
                  if (!"array".equals(((Element)argList.item(i)).getTagName())) {
                    forceArrayCreation = true;
                  }
                }
              }
            }
          }
          getParam(propertyElt.getChildNodes(), params, paramClasses, 0, currentBean, forceArrayCreation);
        }

        // test is parameters expected by the method is
        // consistent with given parameters
        if (expectedParams.length != nbParam) { // inconsistent parameters
          continue;                 // continue to search for another setter
        }
        
        if (!autoCastPropertyArgs) continue; 

        boolean goodParameters = true;
        for (int i = 0 ; i < nbParam ; i++) {
          if (trace2) System.err.println("<CP> expected param["+i+"] ="+expectedParams[i].getName());
          if (trace2) System.err.println("<CP>    given param["+i+"] ="+paramClasses[i].getName());
          if (trace2) System.err.println("<CP>    given value["+i+"] ="+params[i]);
          boolean conversionDone = false;
          for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
            Element elt = (Element)enum.nextElement();
            String type = elt.getAttribute("type");
            if (!"typeConvertor".equals(type)) continue;
            String convertorClassName = elt.getAttribute("class");
            Class convertorClass = null;
            try {
              convertorClass = Class.forName(convertorClassName);
            }
            catch (ClassNotFoundException e) {
              error("unable to retrieve the class '" + convertorClassName + "'");
            }
            String methodName = elt.getAttribute("method");
            try {
              MultiMethod mm=MultiMethod.create(convertorClass,methodName,2);
              Object prms[] = new Object[2];
              prms[0] = params[i];
              prms[1] = expectedParams[i];
              params[i] = mm.invoke(convertorClass.newInstance(), prms);
              conversionDone = true;
            }

            catch (NoClassDefFoundError e) {
              // the convertor is not found. Tries to find another one
              continue;
            }
            catch (Exception e) {
              // the convertor doesn't match. Tries to find another one
              continue;
            }
          }
          if (!conversionDone) {
            goodParameters = false;
            break;
          }
        }
        if (!goodParameters) { // the types of parameters is not consistent
          continue;            // continue to search for another setter
        }
      
        // execute the method
        try {
          if (trace2) {
            System.err.println("<CP> calling method  ="+m);
            System.err.println("<CP> calling method with params[0] ="+params[0]);
          }
          m.invoke(contextBean, params);
        }
        catch (Exception e) {
          error("exception in method '"+m.getName()+"' of bean '"+contextBean.getClass().getName()+"'.");
        }     
        propertySet = true;
        if (nbParam > 0) {
          returnObject = new TypedObject(params[nbParam-1], paramClasses[nbParam-1]);
        }
        break;
      }
    }
    else { // indexed property
      int nbParam = 2; // two parameters for setting the property
      Class[] paramClasses = new Class[nbParam];
      Object params[] = new Object[nbParam];


      for (int ii = 0 ; ii < pd.length ; ii++) {
        if (trace2) {
          System.err.println("<CP> propName="+pd[ii].getName());
        }
        if (!pd[ii].getName().equals(propertyName)) continue;

        // a property with the same name is localized
        // finds the corresponding write method
        Method m = ((IndexedPropertyDescriptor)pd[ii]).getIndexedWriteMethod();
        if (trace2) {
          System.err.println("<CP> found method = "+m);
          System.err.println("<CP> parameters = "+m.getParameterTypes());
        }
        if (m == null) { // the property is read only,
          continue; // continue to search for another setter
        }
        // retrieve the table of parameter classes expected
        Class[] expectedParams = m.getParameterTypes();

        // retrieve the parameters
        paramClasses[0] = int.class;
        params[0] = new Integer(indx);
        if (value.length() > 0) {
          params[1] = value;
          paramClasses[1] = String.class;
        }
        else {
          boolean forceArrayCreation = false;
          // if the 'setProperty' method is called with an array of objects,
          // the we force the creation of an array holding all the sub elements
          if (autoCastPropertyArgs
              && (expectedParams.length == 2)
              && (expectedParams[1].isArray())) {
            if (_xml.countNbChildElements(propertyElt) > 2) forceArrayCreation = true;
            else {
              NodeList argList = propertyElt.getChildNodes();
              for (int i = 0 ; i < argList.getLength() ; i++) {
                if (argList.item(i).getNodeType() == Node.ELEMENT_NODE) {
                  if (!"array".equals(((Element)argList.item(i)).getTagName())) {
                    forceArrayCreation = true;
                  }
                }
              }
            }
          }
          getParam(propertyElt.getChildNodes(), params, paramClasses, 1, currentBean, forceArrayCreation);
        }
        // test is parameters expected by the method is
        // consistent with given parameters
        if (expectedParams.length != nbParam) { // inconsistent parameters
          continue;                 // continue to search for another setter
        }

        if (!autoCastPropertyArgs) continue;
        boolean goodParameters = true;
        for (int i = 0 ; i < nbParam ; i++) {
          boolean conversionDone = false;
          for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
            Element elt = (Element)enum.nextElement();
            String type = elt.getAttribute("type");
            if (!"typeConvertor".equals(type)) continue;
            String convertorClassName = elt.getAttribute("class");
            Class convertorClass = null;
            try {
              convertorClass = Class.forName(convertorClassName);
            }
            catch (ClassNotFoundException e) {
              error("unable to retrieve the class '" + convertorClassName + "'");
            }
            String methodName = elt.getAttribute("method");
            try {
              MultiMethod mm=MultiMethod.create(convertorClass,methodName,2);
              Object prms[] = new Object[2];
              prms[0] = params[i];
              prms[1] = expectedParams[i];
              params[i] = mm.invoke(convertorClass.newInstance(), prms);
              conversionDone = true;
            }

            catch (NoClassDefFoundError e) {
              // the convertor is not found. Tries to find another one
              continue;
            }
            catch (Exception e) {
              // the convertor doesn't match. Tries to find another one
              continue;
            }
          }
          if (!conversionDone) {
            goodParameters = false;
            break;
          }        }
        if (!goodParameters) { // the types of parameters is not consistent
          continue;            // continue to search for another setter
        }

        // execute the method
        try {
          if (trace2) {
            System.err.println("<CP> calling method  ="+m);
            System.err.println("<CP> calling method with params[0] ="+params[0]);
            System.err.println("<CP> calling method with params[1] ="+params[1]);
          }
          m.invoke(contextBean, params);
        }
        catch (Exception e) {
          error("exception in method '"+m.getName()+"' of bean '"+contextBean.getClass().getName()+"'.");
        }     
        propertySet = true;
        if (nbParam > 0) {
          returnObject = new TypedObject(params[nbParam-1], paramClasses[nbParam-1]);
        }
        break;
      }
    }
    if (!propertySet) {
      error("cannot find a method to set property '" + propertyName+"'"
            + " of bean '" + contextBean.getClass().getName() + "'");
    }

    // memo mapping bean<-->properties
    if (_xblinks != null) {
      if (indx == null)
        _xblinks.addMappingBeanProp(contextBean, propertyName);
      else
        _xblinks.addMappingBeanProp(contextBean, propertyName+"/"+indx);
      _xblinks.addMappingProp(contextBean,
                             propertyName,
                             propertyElt.getAttribute("propref"));

      // the code below will not work if target is specified in the
      // property declaration
      Element beanElt = (Element)propertyElt.getParentNode();
      String beanIdAndPropId = beanElt.getAttribute(_xblinks.getEltIdName()) +
                               "." +
                               propertyName;
      if (indx != null) // this is an indexed property
        beanIdAndPropId += "/" + indx;
      _xblinks.putMappingSourceNode(beanIdAndPropId,
                                    propertyElt.getAttribute(_xblinks.getEltIdName()));
    }
    return returnObject;
  }

  /**
   * Registers the object when an id attribute is specified in the element
   * <p>
   * If the node is an element node and an identifier is specified,
   *    memorizes the mapping between the id and the bean
   * also memorizes the mapping between the object and the XPath
   *    representing the source element
   *
   * @param node            the source node
   * @param obj             the object to register
   **/
  private void register(Node node, Object obj) {
    if (node.getNodeType() != Node.ELEMENT_NODE) return;
    Element elt = (Element)node;
    String id = elt.getAttribute("id");
    if (!"".equals(id)) _registeredBeans.put(id, obj);

    if (_xblinks != null) {
      if ("bean".equals(node.getNodeName())) {
        _xblinks.putMappingEltBean(XPathUtil.computeXPath(null, node), obj);
      }
    }
  }

  /**
   * Retrieves the parameter object corresponding to a parameter element
   * in a XML bean specification.
   * <p>
   * The method is used to construct the list of parameter and list
   * of parameter class of a bean specification
   *
   * @param nodes       the list of elements representing the parameters
   * @param par         the list of parameters used by the bean
   * @param parClass    the list of parameter
   * @param nbPara      the positiion where to put the first parameter
   *                    (the next ones are put into the following indexes)
   * @param currentBean the bean that is currently instanciated
   * @param createArray true if the parameters must be stored in an array of objects
   *
   **/
  private void getParam(NodeList nodes,
                        Object[] par,
                        Class[] parClass,
                        int nbPara,
                        Object currentBean,
                        boolean createArray) throws BMException {
    
    if (createArray == true) {
      TypedObject to = getArray((Element)nodes.item(0).getParentNode(), currentBean);
      par[nbPara] = to.getObject();
      parClass[nbPara] = to.getType();
      return;
    }
    int indx = nbPara;
    for (int i = 0 ; i < nodes.getLength() ; i++) {
      if (nodes.item(i).getNodeType() != Node.ELEMENT_NODE) continue; // process only element nodes
      Element elt = (Element)nodes.item(i);
      TypedObject to = getObject(elt, currentBean);
      par[indx] = to.getObject();
      if (trace2) {
        System.err.println("<CP> par["+indx+"] = "+par[indx]);
      }
      parClass[indx] = to.getType();     
      indx += 1;
    }
  }

  /**
   * Retrieve the parameter object corresponding to a parameter element
   * in a XML bean specification.
   * <p>
   * The method is used to construct the list of parameter and list
   * of parameter class of a bean specification
   *
   * @param nodes       the list of elements representing the parameters
   * @param par         the list of parameters used by the bean
   * @param parClass    the list of parameter
   * @param nbPara      the positiion where to put the first parameter
   *                    (the next ones are put into the following indexes)
   * @param currentBean the bean that is currently instanciated
   *
   **/
  private void getParam(NodeList nodes,
                        Object[] par,
                        Class[]  parClass,
                        int      nbPara,
                        Object   currentBean) throws BMException {
    getParam(nodes, par, parClass, nbPara, currentBean, false);
  }

  /**
   *  Gets an object
   *
   *  @param node            the node representing the object to read
   *  @param currentBean     the bean that is curently instanciated
   *
   *  @return                the created object 
   **/
  protected TypedObject getObject(Node node, Object currentBean) throws BMException {
    TypedObject obj = null;
    if (trace) {
      System.err.println("<CP> starting getObject");
      System.err.println("<CP> node="+node);
    }
    if (node.getNodeType() == Node.TEXT_NODE) {
      String value = node.getNodeValue();
      obj = new TypedObject(value, value.getClass());
    }
    else if (node.getNodeType() == Node.ELEMENT_NODE) {
      Element elt = (Element)node;
      String tagName = elt.getTagName();

      if ("property".equals(tagName)) {
        if ((_xml.countNbChildElements(elt) > 0) ||
            (!"".equals(elt.getAttribute("value")))) {
          obj = setProperty(elt, currentBean);
        }
        else {
          obj = getProperty(elt, currentBean);
        }
      }
      else if ("field".equals(tagName)) {
        if ((_xml.countNbChildElements(elt) > 0) ||
            (!"".equals(elt.getAttribute("value")))) {
          obj = setField(elt, currentBean);
        }
        else {
          obj = getField(elt, currentBean);
        }
      }
      else if ("call-method".equals(tagName)) {
        obj = getMethod(elt, currentBean);
      }
      else if ("bean".equals(tagName)) {
        obj = getBean(elt, currentBean);
      }
      else if ("listener".equals(tagName)) {
        obj = setListener(elt, currentBean);
      }
      else if ("event-binding".equals(tagName)) {
        obj = setEventBinding(elt, currentBean);
      }
      else if ("string".equals(tagName)) {
        obj = getString(elt, currentBean);
      }
      else if ("cast".equals(tagName)) {
        obj = getCast(elt, currentBean);
      }
      else if ("array".equals(tagName)) {
        obj = getArray(elt, currentBean);
      }
      else if ("script".equals(tagName)) {
        obj = getScript(elt, currentBean);
      }
      else if ("add".equals(tagName)) {
        obj = executeAdd(elt, currentBean);
      }
      else if ("fire-event".equals(tagName)) {
        obj = setFireEvent(elt, currentBean);
      }
      else if ("args".equals(tagName)) {
        error("'<args>' element not allowed (or misplaced) in a '<"
              + elt.getParentNode().getNodeName() +">' element\n");
      }
      else {
        error("unknown tag '" + tagName);
      }
    }
    if (obj != null) register(node, obj.getObject());
    return obj;
  }

  /**
   *  Gets a property
   *
   *  @param propertyElt            the element representing the property to read
   *  @param currentBean            the bean that is curently instanciated
   *
   *  @return                       the value returned when getting the property
   **/
  protected TypedObject getProperty(Element propertyElt, Object currentBean) throws BMException {
    String propertyName = propertyElt.getAttribute("name");
    String indx = propertyElt.getAttribute("index");
    String target = propertyElt.getAttribute("target");
    Object contextBean = currentBean;
    if (!"".equals(target)) {
      contextBean = _registeredBeans.get(target);
      if (contextBean == null) {
        error("unable to retrieve a bean registered with the name '" + target + "'");
      }
    }

    if (indx.length() == 0) indx = null;

    // gets a bean info describing the bean
    BeanInfo bInf = null;
    try {
      bInf = Introspector.getBeanInfo(contextBean.getClass());
    }
    catch (IntrospectionException ie) {
      error("error occured during introspection of the bean: '"
            + contextBean.getClass().getName()+"'.");
    }

    PropertyDescriptor[] pd = bInf.getPropertyDescriptors();
    Method m =null;
    
    Object returnObject = null;
    boolean propertyGot = false;
    // retrieves the getter corresponding to the bean's property
    for (int ii = 0 ; ii < pd.length ; ii++) {
      if (!pd[ii].getName().equals(propertyName)) continue;
      // the property is localized
      // finds the corresponding read method or indexed read method
      // depending if the property is indexed
      if (indx == null) {
        m = pd[ii].getReadMethod();
        if (trace) {
          System.err.println("<CP> method = "+m);
        }
        if (m == null) { // this property cannot be set,
          continue; // continue to search for another setter
        }
        
        try {
          returnObject = m.invoke(contextBean, null);
        }
        catch (Exception e) {
          error("exception in method '"+m.getName()+"' of bean '"+contextBean.getClass().getName()+"'.");
        } 
        propertyGot = true;
        break;
      }
      else {
        m = ((IndexedPropertyDescriptor)pd[ii]).getIndexedWriteMethod();
        if (trace) {
          System.err.println("<CP> method = "+m);
        }
        if (m == null) { // this property cannot be set,
          continue; // continue to search for another setter
        }
        
        int nbParam = 1; // two parameters for setting the property
        Class[] paramClasses = new Class[nbParam];
        Object params[] = new Object[nbParam];
        paramClasses[0] = int.class;
        params[0] = new Integer(indx);
        try {
          returnObject = m.invoke(contextBean, params);
        }
        catch (Exception e) {
          error("exception in method '"+m.getName()+"' of bean '"+contextBean.getClass().getName()+"'.");
        } 
        propertyGot = true;
        break;
      }
    }
    if (!propertyGot) {
      error("cannot find a method to get property '" + propertyName+"'"
            + " of bean '" + contextBean.getClass().getName() + "'");
    }
    if (returnObject == null) return null;
    else return new TypedObject(returnObject, returnObject.getClass());
  }

  /**
   *  Gets a string
   *
   *  @param stringElt            the element representing the string to read
   *  @param currentBean          the bean that is curently instanciated
   *
   *  @return                     the created object
   **/
  protected TypedObject getString(Element stringElt, Object currentBean) throws BMException {

    String value = stringElt.getAttribute("value");

    if ("".equals(value)) {
      StringBuffer sb = new StringBuffer();
      NodeList childs = stringElt.getChildNodes();
      for (int i = 0 ; i < childs.getLength() ; i++) {
        Node child = childs.item(i);
        if (child.getNodeType() == Node.TEXT_NODE) {
          sb.append(child.getNodeValue());
        }
        else if (child.getNodeType() == Node.ELEMENT_NODE) {
          TypedObject tObj = getObject(child,currentBean);
          Object convertedObj = null;
          boolean conversionDone = false;
          for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
            Element elt = (Element)enum.nextElement();
            String type = elt.getAttribute("type");
            if (!"typeConvertor".equals(type)) continue;
            String convertorClassName = elt.getAttribute("class");
            Class convertorClass = null;
            try {
              convertorClass = Class.forName(convertorClassName);
            }
            catch (ClassNotFoundException e) {
              error("unable to retrieve the class '" + convertorClassName + "'");
            }
            String methodName = elt.getAttribute("method");
            try {
              MultiMethod mm=MultiMethod.create(convertorClass,methodName,2);
              Object prms[] = new Object[2];
              prms[0] = tObj.getObject();
              prms[1] = String.class;
              convertedObj = mm.invoke(convertorClass.newInstance(), prms);
              sb.append((String)convertedObj);
              conversionDone = true;
            }

            catch (NoClassDefFoundError e) {
              // the convertor is not found. Tries to find another one
              continue;
            }
            catch (Exception e) {
              // the convertor doesn't match. Tries to find another one
              continue;
            }
          }
          if (!conversionDone) {
            error("unable to do a cast for class '"
                  + convertedObj.getClass().getName()
                  + " to class 'java.lang.String'");
          }
        }
        //<CP> faire le traitement pour les autres types de noeuds ENTITY, ...
      }
      value = sb.toString();
    }
    if (trace1) {
      System.err.println("<CP> value="+value);
      // <TODO> normalement, les espaces, retour chariots ou autres tab
      // ne sont pas conserves : a verifier
    }
    return new TypedObject(value, String.class);
  }

  /**
   *  Gets a field
   *
   *  @param fieldElt            the element representing the object to read
   *  @param currentBean         the bean that is curently instanciated
   *
   *  @return                    the value of a field
   **/
  protected TypedObject getField(Element fieldElt, Object currentBean) throws BMException {
    String fieldName   = fieldElt.getAttribute("name");
    String target    = fieldElt.getAttribute("target");
    Object contextBean = currentBean;
    Class baseClass = null;
    if (!"".equals(target)) {
      if (target.startsWith("class:")) {
        target = target.substring(6);
        contextBean = null;
        try {
          baseClass = Class.forName(target);
        }
        catch (ClassNotFoundException cnfe) {
          error("unable to find the class '" + target + "'");
        }
      }
      else {
        contextBean = _registeredBeans.get(target);
        if (contextBean == null) {
          error("unable to retrieve a bean registered with the name '" + target + "'");
        }
        baseClass = contextBean.getClass();
      }
    }
    else {
      if ((contextBean != null) && !Class.class.isInstance(contextBean))
        baseClass = contextBean.getClass();
      else baseClass = (Class)contextBean;
    }

    TypedObject returnObject = null;
    try {
      Field field = baseClass.getField(fieldName);
      Object obj = field.get(contextBean);
      if (obj == null) returnObject = null;
      else returnObject = new  TypedObject(obj, field.getType());
    }
    catch (NoSuchFieldException nsfe) {
      error("unable to find the field '" + fieldName + "' in the class '"
            + baseClass.getName() + "'");
    }
    catch (SecurityException se) {
      error("security exception while accessing the field '" + fieldName
            + "' of the class '" + baseClass.getName() + "'");
    }
    catch (IllegalAccessException se) {
      error("unable to access the field '" + fieldName
            + "' of the class '" + baseClass.getName() + "'");
    }
    return returnObject;
  }

  /**
   *  Sets a field
   *
   *  @param fieldElt            the element representing the object to read
   *  @param currentBean         the bean that is curently instanciated
   *
   *  @return                    the value returned when setting the field
   **/
  protected TypedObject setField(Element fieldElt, Object currentBean) throws BMException {
    String fieldName   = fieldElt.getAttribute("name");
    String target    = fieldElt.getAttribute("target");
    Object contextBean = currentBean;
    Class baseClass = null;
    if (!"".equals(target)) {
      if (target.startsWith("class:")) {
        target = target.substring(6);
        contextBean = null;
        try {
          baseClass = Class.forName(target);
        }
        catch (ClassNotFoundException cnfe) {
          error("unable to find the class '" + target + "'");
        }
      }
      else {
        contextBean = _registeredBeans.get(target);
        if (contextBean == null) {
          error("unable to retrieve a bean registered with the name '" + target + "'");
        }
        baseClass = contextBean.getClass();
      }
    }
    else {
      if ((contextBean != null) && !Class.class.isInstance(contextBean))
        baseClass = contextBean.getClass();
      else baseClass = (Class)contextBean;
    }

    // retrieve the parameters
    // we use a standard algorithm to retrieve all
    // parameter values and generate an error is
    // more than one value is specified
    int nbParam = 1; // one parameter for setting the property
    Class[] paramClasses = new Class[nbParam];
    Object params[] = new Object[nbParam];

    String value = fieldElt.getAttribute("value");
    if (value.length() > 0) {
      params[0] = value;
      paramClasses[0] = String.class;
    }
    else {
      boolean forceArrayCreation = false;
      // if the 'setField' method is called with an array of objects,
      // then we force the creation of an array holding all the sub elements
      if (autoCastFieldArgs
          && (_xml.countNbChildElements(fieldElt) > 1)) {
        forceArrayCreation = true;
      }
      getParam(fieldElt.getChildNodes(), params, paramClasses, 0, currentBean, forceArrayCreation);
    }

    if (params.length > 1) {
      error("more than one value is specified for the field '"
            + fieldName + "' in the class '" + baseClass.getName() + "'");
    }

    try {
      Field field = baseClass.getField(fieldName);
      field.set(contextBean, params[0]);
    }
    catch (NoSuchFieldException nsfe) {
      error("unable to find the field '" + fieldName + "' in the class '"
            + baseClass.getName() + "'");
    }
    catch (SecurityException se) {
      error("security exception while accessing the field '" + fieldName
            + "' of the class '" + baseClass.getName() + "'");
    }
    catch (IllegalAccessException se) {
      error("unable to access the field '" + fieldName
            + "' of the class '" + baseClass.getName() + "'");
    }

    return new  TypedObject(params[0], paramClasses[0]);
  }

  /**
   * Sets a new event binding to the bean
   *
   * @param eventElt          the element describing the event binding
   * @param currentBean       the bean currently instanciated
   *
   *  @return                    the value returned when setting the event
   **/
  protected TypedObject setEventBinding(Element eventElt, Object currentBean) throws BMException {
    String eventName = eventElt.getAttribute("name");
    String target    = eventElt.getAttribute("target");
    String filter    = eventElt.getAttribute("filter");
    Object contextBean = currentBean;
    TypedObject returnValue = null;

    if ("".equals(eventName)) {
      error("no name specified for an '<event-binding'> element");
    }


    if (!"".equals(target)) {
      contextBean = _registeredBeans.get(target);
      if (contextBean == null) {
        error("unable to retrieve a bean registered with the name '" + target + "'");
      }
    }

    // retrieves the method to use to set the listener
    BeanInfo bInfo = null;
    try {
      bInfo = Introspector.getBeanInfo(contextBean.getClass());
    }
    catch (IntrospectionException ie) {
      error("error occured during introspection of the bean: '"
            + contextBean.getClass().getName()+"'.");
    }
    Method addListenerMethod = null;
    EventSetDescriptor[] esd = bInfo.getEventSetDescriptors();
    for (int i = 0 ; i < esd.length ; i++) {
      String n = esd[i].getName();
      if (!eventName.equals(n)) continue;
      addListenerMethod = esd[i].getAddListenerMethod();
      break;
    }
    if (addListenerMethod == null) {
      error("unable to find a setter for a listener of '" + eventName
              + "' events on the bean '"
              + contextBean.getClass().getName() + "'.");
    }

    Element elt = _xml.getFirstChildElement(eventElt);
    boolean eventSet = false;
    if ((elt == null)
        || "".equals(elt.getTagName())) {
      error("a '<bean>' or a '<script>' element must be specified for '<event-binding'>");
    }
    else if ("bean".equals(elt.getTagName())) {
      // getObject is called instead of a natural 'getBean'
      // to perform the bean registration which takes place in
      // the getObject method
      returnValue = getObject(elt, currentBean);
      // setting the listener
      Object param[] = new Object[1];
      param[0] = returnValue.getObject();
      try {
        addListenerMethod.invoke(contextBean, param);
        eventSet = true;
      }
      catch (Exception e) {
        error("cannot set a listener for '" + eventName
              + "' event on the bean '"
              + contextBean.getClass().getName()+"'.");
      }
    }
    else if ("script".equals(elt.getTagName())) {
      // the instruction below is just to test the validity of the script
      //returnValue = getObject(elt, currentBean);

      Object param[] = new Object[1];
      String handlerClassName = null;
      // retrieves the event handler class
      for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
        Element el = (Element)enum.nextElement();
        String type = el.getAttribute("type");
        if (!"eventHandler".equals(type)) continue;
        String name = el.getAttribute("name");
        if (!eventName.equals(name)) continue;
        handlerClassName = el.getAttribute("class");
        if ("".equals(handlerClassName)) {
          error("no class name specified for an event of type '" + eventName + "'");
        }
        break;
      }
      if (handlerClassName == null) {
        error("handler for event of type '" + eventName + "' not specified");
      }
      
      Class scriptClass = null;
      try {
        scriptClass = Class.forName(handlerClassName);
        param[0] = scriptClass.newInstance();
      }
      catch (InstantiationException e) {
        error("unable to instanciate the classe '"
              + scriptClass.getName()
              + "'. Check if a constructor with zero argument "
              + "is declared for this class");
      }
      catch (IllegalAccessException e) {
        error("unable to instanciate the classe '"
              + scriptClass.getName()
              + "'. Check if this class has a _public_ constructor");
      }
      catch (ClassNotFoundException e) {
        error("classe '" + handlerClassName + "' not found");
      }


      try {
        addListenerMethod.invoke(contextBean, param);
        eventSet = true;
      }
      catch (Exception e) {
        e.printStackTrace();
        
        error("cannot set a listener for '" + eventName
              + "' event on the bean '"
              + scriptClass.getName()+"'.");
      }

      if (eventSet) {
        if ("".equals(filter))
          ScriptEventProcessor.register(contextBean,
                                        elt,
                                        _registeredBeans,
                                        _xbmapper, _contextURL);
        else ScriptEventProcessor.register(contextBean,
                                           elt,
                                           _registeredBeans,
                                           _xbmapper,
                                           _contextURL,
                                           filter);
      }
    }
    else {
      error("element '<" + elt.getTagName()
            + ">' cannot be present inside a '<event-binding>' element");
    }
    if (!eventSet) {
      error("unable to find a setter for a listener of '" + eventName
            + "' events on the bean '"
            + contextBean.getClass().getName() + "'.");
    }
        
    return returnValue;
  }

  /**
   * Applies a function specified in a XML bean specification.
   *
   *  @param methodElt          the component to which the method must be applied
   *  @param currentBean        the bean currently instanciated
   *
   *  @return                   the object created by a call to the method
   *
   **/
  protected TypedObject getMethod(Element methodElt, Object currentBean) throws BMException {
    String methodName = methodElt.getAttribute("name");
    String target = methodElt.getAttribute("target");

    Class targetClass = null;
    Object contextBean = currentBean;
    if (!"".equals(target)) {
      if (target.startsWith("class:")) {
        target = target.substring(6);
        try {
          targetClass = Class.forName(target);
          contextBean = targetClass;
        }
        catch (ClassNotFoundException cnfe) {
          error("unable to find the class '" + target + "'");
        }
      }
      else {
        contextBean = _registeredBeans.get(target);
        if (contextBean == null) {
          error("unable to retrieve a bean registered with the name '" + target + "'");
        }
          targetClass = contextBean.getClass();
      }
    }
    else {
      if (contextBean == null) {
        error("no target specified for method '" + methodName + "'");
      }
      else {
        if (!Class.class.isInstance(contextBean))
          targetClass = contextBean.getClass();
        else targetClass = (Class)contextBean;
      }
    }

    // gets the parameter(s) specified in the XML specification of the bean
    int nbParam = _xml.countNbChildElements(methodElt);
    Class[] paramClasses = new Class[nbParam];
    Object params[] = new Object[nbParam];
    String value = methodElt.getAttribute("value");
    if (value.length() > 0) {
      params[0] = value;
      paramClasses[0] = value.getClass();
    }
    else {
      getParam(methodElt.getChildNodes(), params, paramClasses, 0, currentBean);
    }

    Object returnedObject = null;
    // first, tries to apply a method which accept exactly
    // the same formal parameter types
    try {
      Method method = targetClass.getMethod(methodName, paramClasses);
      returnedObject = method.invoke(contextBean, params);
    }
    catch (Exception e) {
      // no method accepting all parameters can be applied without a cast
      // Tries now to find a method which can accept the specified
      // arguments after a simple casting from the given parameters to
      // the expected ones
      try {
        Method[] methods = targetClass.getMethods();
        Class[] convertedParamClasses = null;
        boolean goodParameters = true;
        for (int i = 0 ; i < methods.length ; i++) {
          if (!methods[i].getName().equals(methodName)) continue;
          Class[] paramTypes = methods[i].getParameterTypes();
          if (nbParam != paramTypes.length) continue;
          convertedParamClasses = new Class[nbParam];
          goodParameters = true;
          for (int j = 0 ; j < nbParam ; j++) {
            if (!paramTypes[j].isAssignableFrom(paramClasses[j])) {
              goodParameters = false;
              break;
            }
            convertedParamClasses[j] = paramTypes[j];
          }
          if (goodParameters) break;
        }
        if (goodParameters) {
          try {
            Method method = targetClass.getMethod(methodName, convertedParamClasses);
            returnedObject = method.invoke(contextBean, params);
          }
          catch (Exception e1) {
            error("unexpected error while calling the method '"
                  + methodName + "' of class '" + targetClass.getName() + "'");
          }
        }
        else if (autoCastMethodArgs) {
          // tries now to use a typeConverter to cast the arguments
          Method selectedMethod = null;
          Object[] convertedParams = null;
          for (int i = 0 ; i < methods.length ; i++) {
            if (!methods[i].getName().equals(methodName)) continue;
            Class[] paramTypes = methods[i].getParameterTypes();
            if (nbParam != paramTypes.length) continue;
            convertedParams = new Object[nbParam];
            selectedMethod = methods[i];
            goodParameters = true;
            for (int j = 0 ; j < nbParam ; j++) {
              boolean conversionDone = false;
              for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
                Element elt = (Element)enum.nextElement();
                String type = elt.getAttribute("type");
                if (!"typeConvertor".equals(type)) continue;
                String convertorClassName = elt.getAttribute("class");
                Class convertorClass = null;
                try {
                  convertorClass = Class.forName(convertorClassName);
                }
                catch (ClassNotFoundException cnfe) {
                  error("unable to retrieve the class '" + convertorClassName + "'");
                }
                String mName = elt.getAttribute("method");
                try {
                  MultiMethod mm=MultiMethod.create(convertorClass,mName,2);
                  Object prms[] = new Object[2];
                  prms[0] = params[j];
                  prms[1] = paramTypes[j];
                  convertedParams[j] = mm.invoke(convertorClass.newInstance(), prms);
                  conversionDone = true;
                }

                catch (NoClassDefFoundError ex) {
                  // the convertor is not found. Tries to find another one
                  continue;
                }
                catch (Exception ex) {
                  // the convertor doesn't match. Tries to find another one
                  continue;
                }
              }
              if (!conversionDone) {
                goodParameters = false;
                break;
              }
            }
            if (goodParameters) break;
          }
          if (goodParameters) {
            try {
              returnedObject = selectedMethod.invoke(contextBean, convertedParams);
            }
            catch (Exception e1) {
              error("unexpected error while calling the method '"
                    + methodName + "' of class '" + targetClass.getName() + "'");
            }
          }
        }
        else {
          error("unable to call the method '"
                + methodName + "' of class '" + targetClass.getName() + "'");
        }
      }
      catch (SecurityException se) {
        error("security exception raised while retrieving the method '"
              + methodName + "' of class '" + targetClass.getName() + "'");
      }
      catch (Exception e1) {
        e1.printStackTrace();
        error("error while calling the method '"
              + methodName + "' of class '" + targetClass.getName() + "'");
      }
    }
    if (returnedObject == null) return null;
    else return new TypedObject(returnedObject, returnedObject.getClass());
  }

  /**
   *  Gets a Cast
   *
   *  @param castElt            the element representing the object to read
   *  @param currentBean        the bean that is curently instanciated
   *
   *  @return                   the created object 
   **/
  protected TypedObject getCast(Element castElt, Object currentBean) throws BMException {
    String className = castElt.getAttribute("class");
    if ("".equals(className)) {
      error("attribute 'class' not specified in a cast");
    }
    
    String value = castElt.getAttribute("value");
    TypedObject objectToConvert = null;
    if ("".equals(value)) {
      if (_xml.countNbChildElements(castElt) > 1) {
        error("more than one value specified in a cast element");
      }
      objectToConvert = getObject(_xml.getFirstChildElement(castElt), currentBean);
    }
    else {
      objectToConvert = new TypedObject(value, String.class);
    }

    Class targetClass = (Class)_mappingClassName.get(className);
    if (targetClass == null) {
      try {
        targetClass = Class.forName(className);
      }
      catch (ClassNotFoundException cnfe) {
        error("unable to retieve the class '" + className + "'.");
      }
    }

    TypedObject convertedObject = null;

    boolean conversionDone = false;
    for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
      Element elt = (Element)enum.nextElement();
      String type = elt.getAttribute("type");
      if (!"typeConvertor".equals(type)) continue;
      String convertorClassName = elt.getAttribute("class");
      Class convertorClass = null;
      try {
        convertorClass = Class.forName(convertorClassName);
      }
      catch (ClassNotFoundException e) {
        error("unable to retrieve the class '" + convertorClassName + "'");
      }
      String methodName = elt.getAttribute("method");
      try {
        MultiMethod mm=MultiMethod.create(convertorClass,methodName,2);
        Object prms[] = new Object[2];
        prms[0] = objectToConvert.getObject();
        prms[1] = targetClass;
        Object obj = mm.invoke(convertorClass.newInstance(), prms);
        convertedObject = new TypedObject(obj, targetClass);
        conversionDone = true;
      }
      
      catch (NoClassDefFoundError e) {
        // the convertor is not found. Tries to find another one
        continue;
      }      
      catch (Exception e) {
        // the convertor doesn't match. Tries to find another one
        continue;
      }
    }
    if (!conversionDone) {
      error("unable to do a cast for class '"
            + objectToConvert.getObject().getClass().getName()
            + " to class "
            + targetClass.getName());
    }
    return convertedObject;
  }

  /**
   *  Gets a Array
   *
   *  @param arrayElt            the element representing the array to read
   *  @param currentBean         the bean that is curently instanciated
   *
   *  @return                    the created object 
   **/
  protected TypedObject getArray(Element arrayElt, Object currentBean) throws BMException {
    Element elt = _xml.getFirstChildElement(arrayElt);
    int arrayLength = _xml.countNbChildElements(arrayElt);
    Object objArray = null;
    Class  objClass   = null;
    int indx = 0;
    while (elt != null) {
      TypedObject to = getObject(elt, currentBean);

      // when the first object in the array is read,
      // we are able to initialize the array and the element type
      if (objClass == null) {
        objClass = to.getType();
        objArray = Array.newInstance(objClass, arrayLength);
      }
      else { //check if the class of the new element is compatible with previous ones
        if (objClass != to.getType()) {
          error("an '<array>' element cannot contains objects of different classes");
        }
      }
      Array.set(objArray,indx,to.getObject());
      indx += 1;
      elt=_xml.getNextElement(elt);
    }
    return new TypedObject(objArray, objArray.getClass());
  }

  /**
   * If a constructor matching all parameters
   * cannot be found, try to find a constructor
   * using parameters that can be obtained with a conversion of
   * all given parameters
   *
   * @ return   the created object or null if the creation is impossible
   */
  private Object createBeanWAutoCast(Class theClass, Object[] params) throws BMException {
    int matchingCons = -1;
    int nbParams = params.length;
    Object[] memoConvert = new Object[nbParams];
    //    TypeConvertor tc = new TypeConvertor();
    Constructor[] cons = theClass.getConstructors();
    for (int i = 0 ; i < cons.length ; i++) {
      Class[] expectedParams = cons[i].getParameterTypes();
      if (expectedParams.length != nbParams) continue;
      Object[] convertedParams = new Object[nbParams];
      boolean conversionFailed = false;
      for (int j = 0 ; j < nbParams ; j++) {
        boolean conversionDone = false;
        for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
          Element elt = (Element)enum.nextElement();
          String type = elt.getAttribute("type");
          if (!"typeConvertor".equals(type)) continue;
          String convertorClassName = elt.getAttribute("class");
          Class convertorClass = null;
          try {
            convertorClass = Class.forName(convertorClassName);
          }
          catch (ClassNotFoundException e) {
            error("unable to retrieve the class '" + convertorClassName + "'");
          }
          String methodName = elt.getAttribute("method");
          try {
            MultiMethod mm=MultiMethod.create(convertorClass,methodName,2);
            Object prms[] = new Object[2];
            prms[0] = params[j];
            prms[1] = expectedParams[j];
            convertedParams[j] = mm.invoke(convertorClass.newInstance(), prms);
            conversionDone = true;
          }

          catch (NoClassDefFoundError e) {
            // the convertor is not found. Tries to find another one
            continue;
          }
          catch (Exception e) {
            // the convertor doesn't match. Tries to find another one
            continue;
          }
        }
        if (!conversionDone) {
          conversionFailed = true;
          break;
        }
      }
      if (conversionFailed) continue;
      if (matchingCons >= 0) matchingCons = -2;
      else {
        matchingCons = i;
        for (int j = 0 ; j < nbParams ; j++) {
          memoConvert[j] = convertedParams[j];
        }
      }
    }
    if (matchingCons == -1) {
      // unable to find a constructor
      return null;
    }
    else if (matchingCons == -2) {
      // several constructors can be used
      return null;
    }
    try {
      return cons[matchingCons].newInstance(memoConvert);
    }
    catch (Exception e) {
      // error during the creation of the bean
      return null;
    }
  }

  /**
   * Processes a fire-event element
   *
   *  @param fireEventElt          the component to which the fire-event
   *  @param currentBean           the bean currently instanciated
   *
   *  @return                      the object created by the processing of the element
   *
   **/
  protected TypedObject setFireEvent(Element fireEventElt, Object currentBean) throws BMException {
    String eventType = fireEventElt.getAttribute("type");
    BeanEditEvent beEvent = null; // the event that has to be fired

    if ("".equals(eventType)) {
      Element elt = _xml.getFirstChildElement(fireEventElt);
      if ((elt == null)
          || "".equals(elt.getTagName())
          || !"bean".equals(elt.getTagName())) {
        error("a '<bean>' element must be specified for '<fire-event'>");
      }
      TypedObject returnValue = getObject(elt, currentBean);
      Object evt = returnValue.getObject();
      if (!(evt instanceof BeanEditEvent)) {
        error("only instances of 'BeanEditEvent' can be fired with '<fire-event'>");
      }
      beEvent = (BeanEditEvent)evt;
    }
    else {
      String source = fireEventElt.getAttribute("source");
      Object bean = currentBean;
      if (!"".equals(source)) bean =_registeredBeans.get(source);

      if ("END".equalsIgnoreCase(eventType)) {
        beEvent = new BeanEditEvent(currentBean, BeanEditEvent.END);
      }
      else if ("CHANGE_PROPERTY".equalsIgnoreCase(eventType)) {
        String pName = fireEventElt.getAttribute("name");
        if ("".equals(pName)) pName = null;
        beEvent = new BeanEditEvent(bean, BeanEditEvent.CHANGE_PROPERTY, pName, null, null);
      }
      else if ("ADD_CHILD".equalsIgnoreCase(eventType)) {
        String childName = fireEventElt.getAttribute("name");
        beEvent = new BeanEditEvent(bean, BeanEditEvent.ADD_CHILD, childName);      
      }
      else if ("REMOVE_CHILD".equalsIgnoreCase(eventType)) {
        String childRef = fireEventElt.getAttribute("child");
        Object child = _registeredBeans.get(childRef);
        beEvent = new BeanEditEvent(bean, BeanEditEvent.REMOVE_CHILD, child);
      }
      else {
        error("unknown type ("+eventType+") in a '<fire-event'> element");
      }
    }

    if (_xbmapper != null) _xbmapper.beanEditPerformed(beEvent);
    return null;
  }

  /**
   * Processes a add element
   *
   *  @param addElt                the element representing the add
   *  @param currentBean           the bean currently instanciated
   *
   *  @return                      the object created by the processing of the element
   *
   **/
  protected TypedObject executeAdd(Element addElt, Object currentBean) throws BMException {
    String target = addElt.getAttribute("target");
    Object contextBean = currentBean;
    if (!"".equals(target)) {
      contextBean = _registeredBeans.get(target);
      if (contextBean == null) {
        error("unable to retrieve a bean registered with the name '" + target + "'");
      }
    }
    // gets the parameters for the add
    int nbParam = _xml.countNbChildElements(addElt);
    Class[] paramClasses = new Class[nbParam+1];
    Object params[] = new Object[nbParam+1];
    paramClasses[0] = contextBean.getClass();
    params[0] = contextBean;
    getParam(addElt.getChildNodes(), params, paramClasses, 1, currentBean);

    // retrieves the adder to use for this type of 'contextBean' elements
    String className = contextBean.getClass().getName();
    for (Enumeration enum = _registerList.elements() ; enum.hasMoreElements() ;) {
      Element elt = (Element)enum.nextElement();
      String type = elt.getAttribute("type");
      if (!"adder".equals(type)) continue;
      String adderClassName = elt.getAttribute("class");
      Class adderClass = null;
      try {
        adderClass = Class.forName(adderClassName);
      }
      catch (ClassNotFoundException e) {
        error("unable to retrieve the class '" + adderClassName + "'");
      }
      String methodName = elt.getAttribute("method");

      try {
        MultiMethod mm=MultiMethod.create(adderClass,methodName,nbParam+1);
        mm.invoke(adderClass.newInstance(), params);
      }
      catch (NoClassDefFoundError e) {
        // the adder is not found. Tries to find another one
        continue;
      }
      catch (Exception e) {
        // the adder doesn't match. Tries to find another one
        continue;
      }
      break;
    }
    Object returnedObject = params[1];
    if (returnedObject == null) return null;
    else return new TypedObject(returnedObject, returnedObject.getClass());
  }

  /**
   * Processes a script element
   *
   *  @param scriptElt             the component representing the script
   *  @param currentBean           the bean currently instanciated
   *
   *  @return                      the object created by the processing of the element
   *
   **/
  protected TypedObject getScript(Element scriptElt, Object currentBean) throws BMException {
    String language = scriptElt.getAttribute("language");
    if (!"".equals(language)
        && (!"bm'".equals(language))) {
      error("scripting language '" + language + "' is not supported");
    }

    Element childElt = _xml.getFirstChildElement(scriptElt);

    // variables used to memorize the parameters
    int nbParam = 0;
    Class[] paramClasses = null;
    Object params[] = null;
    
    if ((childElt != null)
        && "args".equals(childElt.getTagName())) {
      // gets the parameter(s) specified in the XML specification of the script
      Element argsElt = childElt;
      childElt = _xml.getNextElement(childElt);
      nbParam = _xml.countNbChildElements(argsElt);
      paramClasses = new Class[nbParam];
      params = new Object[nbParam];
      getParam(argsElt.getChildNodes(), params, paramClasses, 0, currentBean);
    }

    TypedObject resultObject = null;
    Hashtable localRegistry = (Hashtable)_registeredBeans.clone();
    for (int i = 0 ; i < nbParam ; i++) {
      localRegistry.put("script:arg"+i, params[i]);
    }
    BMProcessor process = new BMProcessor(_xbmapper);
    while (childElt != null) {
      Object obj = process.processBM(childElt, localRegistry, currentBean, _contextURL);

      if (obj == null) resultObject = null;
      else resultObject = new TypedObject(obj, obj.getClass());
      childElt = _xml.getNextElement(childElt);
    }
    return resultObject;
  }

  /**
   * Processes a script element
   *
   *  @param listenElt             the component representing the listener
   *  @param currentBean           the bean currently instanciated
   *
   *  @return                      the object created by the processing of the element
   *
   **/
  protected TypedObject setListener(Element listenElt, Object currentBean) throws BMException {
    if (_xbmapper == null) {
      error("unknown tag '" + listenElt.getTagName());
    }
    String eventName = listenElt.getAttribute("name");
    String target    = listenElt.getAttribute("target");
    String filter    = listenElt.getAttribute("filter");
    Object contextBean = currentBean;
    TypedObject returnValue = null;

    if ("".equals(eventName)) {
      error("no name specified for an '<event-binding'> element");
    }


    if (!"".equals(target)) {
      contextBean = _registeredBeans.get(target);
      if (contextBean == null) {
        error("unable to retrieve a bean registered with the name '" + target + "'");
      }
    }

    // retrieves the method to use to set the listener
    BeanInfo bInfo = null;
    try {
      bInfo = Introspector.getBeanInfo(contextBean.getClass());
    }
    catch (IntrospectionException ie) {
      error("error occured during introspection of the bean: '"
            + contextBean.getClass().getName()+"'.");
    }

    Method addListenerMethod = null;
    EventSetDescriptor[] esd = bInfo.getEventSetDescriptors();
    for (int i = 0 ; i < esd.length ; i++) {
      String n = esd[i].getName();
      if (!eventName.equals(n)) continue;
      addListenerMethod = esd[i].getAddListenerMethod();
      break;
    }
    if (addListenerMethod == null) {
      error("unable to find a setter for a listener of '" + eventName
              + "' events on the bean '"
              + contextBean.getClass().getName() + "'.");
    }

    // setting the listener to the XBMapper
    Object param[] = new Object[1];
    param[0] = _xbmapper;
    try {
      addListenerMethod.invoke(contextBean, param);
    }
    catch (Exception e) {
      error("cannot set a listener for '" + eventName
            + "' event on the bean '"
            + contextBean.getClass().getName()+"'.");
    }
    return null;
  }

  /**
   *  Error processing
   *
   *  @param mess             the message of the error
   **/
  protected void error(String mess) throws BMException {
    throw new BMException(mess);
  }

  /**
   *  Error processing
   *
   *  @param mess             the message of the error
   *  @param param            a parameter to the error message
   **/
  protected void error(String mess, Object param) throws BMException {
    error(mess);
  }
}
