/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk;

import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
 * A Collection of methods to remove an object placed in a containing one
 *
 * @author Claude Pasquier
 */
public class Removers {

  /**
   * Default constructor
   */
  public Removers() {
  }

  /**
   * Remover for an object of class Component placed in a Container
   *
   *  @param parent    the container of the component
   *  @param comp      the component to remove
   **/
  public void remove(Container parent, Component comp) {
    parent.remove(comp);
  }

  /**
   * Remover for an object of class Component placed in a JFrame
   *
   *  @param parent    the JFrame containing the component
   *  @param comp      the component to remove
   **/
  public void remove(JFrame parent, Component comp) {
    parent.getContentPane().remove(comp);
  }

  /**
   * Remover for an object of class MenuComponent placed in a Menu
   *
   *  @param menu      the menu containing the item
   *  @param item      the menuComponent to remove
   **/
  public void remove(Menu menu, MenuComponent item) {
    menu.remove(item);
  }

  /**
   * Remover for an object of class MenuComponent placed in a MenuBar
   *
   *  @param menubar   the menubar containing the item
   *  @param menu      the menuComponent to remove
   **/
  public void remove(MenuBar menubar, MenuComponent menu) {
    menubar.remove(menu);
  }

  /**
   * Remover for an object of class Component placed in a JMenu
   *
   *  @param menu      the menu containing the component
   *  @param comp      the component to remove
   **/
  public void remove(JMenu menu, Component comp) {
    menu.remove(comp);
  }

  /**
   * Remover for an object of class JMenuItem placed in a JMenu
   *
   *  @param menu      the menu containing the item
   *  @param item      the menuItem to remove
   **/
  public void remove(JMenu menu, JMenuItem item) {
    menu.remove(item);
  }

  /**
   * Remover for an object of class Object placed in a Vector
   *
   *  @param parent   the vector containing the object
   *  @param obj      the object to remove
   **/
  public void remove(Vector parent, Object obj) {
    parent.removeElement(obj);
  }

  /**
   * Remover for an object of class Object placed in a Dictionnary
   *
   *  @param parent   the dictionnary containing the object
   *  @param key      the object to remove
   **/
  public void remove(Dictionary parent, Object key) {
    parent.remove(key);
  }
}
