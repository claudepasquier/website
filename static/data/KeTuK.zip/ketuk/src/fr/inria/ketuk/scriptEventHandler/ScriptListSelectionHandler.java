/* Copyright (c) 2000 by INRIA. Read the COPYRIGHT file. */
/* Author: Claude.Pasquier@sophia.inria.fr               */

package fr.inria.ketuk.scriptEventHandler;

import fr.inria.ketuk.*;
import javax.swing.event.*;


/**
 * A listener class which handle listSelection events
 *
 * @author Claude Pasquier
 */
  
public class ScriptListSelectionHandler implements ListSelectionListener {

  public void valueChanged(ListSelectionEvent event) {
    ScriptEventProcessor p = new ScriptEventProcessor();
    p.processEvent(event, "valueChanged");
  }
}
