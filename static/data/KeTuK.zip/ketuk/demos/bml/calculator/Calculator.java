package demos.calculator;

import java.beans.*;

public class Calculator {
  PropertyChangeSupport pcs = new PropertyChangeSupport (this);
  private boolean first = true; // reset after one recalc

  // the two inputs
  private int a;
  private int b;

  // outputs 
  private float sum, diff, prod, quo;

  public void setA (int a) {
    this.a = a; 
    recalculate ();
  }

  public void setB (int b) {
    this.b = b;
    recalculate ();
  }

  public synchronized void 
  addPropertyChangeListener (PropertyChangeListener listener) {
    pcs.addPropertyChangeListener (listener);
  }
  public synchronized void 
  removePropertyChangeListener (PropertyChangeListener listener) {
    pcs.removePropertyChangeListener (listener);
  }

  public float getSum () { return sum; }
  public float getDiff () { return diff; }
  public float getProd () { return prod; }
  public float getQuo () { return quo; }
  
  private void recalculate () {
    pcs.firePropertyChange ("sum", 
			    first ? null : new Float (sum), 
			    new Float (sum=a+b));
    pcs.firePropertyChange ("diff", 
			    first ? null : new Float (diff), 
			    new Float (diff=a-b));
    pcs.firePropertyChange ("prod", 
			    first ? null : new Float (prod), 
			    new Float (prod=a*b));
    pcs.firePropertyChange ("quo",
			    first ? null : new Float (quo), 
			    new Float (quo=a/((float)1.0*b)));
    first = false;
  }
}
