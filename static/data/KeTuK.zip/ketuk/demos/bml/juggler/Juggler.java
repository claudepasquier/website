//package sunw.demo.juggler;
package demos.juggler;

/**
 * This is a demo based on Sun's Juggler demo (featuring Duke).
 *
 * The modifications to the code include:
 *
 * The Juggler will now load all sequentially numbered ".gif"'s that
 * match the naming convention (instead of a predefined number).
 *
 * The Juggler will now stop on whatever frame is currently being
 * displayed when the "stop" actionEvent is fired (as opposed to
 * going back to a dead frame). This is necessary because dissimilar
 * objects are now being juggled.
 */

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.IOException;
import java.net.URL;
import java.util.*;

import com.ibm.cs.util.StringUtils;

public class Juggler extends Applet implements Runnable {
  private static final String FILE_PREFIX = "Juggle_";
  private static final String FILE_SUFFIX = ".gif";

  private transient Image[] images;
  private transient Thread animationThread;
  private int rate = 110;
  private transient int loop;
  private boolean stopped = true;
  private int imageCount = 0;

  /**
   * Applet method: start the Juggler applet.
   */
  public synchronized void start() {
    startJuggling();
  }

  /**
   * Applet method: stop the Juggler applet.
   */
  public synchronized void stop() {
    stopJuggling();
  }

  /**
   * Initialize the Juggler applet.
   */
  private void initialize()
  {
    Vector imageVector = new Vector();
    String imageName   = FILE_PREFIX + imageCount + FILE_SUFFIX;
    Image  image;

    while ((image = loadImage(imageName)) != null) {
      imageVector.addElement(image);
      imageCount++;
      imageName = FILE_PREFIX + imageCount + FILE_SUFFIX;
    }
    
    if (imageCount > 0) {
      images = new Image[imageCount];

      for (int i = 0; i < imageVector.size(); i++) {
        images[i] = (Image)imageVector.elementAt(i);
      }
    } else {
      System.err.println("Unable to load image: " + imageName);
    }
  }

  /**
   * This is an internal utility method to load GIF icons.
   * It takes the name of a resource file associated with the
   * current object's class-loader and loads a GIF image
   * from that file.
   * <p>
   * @param resourceName A pathname relative to the DocumentBase
   *                     of this applet, e.g. "wombat.gif".
   * @return a GIF image object. May be null if the load failed.
   */
  private Image loadImage(String name) {
    try {
      URL url = getClass().getResource(name);

      if (url == null) {
        try {
          url = StringUtils.getURL(null, name);
        } catch (SecurityException e) {
          return null;
        }
      }

      return createImage((ImageProducer) url.getContent());
    } catch (IOException ex) {
      return null;
    }
  }

  /**
   * Draw the current frame.
   */
  public void paint(Graphics g) {
    if (images == null) {
      return;
    }

    int index = loop % imageCount;

    if (index >= images.length) {
      return;
    }

    Image img = images[index];

    if (img != null) {
      g.drawImage(img, 0, 0, this);
    }
  }

  /**
   * If false, suspend the animation thread.
   */
  public synchronized void setEnabled(boolean x) {
    super.setEnabled(x);
    notify();
  }

  /**
   * Resume the animation thread if we're enabled.
   * @see #stopJuggling
   * @see #setEnabled
   */
  public synchronized void startJuggling() {
    if (images == null) {
      initialize();
    }
  	
    if (animationThread == null) {
      animationThread = new Thread(this);
      animationThread.start();
    }
  	
    stopped = false;
    notify();
  }

  /**
   * Suspend the animation thread if neccessary.
   * @see #startJuggling
   * @see #setEnabled
   */
  public synchronized void stopJuggling() {
    stopped = true;
    Graphics g = getGraphics();
  	
    if (g == null || images == null) {
      return;
    }
    else {
      paint(g);
    }
  }

  /**
   * An event handling method that calls startJuggling. This method
   * can be used to connect a Button or a MenuItem to the Juggler.
   *
   */
  public void startJuggling(ActionEvent x) {
    startJuggling();
  }

  /**
   * This method can be used to connect a Button or a MenuItem
   * to the Juggler.stopJuggling method.
   */
  public void stopJuggling(ActionEvent x) {
    stopJuggling();
  }

  public int getAnimationRate() {
    return rate;
  }

  public void setAnimationRate(int x) {
    rate = x;
  }

  public Dimension getMinimumSize() {
    return new Dimension(144, 125);
  }

  /**
   * @deprecated provided for backward compatibility with old layout managers.
   */
  public Dimension minimumSize() {
    return getMinimumSize();
  }

  public Dimension getPreferredSize() {
    return minimumSize();
  }

  /**
   * @deprecated provided for backward compatibility with old layout managers.
   */
  public Dimension preferredSize() {
    return getPreferredSize();
  }

  public void run() {
    try {
      while(true) {
        // First wait until the animation is not stopped.
        synchronized (this) {
            while (stopped || !isEnabled()) {
              wait();
            }
        }
      	
        loop++;
      	
        if (images != null) {
          // Now draw the current frame.
          Graphics g = getGraphics();
          Image img = images[loop % imageCount];

          if (g != null && img != null) {
            g.drawImage(img, 0, 0, this);
          }
        }

        Thread.sleep(rate);
      }
    } catch (InterruptedException e) {
    }
  }
}

