import ColorFadeBar;
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.beans.*;

// This is the JavaBean wrapper for an existing applet
public class ColorFadeBean
    extends ColorFadeBar
    implements Serializable	// Every JavaBean must be Serializable
{
    public ColorFadeBean()
    {
        super();
    }

    //
    // PROPERTY ACCESSORS
    //

    // Width property
    public void setWidth(int iWidth) { _iHpoints = iWidth;}
    public int getWidth() { return _iHpoints;}

    // Height property
    public void setHeight(int iHeight) { _iVpoints = iHeight; }
    public int getHeight() { return _iVpoints; }

    // Message property
    public void setMessage(String sText) {        _sString = sText;    }
    public String getMessage() { return _sString; }

    // Color From property
    public void setColorFrom(Color newColor) { _colorFrom = newColor;}
    public Color getColorFrom() { return _colorFrom;}

    // ColorTo property
    public void setColorTo(Color newColor) { _colorTo = newColor;}
    public Color getColorTo() { return _colorTo;}

    // Message font property
    public void setMessageFont(Font font) {
        if (font == null) { font = new Font("Helvetica", Font.BOLD, 16); }
        _messageFont = font;
    }
    public Font getMessageFont() {
        if (_messageFont == null) {
            return new Font("Sans-Serif", Font.BOLD, 16);
        }
        return _messageFont;
    }

    // Message color
    public void setMessageColor(Color color) { _colorText = color;}

    public Color getMessageColor() { return _colorText;}

    // Fade direction
    public void setFadeDirection(int iNewFadeDirection)
    {
        // If new direction is out of range, ignore
        if (iNewFadeDirection >= 0 || iNewFadeDirection <= 4) {
            pcs_.firePropertyChange("FadeDirection",
                                    new Integer(_iFadeDirection),
                                    new Integer(iNewFadeDirection));

            _iFadeDirection = iNewFadeDirection;
            repaint();
        }
    }
    public int getFadeDirection() { return _iFadeDirection;}

    // Text direction
    public void setTextDirection(int iNewTextDirection)
    {
        // If new direction is out of range, throw
        // exception
        if (iNewTextDirection == LEFT || iNewTextDirection == RIGHT ||
            iNewTextDirection == CENTER) {

            pcs_.firePropertyChange("TextDirection",
                                    new Integer(_iTextDirection),
                                    new Integer(iNewTextDirection));

            _iTextDirection = iNewTextDirection;
            repaint();
        }
    }
    public int getTextDirection() { return _iTextDirection;}

    // Handle real-time resizes.
    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x,y,width,height);
        setWidth(width);
        setHeight(height);
    }

    protected PropertyChangeSupport pcs_ = new PropertyChangeSupport(this);

    //
    // Property change listeners
    //
    public void addPropertyChangeListener(PropertyChangeListener l)
    {
        System.out.println("Added property change listener");
        pcs_.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l)
    {
        pcs_.removePropertyChangeListener(l);
    }

    //
    // Listen for property changes
    //

    //
    // A property change occurred in something I'm listening to
    //
    public void propertyChange(PropertyChangeEvent evt)
    {
        String	sPropertyName = evt.getPropertyName();
        Object  objNewValue   = evt.getNewValue();
        Object  objOldValue   = evt.getOldValue();

        System.out.println("Got a property change event for " + sPropertyName);

        if (sPropertyName == "FadeDirection") {
            setFadeDirection(((Integer)objNewValue).intValue());
        } else if (sPropertyName == "TextDirection") {
            setTextDirection(((Integer)objNewValue).intValue());
        }
    }
}

