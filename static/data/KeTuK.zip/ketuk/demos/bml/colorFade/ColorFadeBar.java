
//
// This is an existing applet that runs under Java 1.0.2
//

import java.awt.*;
import java.applet.*;
import java.io.*;
import java.beans.*;

public class ColorFadeBar extends Applet implements Runnable
{
    protected int       _iHpoints = 200;
    protected int       _iVpoints = 30;
    protected int	_ix = 0;
    protected int	_dy = 0;
    protected Color     _colorFrom = new Color (0, 0, 0);
    protected Color     _colorTo = new Color (255, 255, 255);
    protected Color     _colorText = new Color (255, 255, 255);
    protected Image     _imageBuffer;
    protected Graphics  _graphicsBuffer;
    protected String    _sString;
    protected Font      _messageFont = new Font("Sans-Serif", Font.BOLD, 16);

    public static final int LEFT   = 0;
    public static final int RIGHT  = 1;
    public static final int UP     = 2;
    public static final int DOWN   = 3;
    public static final int CENTER = 4;

    protected int       _iFadeDirection = LEFT;
    protected int       _iTextDirection = LEFT;

    public void ColorFadeBar()
    {
    }

    // Get int parameter
    protected int iGetParameter(String sName, int iDefault)
    {
        int i;
        try {
            i = Integer.parseInt(getParameter(sName), 10);
        }
        catch (NumberFormatException e) { i = iDefault; }
        System.out.println(sName + " = " + i);
        return i;
    }

    // Get hex parameter
    protected int ixGetParameter(String sName, int iDefault)
    {
        int i;
        try {
            i = Integer.parseInt(getParameter(sName), 16);
        }
        catch (NumberFormatException e) { i = iDefault; }
        System.out.println(sName + " = " + i);
        return i;
    }

    public void init()
    {
        int i;
        Dimension dimSize = size();

        _iHpoints = iGetParameter("WIDTH", dimSize.width);
        _iVpoints = iGetParameter("HEIGHT", dimSize.height);

        if ((i = ixGetParameter("STARTCOLOR", 0x0)) >= 0)
            _colorFrom = new Color(i);

        if ((i = ixGetParameter("ENDCOLOR", 0xffffff)) >= 0)
            _colorTo = new Color(i);

        if ((i = ixGetParameter("TEXTCOLOR", 0xffffff)) >= 0)
            _colorText = new Color(i);

        _sString = getParameter("TEXT");
        if (_sString == null || _sString == "") {
                _sString = "Bite the Wax Tadpole";
        }

        // Get horizontal orientation
        String sOrient = getParameter("FADEDIR");
        if (sOrient != null) {
                if (sOrient.compareTo("RIGHT") == 0)
                      _iFadeDirection = RIGHT;
                else if (sOrient.compareTo("DOWN") == 0)
                    _iFadeDirection = DOWN;
                else if (sOrient.compareTo("UP") == 0)
                    _iFadeDirection = UP;
                else
                    _iFadeDirection = LEFT;
        }

        sOrient = getParameter("TEXTDIR");
        if (sOrient != null) {
            if (sOrient.compareTo("RIGHT") == 0)
                _iTextDirection = RIGHT;
            else if (sOrient.compareTo("CENTER") == 0)
                _iTextDirection = CENTER;
            else
                _iTextDirection = LEFT;
        }

        Font f = getFont();     // Get current font
        _messageFont = f;

        // If a parameter sets the font, override current.
        String sFontname = getParameter("FONT");
        if (sFontname != null && sFontname != "") {
            int iFontsize = iGetParameter("FONTSIZE", 16);
            _messageFont = new Font(sFontname, Font.BOLD, iFontsize);
        }

        // Text offsets. _ix is x position offset. _dy is y baseline offset.
        int _ix = iGetParameter("X0", 5);
        int _dy = iGetParameter("DY", 0);

        // Set applet size
        resize(new Dimension(_iHpoints, _iVpoints));

        // Create image for double-buffering
        _imageBuffer = createImage(_iHpoints, _iVpoints);
        if (_imageBuffer != null) {
                _graphicsBuffer = _imageBuffer.getGraphics();
        }
    
        // Paint requested image
        if (_graphicsBuffer != null) {
                makeImage(_graphicsBuffer);
        }
    }

    // Just paint yourself--you're just for show!
    public void run()
    {
        repaint();
    }

    public Dimension getPreferredSize()
    {
        return new Dimension(_iHpoints, _iVpoints);
    }

    // Draw the already-buffered image
    public void paint(Graphics g)
    {
        if (_imageBuffer != null) {
                g.drawImage(_imageBuffer, 0, 0, this);
        } else {
            makeImage(g);
        }
    }

    // Create the requested image
    public void makeImage(Graphics g)
    {
        Color colorFrom = _colorFrom;
        Color colorTo   = _colorTo;
    
        // Swap from and to if up or right
        if (_iFadeDirection == UP || _iFadeDirection == RIGHT)
            {
                colorFrom = _colorTo;
                colorTo = _colorFrom;
            }
    
        double r0, g0, b0;
        double reddelt = (r0 = colorFrom.getRed()) - colorTo.getRed();
        double greendelt = (g0 = colorFrom.getGreen()) - colorTo.getGreen();
        double bluedelt = (b0 = colorFrom.getBlue()) - colorTo.getBlue();

        if (_iFadeDirection == LEFT || _iFadeDirection == RIGHT)
            {
                reddelt /= 1.0 * _iHpoints;
                bluedelt /= 1.0 * _iHpoints;
                greendelt /= 1.0 * _iHpoints;

                for (int i = 0; i < _iHpoints; i++)
                {
                    g.setColor(new Color((int)r0, (int)g0, (int)b0));
                    g.drawLine(i, 0, i, _iVpoints);
                    r0 -= reddelt;
                    g0 -= greendelt;
                    b0 -= bluedelt;
                }
        }
        else
        {
            reddelt /= 1.0 * _iVpoints;
            bluedelt /= 1.0 * _iVpoints;
            greendelt /= 1.0 * _iVpoints;

            for (int i = 0; i < _iVpoints; i++)
            {
                g.setColor(new Color((int)r0, (int)g0, (int)b0));
                g.drawLine(0, i, _iHpoints, i);
                r0 -= reddelt;
                g0 -= greendelt;
                b0 -= bluedelt;
            }
        }

        // Draw text
        if (_sString != null && _sString != "")
        {
            g.setFont(_messageFont);
            g.setColor(_colorText);

            // Set ix and iy offsets
            FontMetrics fm = g.getFontMetrics();

            int ix = _ix;
            int iy = (_iVpoints + fm.getMaxAscent()) / 2 + _dy;

            if (_iTextDirection == LEFT)
            {
                // ix is fine
            }
            else if (_iTextDirection == RIGHT)
            {
                ix = _iHpoints - fm.stringWidth(_sString) - ix;
            }
            else if (_iTextDirection == CENTER)
            {
                ix = (_iHpoints - fm.stringWidth(_sString)) / 2;
            }

            g.drawString(_sString, ix, iy);
        }
    }
}
